// UserOrdersPage.js - صفحة طلبات المستخدم مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const user_orders_page_en = {
  ordersTitle: "My Orders",
  orderId: "Order ID",
  product: "Product",
  date: "Date",
  status: "Status",
  completed: "Completed",
  pending: "Pending",
  cancelled: "Cancelled",
  details: "Details",
};
export const user_orders_page_ar = {
  ordersTitle: "طلباتي",
  orderId: "رقم الطلب",
  product: "المنتج",
  date: "التاريخ",
  status: "الحالة",
  completed: "مكتمل",
  pending: "بانتظار التنفيذ",
  cancelled: "ملغي",
  details: "التفاصيل",
};
export const user_orders_page_fr = {
  ordersTitle: "Mes commandes",
  orderId: "ID de commande",
  product: "Produit",
  date: "Date",
  status: "Statut",
  completed: "Terminé",
  pending: "En attente",
  cancelled: "Annulé",
  details: "Détails",
};
export const user_orders_page_el = {
  ordersTitle: "Οι παραγγελίες μου",
  orderId: "ID παραγγελίας",
  product: "Προϊόν",
  date: "Ημερομηνία",
  status: "Κατάσταση",
  completed: "Ολοκληρώθηκε",
  pending: "Σε εκκρεμότητα",
  cancelled: "Ακυρώθηκε",
  details: "Λεπτομέρειες",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: user_orders_page_en,
  ar: user_orders_page_ar,
  fr: user_orders_page_fr,
  el: user_orders_page_el,
};

const mockOrders = [
  { id: "#1001", product: "Smart Voice Bot", date: "2025-08-06", status: "completed" },
  { id: "#1002", product: "NFT Art Pack", date: "2025-08-05", status: "pending" },
  { id: "#1003", product: "Crypto News Addon", date: "2025-08-02", status: "cancelled" },
];

export default function UserOrdersPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [orders] = useState(mockOrders);

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("ordersTitle")}</h1>
      <table className="w-full table-auto text-left border">
        <thead>
          <tr className="bg-zinc-900">
            <th className="p-2 border">#</th>
            <th className="p-2 border">{t("orderId")}</th>
            <th className="p-2 border">{t("product")}</th>
            <th className="p-2 border">{t("date")}</th>
            <th className="p-2 border">{t("status")}</th>
            <th className="p-2 border">{t("details")}</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((o, i) => (
            <tr key={o.id} className="border-t">
              <td className="p-2 border">{i + 1}</td>
              <td className="p-2 border">{o.id}</td>
              <td className="p-2 border">{o.product}</td>
              <td className="p-2 border">{o.date}</td>
              <td className="p-2 border">
                <span className={
                  o.status === "completed" ? "text-green-400" :
                  o.status === "pending" ? "text-yellow-400" : "text-red-400"
                }>
                  {t(o.status)}
                </span>
              </td>
              <td className="p-2 border">
                <button className="bg-blue-700 hover:bg-blue-800 text-white px-3 py-1 rounded">
                  {t("details")}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}
