import { useState } from 'react';
import { useTranslation } from 'next-i18next';
import { serverSideTranslations } from 'next-i18next/serverSideTranslations';

export default function TextToIdeaPage() {
  const { t } = useTranslation('common');
  const [topic, setTopic] = useState('');
  const [ideas, setIdeas] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerateIdeas = async () => {
    setIsLoading(true);
    setIdeas([]);

    try {
      // ❌ API خارجي لاحقًا
      const mockIdeas = [
        `Idea 1 for: ${topic}`,
        `Idea 2 for: ${topic}`,
        `Idea 3 for: ${topic}`
      ];
      setTimeout(() => {
        setIdeas(mockIdeas);
        setIsLoading(false);
      }, 1500);
    } catch (err) {
      console.error(err);
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-6 text-[var(--neon)]">
        {t('TextToIdea.title')}
      </h1>

      <div className="max-w-2xl space-y-6">
        <input
          type="text"
          className="w-full p-4 rounded-xl bg-zinc-900 text-white"
          placeholder={t('TextToIdea.placeholder')}
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
        />

        <button
          className="bg-[var(--neon)] text-black font-bold px-6 py-3 rounded-xl hover:opacity-80"
          onClick={handleGenerateIdeas}
          disabled={isLoading || !topic}
        >
          {isLoading ? t('TextToIdea.loading') : t('TextToIdea.generate')}
        </button>

        {ideas.length > 0 && (
          <div className="mt-6 bg-zinc-800 p-4 rounded-xl space-y-2">
            <h2 className="text-xl mb-4">{t('TextToIdea.results')}</h2>
            <ul className="list-disc pl-5 text-white/90">
              {ideas.map((idea, index) => (
                <li key={index}>{idea}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </main>
  );
}

export async function getStaticProps({ locale }) {
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common'])),
    },
  };
}
