// UserProfilePage.js - صفحة الملف الشخصي للمستخدم مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const user_profile_page_en = {
  profileTitle: "My Profile",
  name: "Name",
  email: "Email",
  phone: "Phone",
  edit: "Edit Profile",
  save: "Save Changes",
};
export const user_profile_page_ar = {
  profileTitle: "ملفي الشخصي",
  name: "الاسم",
  email: "البريد الإلكتروني",
  phone: "رقم الهاتف",
  edit: "تعديل الملف الشخصي",
  save: "حفظ التعديلات",
};
export const user_profile_page_fr = {
  profileTitle: "Mon profil",
  name: "Nom",
  email: "E-mail",
  phone: "Téléphone",
  edit: "Modifier le profil",
  save: "Enregistrer les modifications",
};
export const user_profile_page_el = {
  profileTitle: "Το προφίλ μου",
  name: "Όνομα",
  email: "Email",
  phone: "Τηλέφωνο",
  edit: "Επεξεργασία προφίλ",
  save: "Αποθήκευση αλλαγών",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: user_profile_page_en,
  ar: user_profile_page_ar,
  fr: user_profile_page_fr,
  el: user_profile_page_el,
};

const initialProfile = {
  name: "Ali Khaled",
  email: "ali@example.com",
  phone: "+201234567890",
};

export default function UserProfilePage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [profile, setProfile] = useState(initialProfile);
  const [editing, setEditing] = useState(false);

  const handleChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };
  const handleSave = () => {
    setEditing(false);
    // TODO: ربط مع API لحفظ التعديلات
  };

  return (
    <main className="min-h-screen bg-black text-white p-6 max-w-xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("profileTitle")}</h1>
      <div className="bg-zinc-900 rounded-2xl shadow-lg p-8">
        <div className="mb-4">
          <label className="block font-semibold mb-1">{t("name")}</label>
          <input type="text" name="name" value={profile.name} onChange={handleChange} disabled={!editing}
                 className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none" />
        </div>
        <div className="mb-4">
          <label className="block font-semibold mb-1">{t("email")}</label>
          <input type="email" name="email" value={profile.email} onChange={handleChange} disabled={!editing}
                 className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none" />
        </div>
        <div className="mb-4">
          <label className="block font-semibold mb-1">{t("phone")}</label>
          <input type="tel" name="phone" value={profile.phone} onChange={handleChange} disabled={!editing}
                 className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none" />
        </div>
        {!editing ? (
          <button onClick={() => setEditing(true)} className="bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-xl mt-4">
            {t("edit")}
          </button>
        ) : (
          <button onClick={handleSave} className="bg-green-700 hover:bg-green-800 text-white px-4 py-2 rounded-xl mt-4">
            {t("save")}
          </button>
        )}
      </div>
    </main>
  );
}
