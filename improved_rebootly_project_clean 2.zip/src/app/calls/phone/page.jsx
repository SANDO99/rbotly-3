// =============================================
// FILE: src/contacts/contactsApi.js
// Description: Handle-based contacts API. Works in two modes:
//  - MOCK (default if VITE_CONTACTS_API is empty): stores data in localStorage
//  - REAL: calls your backend endpoints (see functions below)
// =============================================

const API_BASE = import.meta.env.VITE_CONTACTS_API || ""; // e.g. /api
const MOCK = !API_BASE;
const USER_KEY = "rbotly_current_user";

function getMe() {
  try { const raw = localStorage.getItem(USER_KEY); return raw ? JSON.parse(raw) : null; } catch { return null; }
}

// ---------- MOCK STORAGE LAYOUT ----------
// localStorage keys:
//  rbotly_users = [{ id, handle, displayName, avatarUrl }]
//  rbotly_contacts_<userId> = { friends: [peerId], blocked: [peerId] }
//  rbotly_requests_in_<userId> = [{ id, fromUserId, toUserId, createdAt }]
//  rbotly_requests_out_<userId> = [{ id, fromUserId, toUserId, createdAt }]

function mockRead(key, fallback) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : (fallback ?? null); } catch { return fallback ?? null; }
}
function mockWrite(key, value) { localStorage.setItem(key, JSON.stringify(value)); }

function ensureContactDocs(userId){
  if (!mockRead(`rbotly_contacts_${userId}`)) mockWrite(`rbotly_contacts_${userId}`, { friends: [], blocked: [] });
  if (!mockRead(`rbotly_requests_in_${userId}`)) mockWrite(`rbotly_requests_in_${userId}`, []);
  if (!mockRead(`rbotly_requests_out_${userId}`)) mockWrite(`rbotly_requests_out_${userId}`, []);
}

export async function usersSearchByHandle(query){
  if (!MOCK) {
    const r = await fetch(`${API_BASE}/users/search?q=${encodeURIComponent(query)}`);
    if (!r.ok) throw new Error("search_failed");
    return await r.json(); // [{ id, handle, displayName, avatarUrl, isOnline? }]
  }
  const users = mockRead('rbotly_users', []) || [];
  const q = query.trim().replace(/^@/, '').toLowerCase();
  if (!q) return [];
  return users.filter(u => u.handle.toLowerCase() === q)
    .map(u => ({...u, isOnline: false}));
}

export async function contactsList(){
  const me = getMe(); if (!me) return [];
  if (!MOCK) {
    const r = await fetch(`${API_BASE}/contacts`, { headers: { 'Authorization': `Bearer ${me.token||''}` }});
    if (!r.ok) throw new Error('contacts_failed');
    return await r.json(); // [{ peerId, handle, displayName, avatarUrl, isOnline }]
  }
  ensureContactDocs(me.id);
  const doc = mockRead(`rbotly_contacts_${me.id}`, { friends: [] });
  const users = mockRead('rbotly_users', []) || [];
  return (doc.friends||[]).map(pid => users.find(u=>u.id===pid)).filter(Boolean).map(u => ({...u, peerId: u.id, isOnline: false}));
}

export async function requestsInbox(){
  const me = getMe(); if (!me) return [];
  if (!MOCK) {
    const r = await fetch(`${API_BASE}/contacts/requests?box=inbox`, { headers: { 'Authorization': `Bearer ${me.token||''}` }});
    if (!r.ok) throw new Error('inbox_failed');
    return await r.json(); // [{ id, fromUser: { id, handle, displayName, avatarUrl }, createdAt }]
  }
  ensureContactDocs(me.id);
  const raw = mockRead(`rbotly_requests_in_${me.id}`, []);
  const users = mockRead('rbotly_users', []) || [];
  return raw.map(r => ({ id: r.id, fromUser: users.find(u=>u.id===r.fromUserId), createdAt: r.createdAt })).filter(x=>x.fromUser);
}

export async function requestsOutbox(){
  const me = getMe(); if (!me) return [];
  if (!MOCK) {
    const r = await fetch(`${API_BASE}/contacts/requests?box=outbox`, { headers: { 'Authorization': `Bearer ${me.token||''}` }});
    if (!r.ok) throw new Error('outbox_failed');
    return await r.json(); // [{ id, toUser: {...}, createdAt }]
  }
  ensureContactDocs(me.id);
  const raw = mockRead(`rbotly_requests_out_${me.id}`, []);
  const users = mockRead('rbotly_users', []) || [];
  return raw.map(r => ({ id: r.id, toUser: users.find(u=>u.id===r.toUserId), createdAt: r.createdAt })).filter(x=>x.toUser);
}

export async function contactsSendRequest(toHandle){
  const me = getMe(); if (!me) throw new Error('no_user');
  if (!MOCK) {
    const r = await fetch(`${API_BASE}/contacts/request`, { method: 'POST', headers: { 'Content-Type':'application/json', 'Authorization': `Bearer ${me.token||''}` }, body: JSON.stringify({ toHandle }) });
    if (!r.ok) throw new Error('request_failed');
    return await r.json(); // { requestId }
  }
  // MOCK
  const users = mockRead('rbotly_users', []) || [];
  const handle = toHandle.trim().replace(/^@/, '').toLowerCase();
  const target = users.find(u => u.handle.toLowerCase() === handle);
  if (!target) throw new Error('not_found');
  if (target.id === me.id) throw new Error('self');
  ensureContactDocs(me.id); ensureContactDocs(target.id);
  const out = mockRead(`rbotly_requests_out_${me.id}`, []);
  const inb = mockRead(`rbotly_requests_in_${target.id}`, []);
  const already = out.find(r => r.toUserId===target.id);
  if (already) throw new Error('already_requested');
  const id = `req_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  out.push({ id, fromUserId: me.id, toUserId: target.id, createdAt: Date.now() });
  inb.push({ id, fromUserId: me.id, toUserId: target.id, createdAt: Date.now() });
  mockWrite(`rbotly_requests_out_${me.id}`, out);
  mockWrite(`rbotly_requests_in_${target.id}`, inb);
  return { requestId: id };
}

export async function contactsAcceptRequest(id){
  const me = getMe(); if (!me) throw new Error('no_user');
  if (!MOCK) {
    const r = await fetch(`${API_BASE}/contacts/requests/${id}/accept`, { method: 'POST', headers: { 'Authorization': `Bearer ${me.token||''}` }});
    if (!r.ok) throw new Error('accept_failed');
    return await r.json();
  }
  // MOCK
  const inbox = mockRead(`rbotly_requests_in_${me.id}`, []);
  const req = inbox.find(r => r.id===id); if (!req) throw new Error('not_found');
  // remove request both sides
  mockWrite(`rbotly_requests_in_${me.id}`, inbox.filter(r=>r.id!==id));
  const outOther = mockRead(`rbotly_requests_out_${req.fromUserId}`, []);
  mockWrite(`rbotly_requests_out_${req.fromUserId}`, outOther.filter(r=>r.id!==id));
  // add friends both ways
  const myC = mockRead(`rbotly_contacts_${me.id}`, { friends: [] });
  const hisC = mockRead(`rbotly_contacts_${req.fromUserId}`, { friends: [] });
  if (!myC.friends.includes(req.fromUserId)) myC.friends.push(req.fromUserId);
  if (!hisC.friends.includes(me.id)) hisC.friends.push(me.id);
  mockWrite(`rbotly_contacts_${me.id}`, myC);
  mockWrite(`rbotly_contacts_${req.fromUserId}`, hisC);
  return { ok: true };
}

export async function contactsDeclineRequest(id){
  const me = getMe(); if (!me) throw new Error('no_user');
  if (!MOCK) {
    const r = await fetch(`${API_BASE}/contacts/requests/${id}/decline`, { method: 'POST', headers: { 'Authorization': `Bearer ${me.token||''}` }});
    if (!r.ok) throw new Error('decline_failed');
    return await r.json();
  }
  const inbox = mockRead(`rbotly_requests_in_${me.id}`, []);
  const req = inbox.find(r => r.id===id); if (!req) throw new Error('not_found');
  mockWrite(`rbotly_requests_in_${me.id}`, inbox.filter(r=>r.id!==id));
  const outOther = mockRead(`rbotly_requests_out_${req.fromUserId}`, []);
  mockWrite(`rbotly_requests_out_${req.fromUserId}`, outOther.filter(r=>r.id!==id));
  return { ok: true };
}

export async function contactsRemove(peerId){
  const me = getMe(); if (!me) throw new Error('no_user');
  if (!MOCK) {
    const r = await fetch(`${API_BASE}/contacts/${peerId}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${me.token||''}` }});
    if (!r.ok) throw new Error('remove_failed');
    return await r.json();
  }
  const myC = mockRead(`rbotly_contacts_${me.id}`, { friends: [] });
  const hisC = mockRead(`rbotly_contacts_${peerId}`, { friends: [] });
  myC.friends = (myC.friends||[]).filter(id => id!==peerId);
  hisC.friends = (hisC.friends||[]).filter(id => id!==me.id);
  mockWrite(`rbotly_contacts_${me.id}`, myC);
  mockWrite(`rbotly_contacts_${peerId}`, hisC);
  return { ok: true };
}

// =============================================
// FILE: src/contacts/mockSeed.js
// Description: Seed a tiny mock user registry for local testing.
// =============================================

export function seedMockUsers(){
  const users = JSON.parse(localStorage.getItem('rbotly_users')||'[]');
  if (users && users.length) return; // already seeded
  const now = Date.now();
  const demo = [
    { id:'u1', handle:'alice', displayName:'Alice', avatarUrl:'' },
    { id:'u2', handle:'bob', displayName:'Bob', avatarUrl:'' },
    { id:'u3', handle:'charlie', displayName:'Charlie', avatarUrl:'' },
  ];
  localStorage.setItem('rbotly_users', JSON.stringify(demo));
  demo.forEach(u => {
    localStorage.setItem(`rbotly_contacts_${u.id}`, JSON.stringify({ friends: [], blocked: [] }));
    localStorage.setItem(`rbotly_requests_in_${u.id}`, JSON.stringify([]));
    localStorage.setItem(`rbotly_requests_out_${u.id}`, JSON.stringify([]));
  });
  // also set a default current user if none
  if (!localStorage.getItem('rbotly_current_user')) {
    localStorage.setItem('rbotly_current_user', JSON.stringify({ id:'u1', name:'Alice', token:'dev' }));
  }
}

// =============================================
// FILE: src/contacts/PhoneTab.jsx
// Description: Messenger-like Phone tab (Add by @handle, Requests in/out, Friends list)
// =============================================

import React, { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { contactsAcceptRequest, contactsDeclineRequest, contactsList, contactsRemove, contactsSendRequest, requestsInbox, requestsOutbox, usersSearchByHandle } from './contactsApi';
import CallButton from '@/call/components/CallButton';
import { useCall } from '@/call/CallContext';

function Section({ title, children }){
  return (
    <section className="rounded-2xl border border-cyan-300/30 bg-black/30 p-4">
      <div className="mb-3 text-sm font-bold text-cyan-100">{title}</div>
      {children}
    </section>
  );
}

export default function PhoneTab(){
  const { t } = useTranslation();
  const { online } = useCall();

  const [q, setQ] = useState('');
  const [searchRes, setSearchRes] = useState([]);

  const [inbox, setInbox] = useState([]);
  const [outbox, setOutbox] = useState([]);
  const [friends, setFriends] = useState([]);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');

  async function refreshAll(){
    setLoading(true);
    try {
      const [i,o,f] = await Promise.all([requestsInbox(), requestsOutbox(), contactsList()]);
      setInbox(i); setOutbox(o); setFriends(f);
    } finally { setLoading(false); }
  }

  useEffect(()=>{ refreshAll(); }, []);

  async function onSearch(){
    setMsg(''); setSearchRes([]);
    try {
      const res = await usersSearchByHandle(q);
      setSearchRes(res);
      if (!res.length) setMsg(t('HANDLE_NOT_FOUND','Handle not found'));
    } catch (e){ setMsg(t('SEARCH_FAILED','Search failed')); }
  }

  async function sendRequest(handle){
    setMsg('');
    try { await contactsSendRequest(handle); setMsg(t('REQUEST_SENT','Request sent')); await refreshAll(); }
    catch(e){ setMsg(e.message || 'Error'); }
  }

  async function accept(id){ await contactsAcceptRequest(id); await refreshAll(); }
  async function decline(id){ await contactsDeclineRequest(id); await refreshAll(); }
  async function removeFriend(peerId){ await contactsRemove(peerId); await refreshAll(); }

  const sortedFriends = useMemo(() => {
    return [...friends].sort((a,b)=> (online[b.peerId]?1:0) - (online[a.peerId]?1:0) || a.displayName.localeCompare(b.displayName));
  }, [friends, online]);

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
      {/* Add by handle */}
      <Section title={t('ADD_BY_HANDLE','Add by handle')}>
        <div className="flex items-center gap-2">
          <input value={q} onChange={(e)=> setQ(e.target.value)} placeholder={t('ENTER_HANDLE','Enter @handle')}
                 className="flex-1 rounded-lg border border-cyan-300/30 bg-black/30 px-3 py-2 text-sm text-cyan-50 placeholder-cyan-300/60" />
          <button onClick={onSearch} className="rounded-lg border border-cyan-300/40 px-3 py-2 text-xs text-cyan-100 hover:bg-cyan-500/10">{t('SEARCH','Search')}</button>
        </div>
        {!!msg && <div className="mt-2 text-[11px] text-cyan-300/70">{msg}</div>}
        {searchRes.length>0 && (
          <div className="mt-3 space-y-2">
            {searchRes.map(u => (
              <div key={u.id} className="flex items-center justify-between rounded-lg border border-cyan-300/20 bg-black/20 px-3 py-2">
                <div>
                  <div className="text-sm font-semibold text-cyan-100">@{u.handle}</div>
                  <div className="text-xs text-cyan-300/70">{u.displayName}</div>
                </div>
                <button onClick={()=>sendRequest(u.handle)} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10">{t('SEND_REQUEST','Send request')}</button>
              </div>
            ))}
          </div>
        )}
      </Section>

      {/* Inbox requests */}
      <Section title={t('INCOMING_REQUESTS','Incoming requests')}>
        {loading && !inbox.length ? <div className="text-xs text-cyan-300/70">{t('LOADING','Loading…')}</div> : null}
        {inbox.length===0 && !loading ? <div className="text-xs text-cyan-300/70">{t('EMPTY','Empty')}</div> : null}
        <div className="space-y-2">
          {inbox.map(r => (
            <div key={r.id} className="flex items-center justify-between rounded-lg border border-cyan-300/20 bg-black/20 px-3 py-2">
              <div>
                <div className="text-sm font-semibold text-cyan-100">@{r.fromUser.handle}</div>
                <div className="text-xs text-cyan-300/70">{r.fromUser.displayName}</div>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={()=>accept(r.id)} className="rounded-lg border border-emerald-400/40 bg-emerald-400/10 px-3 py-1.5 text-xs text-emerald-200 hover:bg-emerald-400/20">{t('ACCEPT','Accept')}</button>
                <button onClick={()=>decline(r.id)} className="rounded-lg border border-rose-400/40 bg-rose-400/10 px-3 py-1.5 text-xs text-rose-200 hover:bg-rose-400/20">{t('DECLINE','Decline')}</button>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* Outbox requests */}
      <Section title={t('OUTGOING_REQUESTS','Outgoing requests')}>
        {loading && !outbox.length ? <div className="text-xs text-cyan-300/70">{t('LOADING','Loading…')}</div> : null}
        {outbox.length===0 && !loading ? <div className="text-xs text-cyan-300/70">{t('EMPTY','Empty')}</div> : null}
        <div className="space-y-2">
          {outbox.map(r => (
            <div key={r.id} className="flex items-center justify-between rounded-lg border border-cyan-300/20 bg-black/20 px-3 py-2">
              <div>
                <div className="text-sm font-semibold text-cyan-100">@{r.toUser.handle}</div>
                <div className="text-xs text-cyan-300/70">{r.toUser.displayName}</div>
              </div>
              <div className="text-[11px] text-cyan-300/70">{t('PENDING','Pending')}</div>
            </div>
          ))}
        </div>
      </Section>

      {/* Friends list */}
      <Section title={t('FRIENDS','Friends')}>
        {loading && !friends.length ? <div className="text-xs text-cyan-300/70">{t('LOADING','Loading…')}</div> : null}
        {friends.length===0 && !loading ? <div className="text-xs text-cyan-300/70">{t('EMPTY','Empty')}</div> : null}
        <div className="space-y-2">
          {sortedFriends.map(f => (
            <div key={f.peerId} className="flex items-center justify-between rounded-lg border border-cyan-300/20 bg-black/20 px-3 py-2">
              <div>
                <div className="text-sm font-semibold text-cyan-100">@{f.handle || f.displayName?.toLowerCase?.() || 'user'}</div>
                <div className="text-xs text-cyan-300/70">{f.displayName} • {online[f.peerId] ? t('ONLINE','Online') : t('OFFLINE','Offline')}</div>
              </div>
              <div className="flex items-center gap-2">
                <CallButton toUserId={f.peerId} withVideo={true} />
                <CallButton toUserId={f.peerId} withVideo={false} />
                <button onClick={()=>removeFriend(f.peerId)} className="rounded-lg border border-rose-400/40 bg-rose-400/10 px-3 py-1.5 text-xs text-rose-200 hover:bg-rose-400/20">{t('REMOVE_FRIEND','Remove')}</button>
              </div>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
}

// =============================================
// FILE: src/call/CallPage.jsx (UPDATED)
// Replace the previous content of CallPage.jsx with the following to include PhoneTab
// =============================================

import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { CallProvider } from './CallContext';
import IncomingCallOverlay from './components/IncomingCallOverlay';
import CallHUD from './components/CallHUD';
import PhoneBridgeButton from './components/PhoneBridgeButton';
import TranslationPanel from './TranslationPanel';
import PhoneTab from '@/contacts/PhoneTab';
import { seedMockUsers } from '@/contacts/mockSeed';

export default function CallPage(){
  const { t } = useTranslation();
  useEffect(()=>{ seedMockUsers(); }, []);
  return (
    <CallProvider>
      <div className="min-h-screen bg-[#05060a] px-4 py-6 text-cyan-50">
        <div className="mx-auto grid max-w-7xl gap-4 md:grid-cols-3">
          {/* LEFT: Phone tab */}
          <section className="md:col-span-2">
            <PhoneTab />
          </section>
          {/* RIGHT: Translation controls + Phone bridge */}
          <section className="flex flex-col gap-4">
            <TranslationPanel />
            <div className="rounded-2xl border border-cyan-300/30 bg-black/30 p-4">
              <div className="mb-2 text-sm font-bold text-cyan-100">{t('PHONE_BRIDGE','Phone bridge')}</div>
              <PhoneBridgeButton />
              <div className="mt-2 text-[11px] text-cyan-300/70">{t('PHONE_BRIDGE_HINT','Invite people without internet by phone number + PIN.')}</div>
            </div>
          </section>
        </div>

        <IncomingCallOverlay />
        <CallHUD />
      </div>
    </CallProvider>
  );
}

// =============================================
// FILE: src/i18n/messages_en.phone.js
// =============================================
export default {
  ADD_BY_HANDLE: "Add by handle",
  ENTER_HANDLE: "Enter @handle",
  SEARCH: "Search",
  SEND_REQUEST: "Send request",
  REQUEST_SENT: "Request sent",
  INCOMING_REQUESTS: "Incoming requests",
  OUTGOING_REQUESTS: "Outgoing requests",
  FRIENDS: "Friends",
  ACCEPT: "Accept",
  DECLINE: "Decline",
  PENDING: "Pending",
  REMOVE_FRIEND: "Remove",
  HANDLE_NOT_FOUND: "Handle not found",
  SEARCH_FAILED: "Search failed",
  LOADING: "Loading…",
  EMPTY: "Empty",
  ONLINE: "Online",
  OFFLINE: "Offline",
  PHONE_BRIDGE: "Phone bridge",
  PHONE_BRIDGE_HINT: "Invite people without internet by phone number + PIN.",
};

// =============================================
// FILE: src/i18n/messages_ar.phone.js
// =============================================
export default {
  ADD_BY_HANDLE: "إضافة عبر الـHandle",
  ENTER_HANDLE: "أدخل ‎@handle",
  SEARCH: "بحث",
  SEND_REQUEST: "إرسال طلب",
  REQUEST_SENT: "تم إرسال الطلب",
  INCOMING_REQUESTS: "طلبات واردة",
  OUTGOING_REQUESTS: "طلبات صادرة",
  FRIENDS: "الأصدقاء",
  ACCEPT: "قبول",
  DECLINE: "رفض",
  PENDING: "قيد الانتظار",
  REMOVE_FRIEND: "إزالة",
  HANDLE_NOT_FOUND: "الـHandle غير موجود",
  SEARCH_FAILED: "فشل البحث",
  LOADING: "جارٍ التحميل…",
  EMPTY: "فارغ",
  ONLINE: "متصل",
  OFFLINE: "غير متصل",
  PHONE_BRIDGE: "جسر هاتفي",
  PHONE_BRIDGE_HINT: "ادعُ أشخاصًا بلا إنترنت عبر رقم هاتف + PIN.",
};

// =============================================
// FILE: src/i18n/messages_fr.phone.js
// =============================================
export default {
  ADD_BY_HANDLE: "Ajouter par handle",
  ENTER_HANDLE: "Saisir @handle",
  SEARCH: "Rechercher",
  SEND_REQUEST: "Envoyer la demande",
  REQUEST_SENT: "Demande envoyée",
  INCOMING_REQUESTS: "Demandes entrantes",
  OUTGOING_REQUESTS: "Demandes sortantes",
  FRIENDS: "Amis",
  ACCEPT: "Accepter",
  DECLINE: "Refuser",
  PENDING: "En attente",
  REMOVE_FRIEND: "Supprimer",
  HANDLE_NOT_FOUND: "Handle introuvable",
  SEARCH_FAILED: "Échec de la recherche",
  LOADING: "Chargement…",
  EMPTY: "Vide",
  ONLINE: "En ligne",
  OFFLINE: "Hors ligne",
  PHONE_BRIDGE: "Passerelle téléphonique",
  PHONE_BRIDGE_HINT: "Invitez des personnes sans Internet via un numéro + PIN.",
};

// =============================================
// FILE: src/i18n/messages_el.phone.js
// =============================================
export default {
  ADD_BY_HANDLE: "Προσθήκη με handle",
  ENTER_HANDLE: "Εισάγετε @handle",
  SEARCH: "Αναζήτηση",
  SEND_REQUEST: "Αποστολή αιτήματος",
  REQUEST_SENT: "Το αίτημα στάλθηκε",
  INCOMING_REQUESTS: "Εισερχόμενα αιτήματα",
  OUTGOING_REQUESTS: "Εξερχόμενα αιτήματα",
  FRIENDS: "Φίλοι",
  ACCEPT: "Αποδοχή",
  DECLINE: "Απόρριψη",
  PENDING: "Σε εκκρεμότητα",
  REMOVE_FRIEND: "Κατάργηση",
  HANDLE_NOT_FOUND: "Το handle δεν βρέθηκε",
  SEARCH_FAILED: "Αποτυχία αναζήτησης",
  LOADING: "Φόρτωση…",
  EMPTY: "Κενό",
  ONLINE: "Σε σύνδεση",
  OFFLINE: "Εκτός σύνδεσης",
  PHONE_BRIDGE: "Γέφυρα τηλεφώνου",
  PHONE_BRIDGE_HINT: "Προσκαλέστε άτομα χωρίς Internet μέσω αριθμού + PIN.",
};
