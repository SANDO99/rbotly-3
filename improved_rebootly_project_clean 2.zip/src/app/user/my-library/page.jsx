// my_library_page.jsx
export const my_library_page_en = {
  myLibraryTitle: "My Library",
  nftBots: "NFT Bots",
  voices: "Voices",
  addons: "Add-ons",
  noItems: "No items found",
  open: "Open",
  download: "Download",
  delete: "Delete",
};
export const my_library_page_ar = {
  myLibraryTitle: "مكتبتي",
  nftBots: "بوتات NFT",
  voices: "الأصوات",
  addons: "الإضافات",
  noItems: "لم يتم العثور على عناصر",
  open: "فتح",
  download: "تنزيل",
  delete: "حذف",
};
export const my_library_page_fr = {
  myLibraryTitle: "Ma bibliothèque",
  nftBots: "Bots NFT",
  voices: "Voix",
  addons: "Add-ons",
  noItems: "Aucun élément trouvé",
  open: "Ouvrir",
  download: "Télécharger",
  delete: "Supprimer",
};
export const my_library_page_el = {
  myLibraryTitle: "Η βιβλιοθήκη μου",
  nftBots: "NFT Bots",
  voices: "Φωνές",
  addons: "Πρόσθετα",
  noItems: "Δεν βρέθηκαν στοιχεία",
  open: "Άνοιγμα",
  download: "Λήψη",
  delete: "Διαγραφή",
};

import { useState } from "react";

const translations = {
  en: my_library_page_en,
  ar: my_library_page_ar,
  fr: my_library_page_fr,
  el: my_library_page_el,
};

const mockItems = {
  bots: [
    { id: 1, name: "Mixtral NFT Bot", img: "/img/nft1.png" },
    { id: 2, name: "EduBotX", img: "/img/bot1.png" },
  ],
  voices: [
    { id: 1, name: "Arabic Male Voice", img: "/img/voice1.png" },
    { id: 2, name: "French Female Voice", img: "/img/voice2.png" },
  ],
  addons: [
    { id: 1, name: "Multi-Language Pack", img: "/img/addon1.png" },
    { id: 2, name: "Advanced Analytics", img: "/img/addon2.png" },
  ],
};

export default function MyLibraryPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [activeTab, setActiveTab] = useState("bots");
  
  const items = mockItems[activeTab] || [];

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-6 text-[var(--neon)]">{t("myLibraryTitle")}</h1>
      
      {/* التبويبات */}
      <div className="flex border-b border-zinc-700 mb-6">
        <button
          onClick={() => setActiveTab("bots")}
          className={`px-4 py-2 font-medium ${activeTab === "bots" ? "border-b-2 border-[var(--neon)] text-[var(--neon)]" : "text-gray-400"}`}
        >
          {t("nftBots")}
        </button>
        <button
          onClick={() => setActiveTab("voices")}
          className={`px-4 py-2 font-medium ${activeTab === "voices" ? "border-b-2 border-[var(--neon)] text-[var(--neon)]" : "text-gray-400"}`}
        >
          {t("voices")}
        </button>
        <button
          onClick={() => setActiveTab("addons")}
          className={`px-4 py-2 font-medium ${activeTab === "addons" ? "border-b-2 border-[var(--neon)] text-[var(--neon)]" : "text-gray-400"}`}
        >
          {t("addons")}
        </button>
      </div>
      
      {/* محتوى التبويب */}
      {items.length === 0 ? (
        <div className="text-center text-gray-400 text-xl py-16">{t("noItems")}</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map(item => (
            <div key={item.id} className="bg-zinc-900 rounded-2xl shadow-lg overflow-hidden flex flex-col">
              <div className="h-48 bg-zinc-800 flex items-center justify-center">
                <img src={item.img} alt={item.name} className="max-h-40 max-w-full" />
              </div>
              <div className="p-4 flex-1 flex flex-col">
                <div className="font-bold text-lg mb-3">{item.name}</div>
                <div className="flex gap-2 mt-auto">
                  <button className="bg-blue-700 hover:bg-blue-800 text-white px-3 py-1 rounded-xl flex-1">
                    {t("open")}
                  </button>
                  <button className="bg-green-700 hover:bg-green-800 text-white px-3 py-1 rounded-xl flex-1">
                    {t("download")}
                  </button>
                  <button className="bg-red-700 hover:bg-red-800 text-white px-3 py-1 rounded-xl">
                    {t("delete")}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}