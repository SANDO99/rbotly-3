"use client";
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'next-i18next';
import { serverSideTranslations } from 'next-i18next/serverSideTranslations';

/**
 * Job Search Page
 *
 * This page lists available jobs fetched from an external API (mocked here).
 * Users can search by title, company or keyword.  In the future this page
 * could integrate with the Botly assistant to help users find jobs.
 */

export default function JobsSearchPage() {
  const { t } = useTranslation('common');
  const [query, setQuery] = useState('');
  const [jobs, setJobs] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch jobs from a mock API.  Replace with real fetch when available.
  useEffect(() => {
    const mockJobs = [
      {
        id: 1,
        title: 'Frontend Developer',
        company: 'Creative Apps',
        location: 'Remote',
        description: 'Work on modern web applications using React and Next.js.',
      },
      {
        id: 2,
        title: 'AI Researcher',
        company: 'DeepTech',
        location: 'Athens, GR',
        description: 'Research and build AI models for language and vision.',
      },
      {
        id: 3,
        title: 'Customer Support Specialist',
        company: 'Global Services',
        location: 'Remote',
        description: 'Assist customers via chat and email using our AI tools.',
      },
    ];
    setJobs(mockJobs);
    setFiltered(mockJobs);
    setLoading(false);
  }, []);

  // Filter jobs based on query
  useEffect(() => {
    const q = query.toLowerCase();
    if (!q) {
      setFiltered(jobs);
    } else {
      setFiltered(
        jobs.filter(
          (job) =>
            job.title.toLowerCase().includes(q) ||
            job.company.toLowerCase().includes(q) ||
            job.location.toLowerCase().includes(q) ||
            job.description.toLowerCase().includes(q)
        )
      );
    }
  }, [query, jobs]);

  return (
    <main className="min-h-screen bg-black text-white p-4 md:p-8 space-y-8">
      <header className="space-y-2">
        <h1 className="text-3xl font-bold text-[var(--neon)]">{t('jobs.title')}</h1>
        <p className="text-gray-400">{t('jobs.desc')}</p>
        <p className="text-xs text-gray-500 italic">{t('jobs.aiTip')}</p>
      </header>
      <div className="flex flex-col gap-4">
        <input
          type="text"
          placeholder={t('jobs.searchPlaceholder')}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="px-4 py-2 rounded-lg bg-zinc-800 text-white placeholder-gray-500 focus:outline-none"
        />
        {loading ? (
          <p className="text-gray-500 italic">{t('jobs.loading')}</p>
        ) : filtered.length === 0 ? (
          <p className="text-gray-500 italic">{t('jobs.noResults')}</p>
        ) : (
          <div className="grid gap-4">
            {filtered.map((job) => (
              <div key={job.id} className="border border-gray-700 rounded-lg p-4 bg-zinc-900 space-y-2">
                <h2 className="text-xl font-semibold text-[var(--neon)]">{job.title}</h2>
                <p className="text-sm text-gray-400">{job.company} — {job.location}</p>
                <p className="text-sm text-gray-400">{job.description}</p>
                <button
                  className="mt-2 px-4 py-2 bg-[var(--neon)] text-black rounded-lg font-semibold hover:opacity-80"
                  onClick={() => {
                    // In a real app this would link to a detailed view or external application page
                    alert(t('jobs.applyBtn'));
                  }}
                >
                  {t('jobs.applyBtn')}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}

export async function getStaticProps({ locale }) {
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common'])),
    },
  };
}