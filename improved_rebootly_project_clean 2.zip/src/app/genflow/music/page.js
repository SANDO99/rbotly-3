import { useState } from 'react';
import { useTranslation } from 'next-i18next';
import { serverSideTranslations } from 'next-i18next/serverSideTranslations';

export default function TextToMusicPage() {
  const { t } = useTranslation('common');
  const [description, setDescription] = useState('');
  const [musicUrl, setMusicUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [genre, setGenre] = useState('ambient');

  const handleGenerateMusic = async () => {
    setIsLoading(true);
    setMusicUrl('');

    try {
      // ❌ الربط الحقيقي بـ API لاحقًا
      const mockMusic = 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3';
      setTimeout(() => {
        setMusicUrl(mockMusic);
        setIsLoading(false);
      }, 2000);
    } catch (err) {
      console.error(err);
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-6 text-[var(--neon)]">
        {t('TextToMusic.title')}
      </h1>

      <div className="max-w-2xl space-y-6">
        <textarea
          className="w-full p-4 rounded-xl bg-zinc-900 text-white"
          rows={4}
          placeholder={t('TextToMusic.placeholder')}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />

        <div>
          <label className="block mb-2 text-white/70">{t('TextToMusic.genreLabel')}</label>
          <select
            className="w-full p-3 rounded-xl bg-zinc-900 text-white"
            value={genre}
            onChange={(e) => setGenre(e.target.value)}
          >
            <option value="ambient">{t('TextToMusic.genres.ambient')}</option>
            <option value="cinematic">{t('TextToMusic.genres.cinematic')}</option>
            <option value="electronic">{t('TextToMusic.genres.electronic')}</option>
          </select>
        </div>

        <button
          className="bg-[var(--neon)] text-black font-bold px-6 py-3 rounded-xl hover:opacity-80"
          onClick={handleGenerateMusic}
          disabled={isLoading || !description}
        >
          {isLoading ? t('TextToMusic.loading') : t('TextToMusic.generate')}
        </button>

        {musicUrl && (
          <div className="mt-6">
            <h2 className="text-xl mb-4">{t('TextToMusic.preview')}</h2>
            <audio controls className="w-full">
              <source src={musicUrl} type="audio/mpeg" />
              Your browser does not support the audio element.
            </audio>
          </div>
        )}
      </div>
    </main>
  );
}

export async function getStaticProps({ locale }) {
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common'])),
    },
  };
}
