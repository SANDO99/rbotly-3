// AdminNFTBotsReviewPage.js - مراجعة بوتات NFT (Canva)
// مع دعم الترجمة الرباعية EN, AR, FR, EL

import { useState } from "react";
import { admin_nftbots_review_en } from "./admin_nftbots_review_en";
import { admin_nftbots_review_ar } from "./admin_nftbots_review_ar";
import { admin_nftbots_review_fr } from "./admin_nftbots_review_fr";
import { admin_nftbots_review_el } from "./admin_nftbots_review_el";

const translations = {
  en: admin_nftbots_review_en,
  ar: admin_nftbots_review_ar,
  fr: admin_nftbots_review_fr,
  el: admin_nftbots_review_el,
};

// بيانات وهمية لبوتات NFT
const mockNFTBots = [
  { id: 1, name: "EduBotX", owner: "ahmed@example.com", status: "pending", type: "kids" },
  { id: 2, name: "MedBot Pro", owner: "sara@example.com", status: "approved", type: "medical" },
  { id: 3, name: "ArtBot Mini", owner: "lucas@example.com", status: "rejected", type: "art" },
];

export default function AdminNFTBotsReviewPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [bots, setBots] = useState(mockNFTBots);

  // أماكن الربط مع API لاعتماد أو رفض البوت مستقبلاً
  const handleApprove = (id) => {
    // TODO: ربط مع API لاعتماد البوت
    setBots(bots.map(b => b.id === id ? { ...b, status: "approved" } : b));
  };
  const handleReject = (id) => {
    // TODO: ربط مع API لرفض البوت
    setBots(bots.map(b => b.id === id ? { ...b, status: "rejected" } : b));
  };

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("nftbotsReviewTitle")}</h1>
      <table className="w-full table-auto text-left border">
        <thead>
          <tr className="bg-zinc-900">
            <th className="p-2 border">#</th>
            <th className="p-2 border">{t("name")}</th>
            <th className="p-2 border">{t("type")}</th>
            <th className="p-2 border">{t("owner")}</th>
            <th className="p-2 border">{t("status")}</th>
            <th className="p-2 border">{t("actions")}</th>
          </tr>
        </thead>
        <tbody>
          {bots.map((b, i) => (
            <tr key={b.id} className="border-t">
              <td className="p-2 border">{i + 1}</td>
              <td className="p-2 border">{b.name}</td>
              <td className="p-2 border">{t(b.type)}</td>
              <td className="p-2 border">{b.owner}</td>
              <td className="p-2 border">
                <span className={
                  b.status === "approved" ? "text-green-400" :
                  b.status === "pending" ? "text-yellow-400" : "text-red-400"
                }>
                  {t(b.status)}
                </span>
              </td>
              <td className="p-2 border flex gap-2">
                {b.status !== "approved" && (
                  <button onClick={() => handleApprove(b.id)} className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded">
                    {t("approve")}
                  </button>
                )}
                {b.status !== "rejected" && (
                  <button onClick={() => handleReject(b.id)} className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded">
                    {t("reject")}
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}

// ----------- ملفات الترجمة الأربعة (مثال) -----------
// admin_nftbots_review_en.js
export const admin_nftbots_review_en = {
  nftbotsReviewTitle: "NFT Bots Review",
  name: "Name",
  type: "Type",
  kids: "For Kids",
  medical: "Medical",
  art: "Art",
  owner: "Owner",
  status: "Status",
  approved: "Approved",
  pending: "Pending",
  rejected: "Rejected",
  actions: "Actions",
  approve: "Approve",
  reject: "Reject",
};
// admin_nftbots_review_ar.js
export const admin_nftbots_review_ar = {
  nftbotsReviewTitle: "مراجعة بوتات NFT",
  name: "الاسم",
  type: "النوع",
  kids: "للأطفال",
  medical: "طبي",
  art: "فن",
  owner: "المالك",
  status: "الحالة",
  approved: "معتمد",
  pending: "بانتظار المراجعة",
  rejected: "مرفوض",
  actions: "إجراءات",
  approve: "اعتماد",
  reject: "رفض",
};
// admin_nftbots_review_fr.js
export const admin_nftbots_review_fr = {
  nftbotsReviewTitle: "Revue des Bots NFT",
  name: "Nom",
  type: "Type",
  kids: "Enfants",
  medical: "Médical",
  art: "Art",
  owner: "Propriétaire",
  status: "Statut",
  approved: "Approuvé",
  pending: "En attente",
  rejected: "Rejeté",
  actions: "Actions",
  approve: "Approuver",
  reject: "Rejeter",
};
// admin_nftbots_review_el.js
export const admin_nftbots_review_el = {
  nftbotsReviewTitle: "Αξιολόγηση NFT Bots",
  name: "Όνομα",
  type: "Τύπος",
  kids: "Παιδικό",
  medical: "Ιατρικό",
  art: "Τέχνη",
  owner: "Ιδιοκτήτης",
  status: "Κατάσταση",
  approved: "Εγκρίθηκε",
  pending: "Σε αναμονή",
  rejected: "Απορρίφθηκε",
  actions: "Ενέργειες",
  approve: "Έγκριση",
  reject: "Απόρριψη",
};
