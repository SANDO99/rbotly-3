// ===============================
// FILE: src/call/utils/iceServers.js
// ===============================
export function getIceServers() {
  const stun = { urls: ["stun:stun.l.google.com:19302"] };
  const turnUrl = import.meta.env.VITE_TURN_URL || "";   // e.g. turns:turn.your-domain.com:5349
  const turnUser = import.meta.env.VITE_TURN_USER || "";
  const turnPass = import.meta.env.VITE_TURN_CRED || "";
  const list = [stun];
  if (turnUrl && turnUser && turnPass) {
    list.push({ urls: [turnUrl], username: turnUser, credential: turnPass });
  }
  return list;
}

// ===============================
// FILE: src/call/CallContext.jsx
// ===============================
import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from "react";
import { getIceServers } from "./utils/iceServers";

const Ctx = createContext(null);
const WS_URL = import.meta.env.VITE_CALL_WS_URL || "ws://localhost:8080"; // signaling
const USER_KEY = "rbotly_current_user";

function getUser() {
  try { const raw = localStorage.getItem(USER_KEY); if (raw) return JSON.parse(raw); } catch {}
  return null;
}

export function CallProvider({ children }) {
  const [ws, setWs] = useState(null);
  const [online, setOnline] = useState({}); // { userId: true }
  const [incoming, setIncoming] = useState(null); // { fromUserId, callId }
  const [active, setActive] = useState(null); // { callId, peerUserId }

  const [muted, setMuted] = useState(false);
  const [camOff, setCamOff] = useState(true);

  const pcRef = useRef(null);
  const localStreamRef = useRef(null);
  const remoteStreamRef = useRef(null);
  const remoteAudioRef = useRef(null); // <audio>
  const remoteVideoRef = useRef(null); // <video>
  const localVideoRef = useRef(null);  // <video>

  // connect signaling WS
  useEffect(() => {
    const u = getUser();
    const sock = new WebSocket(WS_URL);
    sock.onopen = () => {
      sock.send(JSON.stringify({ type: "auth", token: u?.token || "", userId: u?.id || "" }));
    };
    sock.onmessage = async (ev) => {
      const msg = JSON.parse(ev.data || "{}");
      switch (msg.type) {
        case "presence":
          setOnline(msg.online || {});
          break;
        case "call:invite":
          setIncoming({ fromUserId: msg.fromUserId, callId: msg.callId });
          break;
        case "call:decline":
        case "call:busy":
        case "call:end":
          cleanupCall();
          break;
        case "webrtc:offer": {
          await ensurePC();
          await pcRef.current.setRemoteDescription(new RTCSessionDescription(msg.offer));
          const answer = await pcRef.current.createAnswer();
          await pcRef.current.setLocalDescription(answer);
          sock.send(JSON.stringify({ type: "webrtc:answer", toUserId: msg.fromUserId, callId: msg.callId, answer }));
          setActive({ callId: msg.callId, peerUserId: msg.fromUserId });
          break;
        }
        case "webrtc:answer": {
          if (pcRef.current && msg.answer) {
            await pcRef.current.setRemoteDescription(new RTCSessionDescription(msg.answer));
          }
          break;
        }
        case "webrtc:ice": {
          if (pcRef.current) {
            try { await pcRef.current.addIceCandidate(msg.candidate); } catch {}
          }
          break;
        }
        default: break;
      }
    };
    setWs(sock);
    return () => sock.close();
  }, []);

  async function ensurePC(withVideo = true) {
    if (pcRef.current) return pcRef.current;

    const pc = new RTCPeerConnection({ iceServers: getIceServers() });

    pc.onicecandidate = (ev) => {
      if (ev.candidate && active?.peerUserId && ws?.readyState === 1) {
        ws.send(JSON.stringify({ type: "webrtc:ice", toUserId: active.peerUserId, callId: active.callId, candidate: ev.candidate }));
      }
    };

    pc.ontrack = (ev) => {
      // remote tracks
      if (!remoteStreamRef.current) remoteStreamRef.current = new MediaStream();
      remoteStreamRef.current.addTrack(ev.track);
      if (ev.track.kind === "audio" && remoteAudioRef.current) {
        remoteAudioRef.current.srcObject = remoteStreamRef.current;
      }
      if (ev.track.kind === "video" && remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = remoteStreamRef.current;
      }
    };

    pc.onconnectionstatechange = () => {
      const s = pc.connectionState;
      if (s === "failed" || s === "disconnected" || s === "closed") cleanupCall();
    };

    // Local media
    const constraints = { audio: true, video: withVideo ? { width: { ideal: 640 }, height: { ideal: 360 }, frameRate: 15 } : false };
    localStreamRef.current = await navigator.mediaDevices.getUserMedia(constraints);
    localStreamRef.current.getTracks().forEach((tr) => pc.addTrack(tr, localStreamRef.current));

    // show local preview if video on
    if (withVideo && localVideoRef.current) localVideoRef.current.srcObject = localStreamRef.current;

    pcRef.current = pc;
    return pc;
  }

  function setRemoteAudioEl(el) { remoteAudioRef.current = el; if (remoteStreamRef.current) el.srcObject = remoteStreamRef.current; }
  function setRemoteVideoEl(el) { remoteVideoRef.current = el; if (remoteStreamRef.current) el.srcObject = remoteStreamRef.current; }
  function setLocalVideoEl(el) { localVideoRef.current = el; if (localStreamRef.current) el.srcObject = localStreamRef.current; }

  async function callUser(toUserId, withVideo = true) {
    const u = getUser();
    if (!u || !ws || ws.readyState !== 1) return;
    await ensurePC(withVideo);
    const callId = `call_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    setActive({ callId, peerUserId: toUserId });
    ws.send(JSON.stringify({ type: "call:invite", toUserId, callId }));
    const offer = await pcRef.current.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: true });
    await pcRef.current.setLocalDescription(offer);
    ws.send(JSON.stringify({ type: "webrtc:offer", toUserId, callId, offer }));
  }

  async function acceptCall(withVideo = true) {
    const { fromUserId, callId } = incoming || {};
    if (!fromUserId) return;
    setActive({ callId, peerUserId: fromUserId });
    setIncoming(null);
    ws?.send(JSON.stringify({ type: "call:accept", toUserId: fromUserId, callId }));
    await ensurePC(withVideo);
  }

  function declineCall() {
    const { fromUserId, callId } = incoming || {};
    if (!fromUserId) return;
    ws?.send(JSON.stringify({ type: "call:decline", toUserId: fromUserId, callId }));
    setIncoming(null);
  }

  function endCall() {
    if (active?.peerUserId) ws?.send(JSON.stringify({ type: "call:end", toUserId: active.peerUserId, callId: active.callId }));
    cleanupCall();
  }

  function cleanupCall() {
    setActive(null);
    try { pcRef.current?.getSenders?.().forEach((s)=> s.track?.stop?.()); } catch {}
    try { localStreamRef.current?.getTracks?.().forEach((t)=> t.stop()); } catch {}
    if (pcRef.current) { try { pcRef.current.close(); } catch {} pcRef.current = null; }
    if (remoteAudioRef.current) remoteAudioRef.current.srcObject = null;
    if (remoteVideoRef.current) remoteVideoRef.current.srcObject = null;
    if (localVideoRef.current) localVideoRef.current.srcObject = null;
    setCamOff(true); setMuted(false);
  }

  function toggleMute() {
    setMuted((m) => {
      const next = !m;
      localStreamRef.current?.getAudioTracks()?.forEach((tr) => (tr.enabled = !next));
      return next;
    });
  }

  async function toggleCamera() {
    if (!localStreamRef.current) return;
    const tracks = localStreamRef.current.getVideoTracks();
    if (tracks && tracks.length) {
      const on = tracks[0].enabled;
      tracks[0].enabled = !on;
      setCamOff(on);
      return;
    }
    // if no video track, try to add one
    try {
      const cam = await navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 640 }, height: { ideal: 360 }, frameRate: 15 } });
      const track = cam.getVideoTracks()[0];
      localStreamRef.current.addTrack(track);
      const sender = pcRef.current?.addTrack?.(track, localStreamRef.current);
      if (localVideoRef.current) localVideoRef.current.srcObject = localStreamRef.current;
      setCamOff(false);
    } catch {}
  }

  const value = useMemo(() => ({
    online, incoming, active,
    muted, camOff,
    callUser, acceptCall, declineCall, endCall,
    toggleMute, toggleCamera,
    setRemoteAudioEl, setRemoteVideoEl, setLocalVideoEl,
  }), [online, incoming, active, muted, camOff]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCall(){
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useCall must be used within CallProvider");
  return ctx;
}

// ===============================
// FILE: src/call/components/IncomingCallOverlay.jsx
// ===============================
import React from "react";
import { useTranslation } from "react-i18next";
import { useCall } from "../CallContext";

export default function IncomingCallOverlay(){
  const { t } = useTranslation();
  const { incoming, acceptCall, declineCall } = useCall();
  if (!incoming) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
      <div className="w-[340px] rounded-2xl border border-cyan-300/30 bg-[#070a10] p-5 text-cyan-50 shadow-xl">
        <div className="mb-1 text-sm text-cyan-300/80">{t('INCOMING_CALL','Incoming call')}</div>
        <div className="mb-4 text-base font-bold text-cyan-100">{t('SOMEONE_CALLING','Someone is calling you…')}</div>
        <div className="flex items-center gap-2">
          <button onClick={()=>acceptCall(true)} className="flex-1 rounded-lg border border-emerald-400/40 bg-emerald-400/10 px-3 py-2 text-sm text-emerald-200 hover:bg-emerald-400/20">{t('ACCEPT_WITH_VIDEO','Accept (video)')}</button>
          <button onClick={()=>acceptCall(false)} className="flex-1 rounded-lg border border-emerald-400/40 bg-emerald-400/10 px-3 py-2 text-sm text-emerald-200 hover:bg-emerald-400/20">{t('ACCEPT_AUDIO_ONLY','Accept (audio)')}</button>
          <button onClick={declineCall} className="flex-1 rounded-lg border border-rose-400/40 bg-rose-400/10 px-3 py-2 text-sm text-rose-200 hover:bg-rose-400/20">{t('DECLINE','Decline')}</button>
        </div>
      </div>
    </div>
  );
}

// ===============================
// FILE: src/call/components/CallHUD.jsx
// ===============================
import React, { useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { useCall } from "../CallContext";

export default function CallHUD(){
  const { t } = useTranslation();
  const audioRef = useRef(null);
  const remoteVideoRef = useRef(null);
  const localVideoRef = useRef(null);
  const { active, muted, camOff, setRemoteAudioEl, setRemoteVideoEl, setLocalVideoEl, endCall, toggleMute, toggleCamera } = useCall();

  useEffect(() => { setRemoteAudioEl(audioRef.current); }, [setRemoteAudioEl]);
  useEffect(() => { setRemoteVideoEl(remoteVideoRef.current); }, [setRemoteVideoEl]);
  useEffect(() => { setLocalVideoEl(localVideoRef.current); }, [setLocalVideoEl]);

  if (!active) return null;
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 mx-auto mb-3 w-full max-w-5xl rounded-2xl border border-cyan-300/30 bg-[#03050a]/95 p-3 text-cyan-50 backdrop-blur">
      <div className="grid grid-cols-12 gap-3">
        {/* Video area */}
        <div className="col-span-12 md:col-span-9">
          <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-cyan-300/20 bg-black/30">
            <video ref={remoteVideoRef} autoPlay playsInline className="h-full w-full object-cover" />
            <video ref={localVideoRef} autoPlay muted playsInline className="absolute bottom-2 right-2 h-24 w-32 rounded-lg border border-cyan-300/30 object-cover" />
            <audio ref={audioRef} autoPlay playsInline />
          </div>
        </div>

        {/* Controls */}
        <div className="col-span-12 md:col-span-3 flex flex-col gap-2">
          <button onClick={toggleMute} className="rounded-lg border border-cyan-300/40 px-3 py-2 text-xs hover:bg-cyan-500/10">{muted ? t('UNMUTE','Unmute') : t('MUTE','Mute')}</button>
          <button onClick={toggleCamera} className="rounded-lg border border-cyan-300/40 px-3 py-2 text-xs hover:bg-cyan-500/10">{camOff ? t('CAMERA_ON','Camera on') : t('CAMERA_OFF','Camera off')}</button>
          <button onClick={endCall} className="rounded-lg border border-rose-400/40 bg-rose-400/10 px-3 py-2 text-xs hover:bg-rose-400/20">{t('END_CALL','End call')}</button>
        </div>
      </div>
    </div>
  );
}

// ===============================
// FILE: src/call/components/CallButton.jsx
// ===============================
import React from "react";
import { useTranslation } from "react-i18next";
import { useCall } from "../CallContext";

export default function CallButton({ toUserId, withVideo = true, className = "" }){
  const { t } = useTranslation();
  const { callUser } = useCall();
  return (
    <button
      onClick={() => callUser(toUserId, withVideo)}
      className={className || "rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs text-cyan-100 hover:bg-cyan-500/10"}
    >
      {withVideo ? t('CALL_VIDEO','Call (video)') : t('CALL_AUDIO','Call (audio)')}
    </button>
  );
}

// ===============================
// FILE: src/call/components/PhoneBridgeButton.jsx
// ===============================
import React, { useState } from "react";
import { useTranslation } from "react-i18next";

export default function PhoneBridgeButton(){
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const [info, setInfo] = useState(null); // { number, pin, expiresAt }

  async function startBridge(){
    // Placeholder: استدعِ API حقيقي عندك يرجع رقم موحّد + PIN
    // const res = await fetch('/api/phone/start', { method: 'POST' });
    // const data = await res.json();
    const data = { number: "+30 210 000 0000", pin: Math.floor(100000 + Math.random()*900000), expiresAt: new Date(Date.now()+2*60*1000).toISOString() };
    setInfo(data); setOpen(true);
  }

  return (
    <>
      <button onClick={startBridge} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs text-cyan-100 hover:bg-cyan-500/10">{t('START_PHONE_BRIDGE','Phone bridge')}</button>
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60">
          <div className="w-[360px] rounded-2xl border border-cyan-300/30 bg-[#070a10] p-5 text-cyan-50 shadow-xl">
            <div className="mb-3 text-sm text-cyan-300/80">{t('CALL_PHONE_INSTRUCTIONS','Dial the number and enter the PIN to join this call.')}</div>
            <div className="mb-2 text-base font-bold text-cyan-100">{t('NUMBER','Number')}: <span className="font-mono">{info?.number}</span></div>
            <div className="mb-4 text-base font-bold text-cyan-100">PIN: <span className="font-mono">{info?.pin}</span></div>
            <div className="mb-4 text-xs text-cyan-300/70">{t('EXPIRES_AT','Expires at')}: {info ? new Date(info.expiresAt).toLocaleTimeString() : ''}</div>
            <div className="flex items-center justify-end gap-2">
              <button onClick={()=>setOpen(false)} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10">{t('CLOSE','Close')}</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// ===============================
// FILE: src/call/TranslationPanel.jsx
// ===============================
import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";

/**
 * ملاحظة: هذا اللوح واجهة فقط. اربطه لاحقًا مع WS خدمات ASR/MT/TTS.
 */
export default function TranslationPanel(){
  const { t, i18n } = useTranslation();
  const [enabled, setEnabled] = useState(false);
  const [useMyVoice, setUseMyVoice] = useState(false);
  const [listenLang, setListenLang] = useState(""); // target language code
  const [languages, setLanguages] = useState([]); // from /api/capabilities

  useEffect(() => {
    // Placeholder: اسحب من خدمة القدرات
    // fetch('/api/capabilities').then(r=>r.json()).then(setLanguages)
    setLanguages([
      { code: 'auto', name: 'Auto-Detect', kind: 'meta' },
      { code: 'ar', name: 'العربية', kind: 'tts-natural' },
      { code: 'el', name: 'Ελληνικά', kind: 'tts-natural' },
      { code: 'en', name: 'English', kind: 'tts-natural' },
      { code: 'fr', name: 'Français', kind: 'tts-natural' },
      { code: 'es', name: 'Español', kind: 'tts-basic' },
      { code: 'ur', name: 'اردو', kind: 'tts-basic' },
      { code: 'bn', name: 'বাংলা', kind: 'tts-basic' },
      { code: 'fa', name: 'فارسی', kind: 'tts-basic' },
      { code: 'ps', name: 'پښتو', kind: 'captions' },
    ]);
    setListenLang('ar');
  }, []);

  return (
    <div className="rounded-2xl border border-cyan-300/30 bg-[#070a10] p-4 text-cyan-50">
      <div className="mb-2 text-sm font-bold text-cyan-100">{t('TRANSLATION','Translation')}</div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <label className="flex items-center gap-2 text-xs">
          <input type="checkbox" checked={enabled} onChange={(e)=> setEnabled(e.target.checked)} />
          {t('ENABLE_TRANSLATION','Enable voice translation')}
        </label>
        <label className="flex items-center gap-2 text-xs">
          <input type="checkbox" checked={useMyVoice} onChange={(e)=> setUseMyVoice(e.target.checked)} />
          {t('USE_MY_VOICE','Speak with my voice')}
        </label>
      </div>
      <div className="mb-3">
        <label className="mb-1 block text-xs text-cyan-300/80">{t('LISTEN_IN','Listen in')}</label>
        <select value={listenLang} onChange={(e)=> setListenLang(e.target.value)} className="w-full rounded-lg border border-cyan-300/30 bg-black/30 px-3 py-2 text-sm">
          {languages.map((l)=> (
            <option key={l.code} value={l.code}>
              {l.name} {l.kind==='tts-natural' ? '• Natural' : l.kind==='tts-basic' ? '• Basic' : l.kind==='captions' ? '• Captions only' : ''}
            </option>
          ))}
        </select>
      </div>
      <div className="text-[11px] text-cyan-300/70">
        {t('TRANSLATION_HINT','Change target language anytime. If natural voice is unavailable, we will use a basic voice or captions.')}
      </div>
    </div>
  );
}

// ===============================
// FILE: src/call/CallPage.jsx
// ===============================
import React from "react";
import { useTranslation } from "react-i18next";
import { CallProvider } from "./CallContext";
import CallButton from "./components/CallButton";
import IncomingCallOverlay from "./components/IncomingCallOverlay";
import CallHUD from "./components/CallHUD";
import PhoneBridgeButton from "./components/PhoneBridgeButton";
import TranslationPanel from "./TranslationPanel";

export default function CallPage(){
  const { t } = useTranslation();
  const users = [
    { id: 'u1', name: 'Alice' },
    { id: 'u2', name: 'Bob' },
    { id: 'u3', name: 'Charlie' },
  ];
  return (
    <CallProvider>
      <div className="min-h-screen bg-[#05060a] px-4 py-6 text-cyan-50">
        <div className="mx-auto grid max-w-7xl gap-4 md:grid-cols-3">
          {/* Left: People & actions */}
          <section className="rounded-2xl border border-cyan-300/30 bg-black/30 p-4">
            <div className="mb-2 text-sm font-bold text-cyan-100">{t('PEOPLE','People')}</div>
            <div className="space-y-2">
              {users.map((u)=> (
                <div key={u.id} className="flex items-center justify-between gap-2 rounded-lg border border-cyan-300/20 bg-black/20 px-2 py-2 text-sm">
                  <div className="font-semibold text-cyan-100">{u.name}</div>
                  <div className="flex items-center gap-2">
                    <CallButton toUserId={u.id} withVideo={true} />
                    <CallButton toUserId={u.id} withVideo={false} />
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4">
              <PhoneBridgeButton />
            </div>
          </section>

          {/* Middle: Translation */}
          <section className="md:col-span-2">
            <TranslationPanel />
          </section>
        </div>

        <IncomingCallOverlay />
        <CallHUD />
      </div>
    </CallProvider>
  );
}

// ===============================
// FILE: src/i18n/messages_en.calls_full.js
// ===============================
export default {
  PEOPLE: "People",
  CALL_VIDEO: "Call (video)",
  CALL_AUDIO: "Call (audio)",
  INCOMING_CALL: "Incoming call",
  SOMEONE_CALLING: "Someone is calling you…",
  ACCEPT_WITH_VIDEO: "Accept (video)",
  ACCEPT_AUDIO_ONLY: "Accept (audio)",
  DECLINE: "Decline",
  MUTE: "Mute",
  UNMUTE: "Unmute",
  CAMERA_ON: "Camera on",
  CAMERA_OFF: "Camera off",
  END_CALL: "End call",
  START_PHONE_BRIDGE: "Phone bridge",
  CALL_PHONE_INSTRUCTIONS: "Dial the number and enter the PIN to join this call.",
  NUMBER: "Number",
  EXPIRES_AT: "Expires at",
  CLOSE: "Close",
  TRANSLATION: "Translation",
  ENABLE_TRANSLATION: "Enable voice translation",
  USE_MY_VOICE: "Speak with my voice",
  LISTEN_IN: "Listen in",
  TRANSLATION_HINT: "Change target language anytime. If natural voice is unavailable, we will use a basic voice or captions.",
};

// ===============================
// FILE: src/i18n/messages_ar.calls_full.js
// ===============================
export default {
  PEOPLE: "الأشخاص",
  CALL_VIDEO: "اتصال (فيديو)",
  CALL_AUDIO: "اتصال (صوت)",
  INCOMING_CALL: "مكالمة واردة",
  SOMEONE_CALLING: "هناك من يتصل بك…",
  ACCEPT_WITH_VIDEO: "قبول (فيديو)",
  ACCEPT_AUDIO_ONLY: "قبول (صوت)",
  DECLINE: "رفض",
  MUTE: "كتم",
  UNMUTE: "إلغاء الكتم",
  CAMERA_ON: "تشغيل الكاميرا",
  CAMERA_OFF: "إيقاف الكاميرا",
  END_CALL: "إنهاء المكالمة",
  START_PHONE_BRIDGE: "جسر هاتفي",
  CALL_PHONE_INSTRUCTIONS: "اتصل بالرقم وأدخل رمز PIN للانضمام إلى هذه المكالمة.",
  NUMBER: "الرقم",
  EXPIRES_AT: "تنتهي في",
  CLOSE: "إغلاق",
  TRANSLATION: "الترجمة",
  ENABLE_TRANSLATION: "تفعيل الترجمة الصوتية",
  USE_MY_VOICE: "التحدث بصوتي",
  LISTEN_IN: "أسمع بـ",
  TRANSLATION_HINT: "يمكنك تغيير لغة الاستماع في أي وقت. إن لم تتوفر صوت طبيعي سنستخدم صوتًا أساسيًا أو نصًا على الشاشة.",
};

// ===============================
// FILE: src/i18n/messages_fr.calls_full.js
// ===============================
export default {
  PEOPLE: "Personnes",
  CALL_VIDEO: "Appel (vidéo)",
  CALL_AUDIO: "Appel (audio)",
  INCOMING_CALL: "Appel entrant",
  SOMEONE_CALLING: "Quelqu’un vous appelle…",
  ACCEPT_WITH_VIDEO: "Accepter (vidéo)",
  ACCEPT_AUDIO_ONLY: "Accepter (audio)",
  DECLINE: "Refuser",
  MUTE: "Couper le son",
  UNMUTE: "Rétablir le son",
  CAMERA_ON: "Activer la caméra",
  CAMERA_OFF: "Désactiver la caméra",
  END_CALL: "Terminer l’appel",
  START_PHONE_BRIDGE: "Passerelle téléphonique",
  CALL_PHONE_INSTRUCTIONS: "Composez le numéro et entrez le code PIN pour rejoindre l’appel.",
  NUMBER: "Numéro",
  EXPIRES_AT: "Expire à",
  CLOSE: "Fermer",
  TRANSLATION: "Traduction",
  ENABLE_TRANSLATION: "Activer la traduction vocale",
  USE_MY_VOICE: "Parler avec ma voix",
  LISTEN_IN: "Écouter en",
  TRANSLATION_HINT: "Changez la langue cible à tout moment. Si aucune voix naturelle n’est disponible, nous utiliserons une voix basique ou seulement des sous‑titres.",
};

// ===============================
// FILE: src/i18n/messages_el.calls_full.js
// ===============================
export default {
  PEOPLE: "Άτομα",
  CALL_VIDEO: "Κλήση (βίντεο)",
  CALL_AUDIO: "Κλήση (ήχος)",
  INCOMING_CALL: "Εισερχόμενη κλήση",
  SOMEONE_CALLING: "Κάποιος σε καλεί…",
  ACCEPT_WITH_VIDEO: "Αποδοχή (βίντεο)",
  ACCEPT_AUDIO_ONLY: "Αποδοχή (ήχος)",
  DECLINE: "Απόρριψη",
  MUTE: "Σίγαση",
  UNMUTE: "Άρση σίγασης",
  CAMERA_ON: "Ενεργοποίηση κάμερας",
  CAMERA_OFF: "Απενεργοποίηση κάμερας",
  END_CALL: "Τερματισμός κλήσης",
  START_PHONE_BRIDGE: "Γέφυρα τηλεφώνου",
  CALL_PHONE_INSTRUCTIONS: "Κάλεσε τον αριθμό και εισήγαγε το PIN για να συνδεθείς στην κλήση.",
  NUMBER: "Αριθμός",
  EXPIRES_AT: "Λήγει στις",
  CLOSE: "Κλείσιμο",
  TRANSLATION: "Μετάφραση",
  ENABLE_TRANSLATION: "Ενεργοποίηση φωνητικής μετάφρασης",
  USE_MY_VOICE: "Να μιλάω με τη φωνή μου",
  LISTEN_IN: "Να ακούω σε",
  TRANSLATION_HINT: "Άλλαξε τη γλώσσα στόχο οποιαδήποτε στιγμή. Αν δεν υπάρχει φυσική φωνή, θα χρησιμοποιήσουμε βασική ή μόνο υπότιτλους.",
};

// ===============================
// FILE: server/signaling-server.js
// ===============================
/**
 * Minimal WebSocket signaling server for 1:1 audio/video calls.
 * Run: npm i ws
 *      node server/signaling-server.js
 * Env: PORT=8080 (default)
 */
const http = require('http');
const WebSocket = require('ws');

const PORT = process.env.PORT || 8080;
const server = http.createServer();
const wss = new WebSocket.Server({ server });

const clients = new Map(); // userId -> ws

function send(ws, msg) { try { ws.send(JSON.stringify(msg)); } catch {} }
function broadcastPresence() {
  const online = {}; for (const [uid] of clients) online[uid] = true;
  const msg = { type: 'presence', online };
  for (const [, ws] of clients) send(ws, msg);
}

wss.on('connection', (ws) => {
  let userId = null;
  ws.on('message', (raw) => {
    let msg = {}; try { msg = JSON.parse(raw); } catch { return; }
    switch (msg.type) {
      case 'auth': {
        userId = msg.userId || null; if (!userId) { ws.close(); return; }
        clients.set(userId, ws); broadcastPresence(); break; }
      case 'call:invite':
      case 'call:accept':
      case 'call:decline':
      case 'call:end':
      case 'webrtc:offer':
      case 'webrtc:answer':
      case 'webrtc:ice': {
        const target = clients.get(msg.toUserId);
        if (!target) { if (msg.type === 'call:invite') send(ws, { type: 'call:busy', toUserId: msg.toUserId, callId: msg.callId }); return; }
        send(target, { ...msg, fromUserId: userId }); break; }
      default: break;
    }
  });
  ws.on('close', () => { if (userId) { clients.delete(userId); broadcastPresence(); } });
});

server.listen(PORT, () => console.log('Signaling server listening on', PORT));
