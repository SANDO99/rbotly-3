import React, { createContext, useContext, useEffect, useMemo, useState } from "react";

// BotStudioContext — monthly subscription gating + editable bot configs (mock, API‑ready)
// - Keeps per-bot subscription state (active/inactive/expired) with renewal date
// - Holds editable config (prompt/tools/language/examples)
// - Holds datasets & jobs (mock placeholders for now)
// - Persisted to localStorage under "rb_studio"

const Ctx = createContext(null);

const STORAGE_KEY = "rb_studio";

function emptyBotState() {
  return {
    subscription: { status: "inactive", renewAt: null },
    config: {
      language: "ar",
      prompt: "",
      tools: { rag: true, web: false },
      gen: { maxTokens: 512, temperature: 0.7 },
      examples: [],
    },
    datasets: [], // {id, filename, size, lang, status}
    jobs: [], // {id, type, status, progress, createdAt, error?}
  };
}

export function BotStudioProvider({ children }) {
  const [store, setStore] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
    } catch {
      return {};
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
    } catch {}
  }, [store]);

  function ensure(botId) {
    if (!botId) return;
    setStore((prev) => (prev[botId] ? prev : { ...prev, [botId]: emptyBotState() }));
  }

  function get(botId) {
    return store[botId] || emptyBotState();
  }

  // ---- Subscription (Monthly only) ----
  function activateMonthly(botId, { months = 1 } = {}) {
    if (!botId) return;
    const renewAt = Date.now() + months * 30 * 24 * 60 * 60 * 1000; // approx 30-day month
    setStore((prev) => ({
      ...prev,
      [botId]: {
        ...(prev[botId] || emptyBotState()),
        subscription: { status: "active", renewAt },
      },
    }));
  }

  function expire(botId) {
    if (!botId) return;
    setStore((prev) => ({
      ...prev,
      [botId]: { ...(prev[botId] || emptyBotState()), subscription: { status: "expired", renewAt: prev[botId]?.subscription?.renewAt || null } },
    }));
  }

  function cancel(botId) {
    if (!botId) return;
    setStore((prev) => ({
      ...prev,
      [botId]: { ...(prev[botId] || emptyBotState()), subscription: { status: "inactive", renewAt: null } },
    }));
  }

  const isActive = (botId) => get(botId).subscription.status === "active";

  // ---- Config ----
  function setConfig(botId, partial) {
    if (!botId) return;
    setStore((prev) => ({
      ...prev,
      [botId]: { ...(prev[botId] || emptyBotState()), config: { ...(prev[botId]?.config || emptyBotState().config), ...partial } },
    }));
  }

  function addExample(botId, qa) {
    if (!botId) return;
    setStore((prev) => {
      const st = prev[botId] || emptyBotState();
      return {
        ...prev,
        [botId]: { ...st, config: { ...st.config, examples: [...(st.config.examples || []), { id: crypto.randomUUID(), ...qa }] } },
      };
    });
  }

  function removeExample(botId, id) {
    if (!botId) return;
    setStore((prev) => {
      const st = prev[botId] || emptyBotState();
      return {
        ...prev,
        [botId]: { ...st, config: { ...st.config, examples: (st.config.examples || []).filter((x) => x.id !== id) } },
      };
    });
  }

  // ---- Datasets (mock) ----
  function addDataset(botId, file) {
    if (!botId || !file) return;
    setStore((prev) => {
      const st = prev[botId] || emptyBotState();
      const ds = st.datasets || [];
      const item = {
        id: crypto.randomUUID(),
        filename: file.name,
        size: file.size,
        lang: st.config.language || "ar",
        status: "ready",
      };
      return { ...prev, [botId]: { ...st, datasets: [item, ...ds] } };
    });
  }

  function startEmbedJob(botId) {
    if (!botId) return;
    const job = { id: crypto.randomUUID(), type: "embed", status: "queued", progress: 0, createdAt: Date.now() };
    setStore((prev) => {
      const st = prev[botId] || emptyBotState();
      return { ...prev, [botId]: { ...st, jobs: [job, ...(st.jobs || [])] } };
    });
    // mock advance
    setTimeout(() => updateJob(botId, job.id, { status: "running", progress: 35 }), 600);
    setTimeout(() => updateJob(botId, job.id, { progress: 75 }), 1300);
    setTimeout(() => updateJob(botId, job.id, { status: "done", progress: 100 }), 2000);
  }

  function updateJob(botId, jobId, partial) {
    setStore((prev) => {
      const st = prev[botId] || emptyBotState();
      return {
        ...prev,
        [botId]: {
          ...st,
          jobs: (st.jobs || []).map((j) => (j.id === jobId ? { ...j, ...partial } : j)),
        },
      };
    });
  }

  const value = useMemo(
    () => ({
      ensure,
      get,
      isActive,
      activateMonthly,
      expire,
      cancel,
      setConfig,
      addExample,
      removeExample,
      addDataset,
      startEmbedJob,
    }),
    [store]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useBotStudio() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useBotStudio must be used inside BotStudioProvider");
  return v;
}
