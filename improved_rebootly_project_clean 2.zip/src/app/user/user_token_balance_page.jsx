// UserTokenBalancePage.js - صفحة رصيد التوكن مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const user_token_balance_page_en = {
  tokenBalanceTitle: "Token Balance",
  totalBalance: "Total Token Balance",
  used: "Used",
  remaining: "Remaining",
  transactions: "Transactions",
  date: "Date",
  amount: "Amount",
  description: "Description",
};
export const user_token_balance_page_ar = {
  tokenBalanceTitle: "رصيد التوكن",
  totalBalance: "إجمالي رصيد التوكن",
  used: "المستخدم",
  remaining: "المتبقي",
  transactions: "المعاملات",
  date: "التاريخ",
  amount: "القيمة",
  description: "الوصف",
};
export const user_token_balance_page_fr = {
  tokenBalanceTitle: "Solde de jetons",
  totalBalance: "Solde total de jetons",
  used: "Utilisé",
  remaining: "Restant",
  transactions: "Transactions",
  date: "Date",
  amount: "Montant",
  description: "Description",
};
export const user_token_balance_page_el = {
  tokenBalanceTitle: "Υπόλοιπο tokens",
  totalBalance: "Συνολικό υπόλοιπο tokens",
  used: "Χρησιμοποιήθηκαν",
  remaining: "Υπόλοιπο",
  transactions: "Συναλλαγές",
  date: "Ημερομηνία",
  amount: "Ποσό",
  description: "Περιγραφή",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: user_token_balance_page_en,
  ar: user_token_balance_page_ar,
  fr: user_token_balance_page_fr,
  el: user_token_balance_page_el,
};

const mockBalance = {
  total: 120,
  used: 45,
  remaining: 75,
  transactions: [
    { id: 1, date: "2025-08-07", amount: -20, description: "Text-to-Image Service" },
    { id: 2, date: "2025-08-05", amount: +100, description: "Token Purchase" },
    { id: 3, date: "2025-07-30", amount: -25, description: "GenFlow Tool" },
  ],
};

export default function UserTokenBalancePage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [balance] = useState(mockBalance);

  return (
    <main className="min-h-screen bg-black text-white p-6 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("tokenBalanceTitle")}</h1>
      <div className="grid grid-cols-2 gap-6 mb-8">
        <div className="bg-zinc-900 rounded-2xl p-6 flex flex-col items-center">
          <div className="text-lg font-semibold mb-2">{t("totalBalance")}</div>
          <div className="text-2xl font-mono text-[var(--neon)]">{balance.total}</div>
        </div>
        <div className="bg-zinc-900 rounded-2xl p-6 flex flex-col items-center">
          <div className="text-lg font-semibold mb-2">{t("used")}</div>
          <div className="text-2xl font-mono text-red-400">{balance.used}</div>
          <div className="text-lg font-semibold mb-2 mt-4">{t("remaining")}</div>
          <div className="text-2xl font-mono text-green-400">{balance.remaining}</div>
        </div>
      </div>
      <div className="bg-zinc-900 rounded-2xl p-6">
        <div className="text-xl font-bold mb-4">{t("transactions")}</div>
        <table className="w-full table-auto text-left border">
          <thead>
            <tr className="bg-zinc-800">
              <th className="p-2 border">#</th>
              <th className="p-2 border">{t("date")}</th>
              <th className="p-2 border">{t("amount")}</th>
              <th className="p-2 border">{t("description")}</th>
            </tr>
          </thead>
          <tbody>
            {balance.transactions.map((tr, i) => (
              <tr key={tr.id} className="border-t">
                <td className="p-2 border">{i + 1}</td>
                <td className="p-2 border">{tr.date}</td>
                <td className={
                  "p-2 border font-mono " + (tr.amount < 0 ? "text-red-400" : "text-green-400")
                }>{tr.amount}</td>
                <td className="p-2 border">{tr.description}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
