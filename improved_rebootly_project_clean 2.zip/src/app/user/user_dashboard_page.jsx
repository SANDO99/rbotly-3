// UserDashboardPage.js - لوحة المستخدم مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const user_dashboard_page_en = {
  dashboardTitle: "User Dashboard",
  welcome: "Welcome,",
  balance: "Token Balance",
  orders: "Orders",
  products: "My Products",
  profile: "Profile",
  settings: "Settings",
  viewAll: "View All",
};
export const user_dashboard_page_ar = {
  dashboardTitle: "لوحة المستخدم",
  welcome: "مرحبًا،",
  balance: "رصيد التوكن",
  orders: "الطلبات",
  products: "منتجاتي",
  profile: "الملف الشخصي",
  settings: "الإعدادات",
  viewAll: "عرض الكل",
};
export const user_dashboard_page_fr = {
  dashboardTitle: "Tableau de bord utilisateur",
  welcome: "Bienvenue,",
  balance: "Solde de jetons",
  orders: "Commandes",
  products: "Mes produits",
  profile: "Profil",
  settings: "Paramètres",
  viewAll: "Voir tout",
};
export const user_dashboard_page_el = {
  dashboardTitle: "Πίνακας χρήστη",
  welcome: "Καλώς ήρθατε,",
  balance: "Υπόλοιπο tokens",
  orders: "Παραγγελίες",
  products: "Τα προϊόντα μου",
  profile: "Προφίλ",
  settings: "Ρυθμίσεις",
  viewAll: "Προβολή όλων",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: user_dashboard_page_en,
  ar: user_dashboard_page_ar,
  fr: user_dashboard_page_fr,
  el: user_dashboard_page_el,
};

const userInfo = {
  name: "Ali Khaled",
  balance: 136,
};

export default function UserDashboardPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [user] = useState(userInfo);

  // أمثلة تنقل لأقسام أخرى (افتراضية)
  const goTo = (section) => {
    alert(`Navigate to: ${section}`);
  };

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-4 text-[var(--neon)]">{t("dashboardTitle")}</h1>
      <div className="bg-zinc-900 rounded-2xl shadow-lg p-6 mb-8 flex flex-col md:flex-row md:items-center gap-6">
        <div>
          <div className="text-xl font-semibold">{t("welcome")} <span className="text-[var(--neon)]">{user.name}</span></div>
          <div className="mt-2 text-lg">{t("balance")}: <span className="font-mono text-[var(--neon)]">{user.balance}</span></div>
        </div>
        <div className="flex gap-4 mt-4 md:mt-0 md:ml-auto">
          <button onClick={() => goTo("profile")} className="bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-xl shadow">{t("profile")}</button>
          <button onClick={() => goTo("settings")} className="bg-zinc-700 hover:bg-zinc-800 text-white px-4 py-2 rounded-xl shadow">{t("settings")}</button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-zinc-900 rounded-2xl p-6 flex flex-col">
          <div className="text-lg font-semibold mb-2">{t("orders")}</div>
          <button onClick={() => goTo("orders")} className="text-[var(--neon)] underline font-bold w-max">{t("viewAll")}</button>
        </div>
        <div className="bg-zinc-900 rounded-2xl p-6 flex flex-col">
          <div className="text-lg font-semibold mb-2">{t("products")}</div>
          <button onClick={() => goTo("products")} className="text-[var(--neon)] underline font-bold w-max">{t("viewAll")}</button>
        </div>
      </div>
    </main>
  );
}
