import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";

// ------------------------------------------------------------
// Rbotly — Marketplace / Checkout Page
// - Neon Blue on Dark
// - 4 Languages (AR, EN, FR, EL)
// - Token payment (mock): checks balance, deducts, success states
// - Handles three types: NFT bot (mint), Public bot (deliver to dashboard or download), Sound (download)
// - Reads id from /checkout/:id or ?id=
// ------------------------------------------------------------

const DICT = {
  ar: {
    TITLE: "الدفع",
    BACK: "رجوع إلى السوق",
    ITEM: "المنتج",
    TYPE: "النوع",
    PRICE: "السعر",
    TOKENS: "توكن",
    BALANCE: "رصيدي",
    TOTAL: "الإجمالي",
    TERMS: "أوافق على الشروط والأحكام",
    PAY: "ادفع بالتوكن",
    INSUFFICIENT: "الرصيد غير كافٍ",
    PROCESSING: "جارٍ المعالجة...",
    SUCCESS: "تم الدفع بنجاح",
    SUCCESS_DESC_NFT: "تم سكّ الـNFT وإضافته مباشرة إلى حسابك.",
    SUCCESS_DESC_BOT: "تمت إضافة البوت إلى لوحة المستخدم.",
    SUCCESS_DESC_SOUND: "تم إضافة الصوت إلى التحميلات ويمكن تنزيله الآن.",
    NOT_FOUND: "العنصر غير موجود",
    DELIVERY: "خيارات التسليم",
    HOST_ON_PLATFORM: "استخدامه على المنصة",
    DOWNLOAD_FILES: "تنزيل الملفات",
    OPEN_DASHBOARD: "فتح لوحة المستخدم",
    GO_DOWNLOADS: "الذهاب للتحميلات",
    TOP_UP: "شحن الرصيد",
    SUMMARY: "ملخص الطلب",
    QTY: "الكمية",
    ONE: "واحد",
    ID: "المعرف",
    CATEGORY_NFT: "NFT",
    CATEGORY_PUBLIC: "عام",
    CATEGORY_SOUND: "صوت",
    TERMS_HINT: "يجب الموافقة على الشروط قبل الدفع.",
    BAL_AFTER: "الرصيد بعد الدفع",
    ORDER_ID: "رقم الطلب",
  },
  en: {
    TITLE: "Checkout",
    BACK: "Back to Market",
    ITEM: "Item",
    TYPE: "Type",
    PRICE: "Price",
    TOKENS: "Token",
    BALANCE: "My balance",
    TOTAL: "Total",
    TERMS: "I agree to the Terms & Conditions",
    PAY: "Pay with tokens",
    INSUFFICIENT: "Insufficient balance",
    PROCESSING: "Processing...",
    SUCCESS: "Payment successful",
    SUCCESS_DESC_NFT: "NFT minted and added to your account.",
    SUCCESS_DESC_BOT: "The bot has been added to your dashboard.",
    SUCCESS_DESC_SOUND: "The voice pack is available in your downloads.",
    NOT_FOUND: "Item not found",
    DELIVERY: "Delivery options",
    HOST_ON_PLATFORM: "Use on platform",
    DOWNLOAD_FILES: "Download files",
    OPEN_DASHBOARD: "Open Dashboard",
    GO_DOWNLOADS: "Go to Downloads",
    TOP_UP: "Top up",
    SUMMARY: "Order Summary",
    QTY: "Qty",
    ONE: "One",
    ID: "ID",
    CATEGORY_NFT: "NFT",
    CATEGORY_PUBLIC: "Public",
    CATEGORY_SOUND: "Sound",
    TERMS_HINT: "You must accept the terms before paying.",
    BAL_AFTER: "Balance after payment",
    ORDER_ID: "Order ID",
  },
  fr: {
    TITLE: "Paiement",
    BACK: "Retour au Marché",
    ITEM: "Article",
    TYPE: "Type",
    PRICE: "Prix",
    TOKENS: "Jeton",
    BALANCE: "Mon solde",
    TOTAL: "Total",
    TERMS: "J'accepte les Conditions Générales",
    PAY: "Payer avec des jetons",
    INSUFFICIENT: "Solde insuffisant",
    PROCESSING: "Traitement...",
    SUCCESS: "Paiement réussi",
    SUCCESS_DESC_NFT: "NFT frappé et ajouté à votre compte.",
    SUCCESS_DESC_BOT: "Le bot a été ajouté à votre tableau de bord.",
    SUCCESS_DESC_SOUND: "Le pack voix est disponible dans vos téléchargements.",
    NOT_FOUND: "Article introuvable",
    DELIVERY: "Options de livraison",
    HOST_ON_PLATFORM: "Utiliser sur la plateforme",
    DOWNLOAD_FILES: "Télécharger les fichiers",
    OPEN_DASHBOARD: "Ouvrir le Tableau de bord",
    GO_DOWNLOADS: "Aller aux Téléchargements",
    TOP_UP: "Recharger",
    SUMMARY: "Récapitulatif",
    QTY: "Qté",
    ONE: "Un",
    ID: "ID",
    CATEGORY_NFT: "NFT",
    CATEGORY_PUBLIC: "Public",
    CATEGORY_SOUND: "Voix",
    TERMS_HINT: "Vous devez accepter les conditions avant de payer.",
    BAL_AFTER: "Solde après paiement",
    ORDER_ID: "ID Commande",
  },
  el: {
    TITLE: "Πληρωμή",
    BACK: "Πίσω στην Αγορά",
    ITEM: "Αντικείμενο",
    TYPE: "Τύπος",
    PRICE: "Τιμή",
    TOKENS: "Token",
    BALANCE: "Υπόλοιπό μου",
    TOTAL: "Σύνολο",
    TERMS: "Αποδέχομαι τους Όρους Χρήσης",
    PAY: "Πληρωμή με tokens",
    INSUFFICIENT: "Μη επαρκές υπόλοιπο",
    PROCESSING: "Επεξεργασία...",
    SUCCESS: "Η πληρωμή ολοκληρώθηκε",
    SUCCESS_DESC_NFT: "Το NFT κόπηκε και προστέθηκε στον λογαριασμό σου.",
    SUCCESS_DESC_BOT: "Το bot προστέθηκε στο dashboard σου.",
    SUCCESS_DESC_SOUND: "Το πακέτο φωνής είναι διαθέσιμο στα downloads.",
    NOT_FOUND: "Το αντικείμενο δεν βρέθηκε",
    DELIVERY: "Επιλογές παράδοσης",
    HOST_ON_PLATFORM: "Χρήση στην πλατφόρμα",
    DOWNLOAD_FILES: "Λήψη αρχείων",
    OPEN_DASHBOARD: "Άνοιγμα Πίνακα Ελέγχου",
    GO_DOWNLOADS: "Μετάβαση στα Downloads",
    TOP_UP: "Φόρτιση υπολοίπου",
    SUMMARY: "Σύνοψη παραγγελίας",
    QTY: "Ποσ.",
    ONE: "Ένα",
    ID: "ID",
    CATEGORY_NFT: "NFT",
    CATEGORY_PUBLIC: "Δημόσιο",
    CATEGORY_SOUND: "Ήχος",
    TERMS_HINT: "Πρέπει να αποδεχτείς τους όρους για να πληρώσεις.",
    BAL_AFTER: "Υπόλοιπο μετά την πληρωμή",
    ORDER_ID: "Κωδ. Παραγγελίας",
  },
};

const CATALOG = [
  // NFT
  { id: "nft-guardian-01", type: "bots-nft", name: "Guardian AI", description: "Bot NFT للحماية والمراقبة الذكية.", image: "https://placehold.co/640x360/png", priceTokens: 1200, language: "ar" },
  { id: "nft-mentor-02", type: "bots-nft", name: "Mentor AI", description: "Bot NFT للتعليم والدروس القصيرة.", image: "https://placehold.co/640x360/png", priceTokens: 950, language: "en" },
  // Public bots
  { id: "public-researcher-01", type: "bots", name: "Researcher", description: "بوت للبحث الذكي عن المعلومات.", image: "https://placehold.co/640x360/png", priceTokens: 300, language: "ar" },
  { id: "public-writer-02", type: "bots", name: "Writer", description: "بوت كتابة مقالات ومنشورات.", image: "https://placehold.co/640x360/png", priceTokens: 280, language: "fr" },
  // Sounds
  { id: "voice-orion", type: "sounds", name: "Orion Male", description: "صوت ذكوري واضح للرواية.", image: "https://placehold.co/640x360/png", priceTokens: 150, language: "en" },
  { id: "voice-lyra", type: "sounds", name: "Lyra Female", description: "صوت أنثوي دافئ لفيديوهات قصيرة.", image: "https://placehold.co/640x360/png", priceTokens: 160, language: "el" },
];

function useI18n(lang) {
  return (k) => (DICT[lang]?.[k] ?? DICT.en[k] ?? k);
}

function useRTL(lang) {
  useEffect(() => {
    const rtl = lang === "ar";
    document.documentElement.dir = rtl ? "rtl" : "ltr";
    document.documentElement.lang = lang;
  }, [lang]);
}

function Chip({ children }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-cyan-300/30 bg-cyan-300/10 px-2.5 py-1 text-xs text-cyan-100">
      {children}
    </span>
  );
}

function categoryLabel(type, t) {
  if (type === "bots-nft") return t("CATEGORY_NFT");
  if (type === "bots") return t("CATEGORY_PUBLIC");
  return t("CATEGORY_SOUND");
}

function generateOrderId() {
  const n = Date.now().toString(36).toUpperCase();
  const r = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `CHK-${n}-${r}`;
}

export default function MarketCheckoutPage() {
  const [lang, setLang] = useState("ar");
  const t = useI18n(lang);
  useRTL(lang);

  const [itemId] = useState(() => {
    const path = typeof window !== "undefined" ? window.location.pathname : "/";
    const byPath = path.split("/checkout/")[1];
    if (byPath) return byPath.split("/")[0];
    const sp = typeof window !== "undefined" ? new URLSearchParams(window.location.search) : null;
    return sp?.get("id") || "nft-guardian-01"; // default
  });

  const item = useMemo(() => CATALOG.find((x) => x.id === itemId), [itemId]);

  const [balance, setBalance] = useState(2000); // mock user balance
  const [accept, setAccept] = useState(false);
  const [delivery, setDelivery] = useState("host"); // host | download (only for bots/sounds)
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [orderId, setOrderId] = useState("");

  if (!item) {
    return (
      <div className="min-h-screen w-full bg-[#05060a] text-cyan-50">
        <div className="mx-auto max-w-5xl px-5 py-10">
          <a href="/market" className="inline-block rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">← {t("BACK")}</a>
          <div className="mt-6 rounded-2xl border border-cyan-300/30 bg-black/30 p-6 text-center text-cyan-100/85">{t("NOT_FOUND")}</div>
        </div>
      </div>
    );
  }

  const total = item.priceTokens || 0;
  const canPay = accept && !processing && balance >= total;

  function pay() {
    if (!canPay) return;
    setProcessing(true);
    const id = generateOrderId();
    setOrderId(id);
    setTimeout(() => {
      setBalance((b) => b - total);
      setProcessing(false);
      setSuccess(true);
    }, 900);
  }

  return (
    <div className="min-h-screen w-full bg-[#05060a] bg-[radial-gradient(1200px_600px_at_10%_-10%,rgba(0,229,255,0.08),transparent_40%),radial-gradient(900px_500px_at_90%_0%,rgba(0,229,255,0.06),transparent_35%)] text-cyan-50">
      <div className="mx-auto max-w-5xl px-5 py-8">
        {/* Header */}
        <header className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <a href="/market" className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">← {t("BACK")}</a>
            <motion.h1 initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="text-[clamp(24px,3.4vw,36px)] font-extrabold tracking-wide text-cyan-100 drop-shadow-[0_0_22px_rgba(0,229,255,0.18)]">
              {t("TITLE")}
            </motion.h1>
          </div>
          <select value={lang} onChange={(e) => setLang(e.target.value)} className="min-w-[140px] rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 outline-none ring-0 transition focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20">
            <option value="ar">العربية</option>
            <option value="en">English</option>
            <option value="fr">Français</option>
            <option value="el">Ελληνικά</option>
          </select>
        </header>

        {/* Content */}
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-[1.1fr,0.9fr]">
          {/* Left: Item + Delivery */}
          <div className="space-y-5">
            {/* Item card */}
            <div className="overflow-hidden rounded-2xl border border-cyan-300/30 bg-black/40 shadow-[0_0_24px_rgba(0,229,255,0.12)]">
              <div className="aspect-video w-full overflow-hidden">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={item.image} alt={item.name} className="h-full w-full object-cover opacity-95" />
              </div>
              <div className="p-4">
                <div className="mb-1 text-sm text-cyan-100/70">{t("ITEM")}</div>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="text-lg font-bold text-cyan-100">{item.name}</div>
                    <div className="mt-1 text-cyan-100/80">{item.description}</div>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <Chip>{t("TYPE")}: {categoryLabel(item.type, t)}</Chip>
                      <Chip>{t("ID")}: {item.id}</Chip>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-cyan-100/70">{t("PRICE")}</div>
                    <div className="font-mono text-xl text-cyan-100">{item.priceTokens} {t("TOKENS")}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Delivery options (only for non-NFT) */}
            {item.type !== "bots-nft" && (
              <div className="rounded-2xl border border-cyan-300/30 bg-gradient-to-b from-cyan-400/10 to-cyan-400/5 p-4">
                <div className="mb-2 text-cyan-100">{t("DELIVERY")}</div>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <label className={`flex flex-1 cursor-pointer items-center gap-3 rounded-xl border px-3 py-2 ${
                    delivery === "host" ? "border-cyan-300/70 bg-cyan-400/10" : "border-cyan-300/30 bg-black/30"
                  }`}>
                    <input type="radio" name="delivery" className="accent-cyan-400" checked={delivery === "host"} onChange={() => setDelivery("host")} />
                    <span className="text-cyan-100">{t("HOST_ON_PLATFORM")}</span>
                  </label>
                  <label className={`flex flex-1 cursor-pointer items-center gap-3 rounded-xl border px-3 py-2 ${
                    delivery === "download" ? "border-cyan-300/70 bg-cyan-400/10" : "border-cyan-300/30 bg-black/30"
                  }`}>
                    <input type="radio" name="delivery" className="accent-cyan-400" checked={delivery === "download"} onChange={() => setDelivery("download")} />
                    <span className="text-cyan-100">{t("DOWNLOAD_FILES")}</span>
                  </label>
                </div>
              </div>
            )}

            {/* Terms */}
            <label className="flex items-start gap-3 rounded-2xl border border-cyan-300/30 bg-black/30 p-4">
              <input type="checkbox" className="mt-1.5 accent-cyan-400" checked={accept} onChange={() => setAccept((v) => !v)} />
              <div>
                <div className="text-cyan-100">{t("TERMS")}</div>
                {!accept && <div className="text-xs text-cyan-100/70">{t("TERMS_HINT")}</div>}
              </div>
            </label>
          </div>

          {/* Right: Summary + Pay */}
          <div className="space-y-5">
            <div className="rounded-2xl border border-cyan-300/30 bg-gradient-to-b from-cyan-400/10 to-cyan-400/5 p-4">
              <div className="mb-3 text-cyan-100">{t("SUMMARY")}</div>
              <div className="flex items-center justify-between text-sm text-cyan-100/80">
                <span>{t("ITEM")}</span>
                <span className="font-medium">{item.name}</span>
              </div>
              <div className="mt-2 flex items-center justify-between text-sm text-cyan-100/80">
                <span>{t("QTY")}</span>
                <span className="font-medium">{t("ONE")}</span>
              </div>
              <div className="mt-2 flex items-center justify-between text-sm text-cyan-100/80">
                <span>{t("TYPE")}</span>
                <span className="font-medium">{categoryLabel(item.type, t)}</span>
              </div>
              <div className="mt-2 flex items-center justify-between text-sm text-cyan-100/80">
                <span>{t("PRICE")}</span>
                <span className="font-mono">{item.priceTokens} {t("TOKENS")}</span>
              </div>
              <div className="mt-4 h-px w-full bg-cyan-300/20" />
              <div className="mt-3 flex items-center justify-between text-sm text-cyan-100/80">
                <span>{t("BALANCE")}</span>
                <span className="font-mono">{balance} {t("TOKENS")}</span>
              </div>
              <div className="mt-2 flex items-center justify-between text-sm text-cyan-100/80">
                <span>{t("TOTAL")}</span>
                <span className="font-mono text-cyan-100">{total} {t("TOKENS")}</span>
              </div>
              <div className="mt-2 flex items-center justify-between text-xs text-cyan-100/70">
                <span>{t("BAL_AFTER")}</span>
                <span className="font-mono">{Math.max(0, balance - total)} {t("TOKENS")}</span>
              </div>
              <div className="mt-4 flex items-center gap-2">
                <button onClick={() => (window.location.href = "/wallet/topup") } className="rounded-xl border border-cyan-300/30 bg-black/30 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">
                  {t("TOP_UP")}
                </button>
                <div className="grow" />
                <button
                  disabled={!canPay}
                  onClick={pay}
                  className={`rounded-xl px-4 py-2 text-sm font-semibold ${
                    canPay
                      ? "border border-cyan-300/40 bg-cyan-500/10 text-cyan-50 hover:bg-cyan-500/20"
                      : "border border-cyan-300/20 bg-black/30 text-cyan-100/60"
                  }`}
                >
                  {processing ? t("PROCESSING") : balance < total ? t("INSUFFICIENT") : t("PAY")}
                </button>
              </div>
            </div>

            {/* Success panel */}
            {success && (
              <div className="rounded-2xl border border-cyan-300/40 bg-black/40 p-4 shadow-[0_0_24px_rgba(0,229,255,0.18)]">
                <div className="mb-1 text-lg font-bold text-cyan-100">✅ {t("SUCCESS")}</div>
                <div className="text-cyan-100/85">
                  {item.type === "bots-nft" && t("SUCCESS_DESC_NFT")}
                  {item.type === "bots" && t("SUCCESS_DESC_BOT")}
                  {item.type === "sounds" && t("SUCCESS_DESC_SOUND")}
                </div>
                <div className="mt-3 grid grid-cols-1 gap-2 text-sm text-cyan-100/85 sm:grid-cols-2">
                  <div>
                    <div className="text-cyan-100/70">{t("ORDER_ID")}</div>
                    <div className="font-mono">{orderId}</div>
                  </div>
                  <div>
                    <div className="text-cyan-100/70">{t("BAL_AFTER")}</div>
                    <div className="font-mono">{balance} {t("TOKENS")}</div>
                  </div>
                </div>
                <div className="mt-4 flex flex-wrap items-center gap-2">
                  {(item.type === "bots" || item.type === "bots-nft") && (
                    <a href="/dashboard/bots" className="rounded-xl border border-cyan-300/40 bg-cyan-500/10 px-3 py-2 text-sm font-medium text-cyan-50 hover:bg-cyan-500/20">
                      {t("OPEN_DASHBOARD")}
                    </a>
                  )}
                  {item.type === "sounds" && (
                    <a href="/downloads" className="rounded-xl border border-cyan-300/40 bg-cyan-500/10 px-3 py-2 text-sm font-medium text-cyan-50 hover:bg-cyan-500/20">
                      {t("GO_DOWNLOADS")}
                    </a>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
