// search_results_page.jsx
export const search_results_page_en = {
  searchResults: "Search Results",
  noResults: "No results found for",
  nftBots: "NFT Bots",
  voices: "Voices",
  addons: "Add-ons",
  viewAll: "View All",
};
export const search_results_page_ar = {
  searchResults: "نتائج البحث",
  noResults: "لم يتم العثور على نتائج لـ",
  nftBots: "بوتات NFT",
  voices: "الأصوات",
  addons: "الإضافات",
  viewAll: "عرض الكل",
};
export const search_results_page_fr = {
  searchResults: "Résultats de recherche",
  noResults: "Aucun résultat trouvé pour",
  nftBots: "Bots NFT",
  voices: "Voix",
  addons: "Add-ons",
  viewAll: "Voir tout",
};
export const search_results_page_el = {
  searchResults: "Αποτελέσματα αναζήτησης",
  noResults: "Δεν βρέθηκαν αποτελέσματα για",
  nftBots: "NFT Bots",
  voices: "Φωνές",
  addons: "Πρόσθετα",
  viewAll: "Προβολή όλων",
};

import { useRouter } from "next/router";
import { useState, useEffect } from "react";

const translations = {
  en: search_results_page_en,
  ar: search_results_page_ar,
  fr: search_results_page_fr,
  el: search_results_page_el,
};

// محاكاة بيانات البحث
const mockSearchResults = (query) => ({
  bots: [
    { id: 1, name: `Mixtral NFT Bot (${query})`, owner: "ahmed@example.com", img: "/img/nft1.png" },
    { id: 2, name: `EduBotX (${query})`, owner: "sara@example.com", img: "/img/bot1.png" },
  ],
  voices: [
    { id: 1, name: `Arabic Male Voice (${query})`, creator: "voicecraft@example.com", img: "/img/voice1.png" },
  ],
  addons: [
    { id: 1, name: `Multi-Language Pack (${query})`, developer: "devteam@example.com", img: "/img/addon1.png" },
  ],
});

export default function SearchResultsPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const router = useRouter();
  const { q } = router.query;
  const [results, setResults] = useState({ bots: [], voices: [], addons: [] });

  useEffect(() => {
    if (q) {
      // محاكاة استدعاء API للبحث
      setTimeout(() => {
        setResults(mockSearchResults(q));
      }, 300);
    }
  }, [q]);

  const totalResults = 
    results.bots.length + 
    results.voices.length + 
    results.addons.length;

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-6 text-[var(--neon)]">
        {t("searchResults")}: <span className="text-white">"{q}"</span>
      </h1>
      
      {totalResults === 0 ? (
        <div className="text-center py-16">
          <div className="text-2xl text-gray-400 mb-2">
            {t("noResults")} "{q}"
          </div>
          <div className="text-lg">Try different keywords</div>
        </div>
      ) : (
        <>
          {/* نتائج بوتات NFT */}
          {results.bots.length > 0 && (
            <section className="mb-12">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-[var(--neon)]">
                  {t("nftBots")} ({results.bots.length})
                </h2>
                <button className="text-blue-500 hover:text-blue-400">
                  {t("viewAll")} →
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {results.bots.map(bot => (
                  <div key={bot.id} className="bg-zinc-900 rounded-2xl shadow-lg overflow-hidden flex flex-col">
                    <div className="h-48 bg-zinc-800 flex items-center justify-center">
                      <img src={bot.img} alt={bot.name} className="max-h-40 max-w-full" />
                    </div>
                    <div className="p-4 flex-1 flex flex-col">
                      <div className="font-bold text-lg mb-1">{bot.name}</div>
                      <div className="text-xs text-gray-400 mb-3">Owner: {bot.owner}</div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
          
          {/* نتائج الأصوات */}
          {results.voices.length > 0 && (
            <section className="mb-12">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-[var(--neon)]">
                  {t("voices")} ({results.voices.length})
                </h2>
                <button className="text-blue-500 hover:text-blue-400">
                  {t("viewAll")} →
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {results.voices.map(voice => (
                  <div key={voice.id} className="bg-zinc-900 rounded-2xl shadow-lg overflow-hidden flex flex-col">
                    <div className="h-48 bg-zinc-800 flex items-center justify-center">
                      <img src={voice.img} alt={voice.name} className="max-h-40 max-w-full" />
                    </div>
                    <div className="p-4 flex-1 flex flex-col">
                      <div className="font-bold text-lg mb-1">{voice.name}</div>
                      <div className="text-xs text-gray-400 mb-3">Creator: {voice.creator}</div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
          
          {/* نتائج الإضافات */}
          {results.addons.length > 0 && (
            <section className="mb-12">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-[var(--neon)]">
                  {t("addons")} ({results.addons.length})
                </h2>
                <button className="text-blue-500 hover:text-blue-400">
                  {t("viewAll")} →
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {results.addons.map(addon => (
                  <div key={addon.id} className="bg-zinc-900 rounded-2xl shadow-lg overflow-hidden flex flex-col">
                    <div className="h-48 bg-zinc-800 flex items-center justify-center">
                      <img src={addon.img} alt={addon.name} className="max-h-40 max-w-full" />
                    </div>
                    <div className="p-4 flex-1 flex flex-col">
                      <div className="font-bold text-lg mb-1">{addon.name}</div>
                      <div className="text-xs text-gray-400 mb-3">Developer: {addon.developer}</div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </>
      )}
    </main>
  );
}