import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";

// ------------------------------------------------------------
// Rbotly — Marketplace / Bots NFT
// - Neon Blue on Dark
// - 4 Languages (AR, EN, FR, EL)
// - Filters: search, language, price min/max, tags, sort
// - Mock data; actions: Try (preview), Buy (checkout)
// ------------------------------------------------------------

const DICT = {
  ar: {
    PAGE_TITLE: "بوتات NFT",
    PAGE_SUB: "بوتات NFT نقوم بصناعتها وطرحها للبيع. اختر وجرب قبل الشراء.",
    BACK: "رجوع إلى السوق",
    LANGUAGE: "اللغة",
    FILTERS: "الفلاتر",
    SEARCH_PLACEHOLDER: "ابحث داخل بوتات الـNFT...",
    ALL: "الكل",
    MIN: "الأدنى",
    MAX: "الأعلى",
    PRICE: "السعر",
    TAGS: "الوسوم (افصل بفواصل ,)",
    SORT_BY: "الترتيب",
    SORT_DEFAULT: "الأحدث",
    SORT_PRICE_ASC: "السعر ↑",
    SORT_PRICE_DESC: "السعر ↓",
    RESET: "إعادة تعيين",
    TOKENS: "توكن",
    TRY: "جرّب البوت",
    BUY: "شراء",
    NO_RESULTS: "لا توجد نتائج مطابقة.",
    ITEMS: "عناصر",
  },
  en: {
    PAGE_TITLE: "Bots NFT",
    PAGE_SUB: "Hand-crafted NFT bots. Browse, try, then buy.",
    BACK: "Back to Market",
    LANGUAGE: "Language",
    FILTERS: "Filters",
    SEARCH_PLACEHOLDER: "Search NFT bots...",
    ALL: "All",
    MIN: "Min",
    MAX: "Max",
    PRICE: "Price",
    TAGS: "Tags (comma-separated)",
    SORT_BY: "Sort",
    SORT_DEFAULT: "Newest",
    SORT_PRICE_ASC: "Price ↑",
    SORT_PRICE_DESC: "Price ↓",
    RESET: "Reset",
    TOKENS: "Token",
    TRY: "Try bot",
    BUY: "Buy",
    NO_RESULTS: "No matching results.",
    ITEMS: "items",
  },
  fr: {
    PAGE_TITLE: "Bots NFT",
    PAGE_SUB: "Bots NFT conçus par nous. Parcourez, essayez, achetez.",
    BACK: "Retour au Marché",
    LANGUAGE: "Langue",
    FILTERS: "Filtres",
    SEARCH_PLACEHOLDER: "Rechercher des bots NFT...",
    ALL: "Tous",
    MIN: "Min",
    MAX: "Max",
    PRICE: "Prix",
    TAGS: "Mots-clés (séparés par des virgules)",
    SORT_BY: "Tri",
    SORT_DEFAULT: "Plus récent",
    SORT_PRICE_ASC: "Prix ↑",
    SORT_PRICE_DESC: "Prix ↓",
    RESET: "Réinitialiser",
    TOKENS: "Jeton",
    TRY: "Essayer le bot",
    BUY: "Acheter",
    NO_RESULTS: "Aucun résultat correspondant.",
    ITEMS: "articles",
  },
  el: {
    PAGE_TITLE: "Bots NFT",
    PAGE_SUB: "NFT bots από εμάς. Περιηγήσου, δοκίμασε, αγόρασε.",
    BACK: "Πίσω στην Αγορά",
    LANGUAGE: "Γλώσσα",
    FILTERS: "Φίλτρα",
    SEARCH_PLACEHOLDER: "Αναζήτηση NFT bots...",
    ALL: "Όλα",
    MIN: "Ελάχιστο",
    MAX: "Μέγιστο",
    PRICE: "Τιμή",
    TAGS: "Ετικέτες (χωρίζονται με κόμμα)",
    SORT_BY: "Ταξινόμηση",
    SORT_DEFAULT: "Νεότερα",
    SORT_PRICE_ASC: "Τιμή ↑",
    SORT_PRICE_DESC: "Τιμή ↓",
    RESET: "Επαναφορά",
    TOKENS: "Token",
    TRY: "Δοκίμασε bot",
    BUY: "Αγορά",
    NO_RESULTS: "Δεν βρέθηκαν αποτελέσματα.",
    ITEMS: "αντικείμενα",
  },
};

const NFTS = [
  {
    id: "nft-guardian-01",
    name: "Guardian AI",
    description: "Bot NFT للحماية والمراقبة الذكية.",
    image: "https://placehold.co/640x360/png",
    priceTokens: 1200,
    language: "ar",
    tags: ["security", "monitoring"],
    createdAt: 1722100000000,
  },
  {
    id: "nft-mentor-02",
    name: "Mentor AI",
    description: "Bot NFT للتعليم والدروس القصيرة.",
    image: "https://placehold.co/640x360/png",
    priceTokens: 950,
    language: "en",
    tags: ["education"],
    createdAt: 1722200000000,
  },
  {
    id: "nft-stylist-03",
    name: "Stylist AI",
    description: "Bot NFT لموضة ولبس يومي.",
    image: "https://placehold.co/640x360/png",
    priceTokens: 720,
    language: "fr",
    tags: ["lifestyle", "fashion"],
    createdAt: 1722300000000,
  },
  {
    id: "nft-trader-04",
    name: "Trader AI",
    description: "Bot NFT مساعد تداول أساسي.",
    image: "https://placehold.co/640x360/png",
    priceTokens: 1400,
    language: "el",
    tags: ["finance"],
    createdAt: 1722400000000,
  },
  {
    id: "nft-chef-05",
    name: "Chef AI",
    description: "Bot NFT للوصفات والأطباق اليومية.",
    image: "https://placehold.co/640x360/png",
    priceTokens: 680,
    language: "ar",
    tags: ["cooking"],
    createdAt: 1722500000000,
  },
];

function useI18n(lang) {
  return (k) => (DICT[lang]?.[k] ?? DICT.en[k] ?? k);
}

function useRTL(lang) {
  useEffect(() => {
    const rtl = lang === "ar";
    document.documentElement.dir = rtl ? "rtl" : "ltr";
    document.documentElement.lang = lang;
  }, [lang]);
}

function Chip({ children }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-cyan-300/30 bg-cyan-300/10 px-2.5 py-1 text-xs text-cyan-100">
      {children}
    </span>
  );
}

function Card({ t, item, onTry, onBuy }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-cyan-300/25 bg-gradient-to-b from-cyan-400/10 to-cyan-400/5 shadow-[0_0_24px_rgba(0,229,255,0.12)]"
    >
      <div className="aspect-video w-full overflow-hidden bg-black/60">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={item.image}
          alt={item.name}
          className="h-full w-full object-cover opacity-90 transition-opacity duration-200 group-hover:opacity-100"
        />
      </div>
      <div className="p-4">
        <div className="font-semibold tracking-wide text-cyan-100">{item.name}</div>
        <div className="mt-1 line-clamp-2 text-sm text-cyan-100/80">{item.description}</div>
        <div className="mt-3 flex items-center justify-between">
          <div className="font-mono text-cyan-200">{item.priceTokens} {t("TOKENS")}</div>
          <div className="flex gap-2">
            <button
              onClick={() => onTry?.(item)}
              className="rounded-md border border-cyan-300/40 px-3 py-1.5 text-sm text-cyan-50 hover:bg-cyan-500/10"
            >
              {t("TRY")}
            </button>
            <button
              onClick={() => onBuy?.(item)}
              className="rounded-md border border-cyan-300/40 px-3 py-1.5 text-sm text-cyan-50 hover:bg-cyan-500/10"
            >
              {t("BUY")}
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export default function MarketBotsNFTPage() {
  const [lang, setLang] = useState("ar");
  const t = useI18n(lang);
  useRTL(lang);

  const [q, setQ] = useState("");
  const [langFilter, setLangFilter] = useState("all");
  const [minP, setMinP] = useState("");
  const [maxP, setMaxP] = useState("");
  const [tags, setTags] = useState("");
  const [sort, setSort] = useState("default");

  const match = (item) => {
    const text = `${item.name} ${item.description}`.toLowerCase();
    if (q && !text.includes(q.toLowerCase())) return false;
    if (langFilter !== "all" && item.language !== langFilter) return false;
    const p = item.priceTokens ?? 0;
    if (minP !== "" && p < Number(minP)) return false;
    if (maxP !== "" && p > Number(maxP)) return false;
    const tagList = tags
      .split(",")
      .map((s) => s.trim().toLowerCase())
      .filter(Boolean);
    if (tagList.length) {
      const itemTags = (item.tags || []).map((s) => s.toLowerCase());
      const ok = tagList.every((tg) => itemTags.includes(tg));
      if (!ok) return false;
    }
    return true;
  };

  const filtered = useMemo(() => {
    let list = NFTS.filter(match);
    if (sort === "price-asc") list = [...list].sort((a, b) => (a.priceTokens || 0) - (b.priceTokens || 0));
    else if (sort === "price-desc") list = [...list].sort((a, b) => (b.priceTokens || 0) - (a.priceTokens || 0));
    else list = [...list].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)); // default newest
    return list;
  }, [q, langFilter, minP, maxP, tags, sort, lang]);

  const onTry = (item) => {
    window.location.href = `/market/preview/${item.id}`;
  };
  const onBuy = (item) => {
    window.location.href = `/checkout/${item.id}`;
  };

  const resetFilters = () => {
    setQ("");
    setLangFilter("all");
    setMinP("");
    setMaxP("");
    setTags("");
    setSort("default");
  };

  return (
    <div className="min-h-screen w-full bg-[#05060a] bg-[radial-gradient(1200px_600px_at_10%_-10%,rgba(0,229,255,0.08),transparent_40%),radial-gradient(900px_500px_at_90%_0%,rgba(0,229,255,0.06),transparent_35%)] text-cyan-50">
      <div className="mx-auto max-w-6xl px-5 py-8">
        {/* Header */}
        <header className="mb-6">
          <div className="mb-2 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <a
                href="/market"
                className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10"
              >
                ← {t("BACK")}
              </a>
              <motion.h1
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="text-[clamp(24px,3.4vw,36px)] font-extrabold tracking-wide text-cyan-100 drop-shadow-[0_0_22px_rgba(0,229,255,0.18)]"
              >
                {t("PAGE_TITLE")}
              </motion.h1>
            </div>
            <select
              value={lang}
              onChange={(e) => setLang(e.target.value)}
              className="min-w-[140px] rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 outline-none ring-0 transition focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            >
              <option value="ar">العربية</option>
              <option value="en">English</option>
              <option value="fr">Français</option>
              <option value="el">Ελληνικά</option>
            </select>
          </div>
          <p className="text-cyan-100/80">{t("PAGE_SUB")}</p>
        </header>

        {/* Filters */}
        <div className="mb-6 rounded-2xl border border-cyan-300/30 bg-gradient-to-b from-cyan-400/10 to-cyan-400/5 p-4 shadow-[0_0_30px_rgba(0,229,255,0.12)]">
          <div className="mb-3 flex items-center justify-between">
            <strong className="text-cyan-100">{t("FILTERS")}</strong>
            <div className="flex flex-wrap items-center gap-2">
              <Chip>NFT Only</Chip>
              <Chip>Neon UI</Chip>
              <Chip>{filtered.length} {t("ITEMS")}</Chip>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-6">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("SEARCH_PLACEHOLDER")}
              className="col-span-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20 sm:col-span-2 lg:col-span-6"
            />
            <select
              value={langFilter}
              onChange={(e) => setLangFilter(e.target.value)}
              className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            >
              <option value="all">{t("ALL")}</option>
              <option value="ar">العربية</option>
              <option value="en">English</option>
              <option value="fr">Français</option>
              <option value="el">Ελληνικά</option>
            </select>
            <input
              type="number"
              inputMode="numeric"
              value={minP}
              onChange={(e) => setMinP(e.target.value)}
              placeholder={t("MIN")}
              className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            />
            <input
              type="number"
              inputMode="numeric"
              value={maxP}
              onChange={(e) => setMaxP(e.target.value)}
              placeholder={t("MAX")}
              className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            />
            <input
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder={t("TAGS")}
              className="col-span-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20 sm:col-span-2 lg:col-span-3"
            />
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            >
              <option value="default">{t("SORT_DEFAULT")}</option>
              <option value="price-asc">{t("SORT_PRICE_ASC")}</option>
              <option value="price-desc">{t("SORT_PRICE_DESC")}</option>
            </select>
            <button
              onClick={resetFilters}
              className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10"
            >
              {t("RESET")}
            </button>
          </div>
        </div>

        {/* Cards */}
        {filtered.length === 0 ? (
          <div className="rounded-2xl border border-cyan-300/25 bg-black/30 p-6 text-center text-cyan-100/80">
            {t("NO_RESULTS")}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((item) => (
              <Card key={item.id} t={t} item={item} onTry={onTry} onBuy={onBuy} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
