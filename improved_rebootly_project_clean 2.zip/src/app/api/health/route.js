import { NextResponse } from 'next/server';

// Simple health check endpoint. Returns a JSON object indicating that the
// application is running. Useful for smoke testing during development.
export async function GET() {
  return NextResponse.json({ status: 'ok' });
}