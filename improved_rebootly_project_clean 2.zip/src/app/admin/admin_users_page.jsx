// AdminUsersPage.js - إدارة المستخدمين (Canva)
// مع دعم الترجمة الرباعية EN, AR, FR, EL

import { useState } from "react";
import { admin_users_en } from "./admin_users_en";
import { admin_users_ar } from "./admin_users_ar";
import { admin_users_fr } from "./admin_users_fr";
import { admin_users_el } from "./admin_users_el";

const translations = {
  en: admin_users_en,
  ar: admin_users_ar,
  fr: admin_users_fr,
  el: admin_users_el,
};

// بيانات وهمية كمثال
const usersList = [
  { id: 1, name: "Ahmed Ali", email: "ahmed@example.com", status: "active", role: "user" },
  { id: 2, name: "Sara Elbaz", email: "sara@example.com", status: "inactive", role: "seller" },
  { id: 3, name: "John Doe", email: "john@example.com", status: "active", role: "admin" },
];

export default function AdminUsersPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [users, setUsers] = useState(usersList);

  // أماكن الربط مع API لتغيير الحالة أو الدور مستقبلاً
  const handleToggleStatus = (id) => {
    // TODO: هنا الربط مع API لتفعيل/تعطيل المستخدم
    setUsers(users.map(u => u.id === id ? { ...u, status: u.status === "active" ? "inactive" : "active" } : u));
  };
  const handleChangeRole = (id) => {
    // TODO: هنا الربط مع API لتغيير دور المستخدم
    setUsers(users.map(u => u.id === id ? { ...u, role: u.role === "user" ? "seller" : "user" } : u));
  };

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("usersTitle")}</h1>
      <table className="w-full table-auto text-left border">
        <thead>
          <tr className="bg-zinc-900">
            <th className="p-2 border">#</th>
            <th className="p-2 border">{t("name")}</th>
            <th className="p-2 border">{t("email")}</th>
            <th className="p-2 border">{t("status")}</th>
            <th className="p-2 border">{t("role")}</th>
            <th className="p-2 border">{t("actions")}</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u, i) => (
            <tr key={u.id} className="border-t">
              <td className="p-2 border">{i + 1}</td>
              <td className="p-2 border">{u.name}</td>
              <td className="p-2 border">{u.email}</td>
              <td className="p-2 border">
                <span className={u.status === "active" ? "text-green-400" : "text-red-400"}>
                  {t(u.status)}
                </span>
              </td>
              <td className="p-2 border">{t(u.role)}</td>
              <td className="p-2 border flex gap-2">
                <button onClick={() => handleToggleStatus(u.id)} className="bg-blue-700 hover:bg-blue-800 text-white px-3 py-1 rounded">
                  {u.status === "active" ? t("deactivate") : t("activate")}
                </button>
                <button onClick={() => handleChangeRole(u.id)} className="bg-yellow-500 hover:bg-yellow-600 text-black px-3 py-1 rounded">
                  {u.role === "user" ? t("makeSeller") : t("makeUser")}
                </button>
                {/* مكان لإضافة زر حذف أو مراسلة أو إدارة متقدمة */}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}

// ----------- ملفات الترجمة الأربعة (مثال) -----------
// admin_users_en.js
export const admin_users_en = {
  usersTitle: "Manage Users",
  name: "Name",
  email: "Email",
  status: "Status",
  role: "Role",
  actions: "Actions",
  active: "Active",
  inactive: "Inactive",
  user: "User",
  seller: "Seller",
  admin: "Admin",
  activate: "Activate",
  deactivate: "Deactivate",
  makeSeller: "Make Seller",
  makeUser: "Make User",
};
// admin_users_ar.js
export const admin_users_ar = {
  usersTitle: "إدارة المستخدمين",
  name: "الاسم",
  email: "البريد الإلكتروني",
  status: "الحالة",
  role: "الدور",
  actions: "إجراءات",
  active: "نشط",
  inactive: "غير نشط",
  user: "مستخدم",
  seller: "بائع",
  admin: "مشرف",
  activate: "تفعيل",
  deactivate: "تعطيل",
  makeSeller: "جعله بائع",
  makeUser: "جعله مستخدم",
};
// admin_users_fr.js
export const admin_users_fr = {
  usersTitle: "Gérer les utilisateurs",
  name: "Nom",
  email: "E-mail",
  status: "Statut",
  role: "Rôle",
  actions: "Actions",
  active: "Actif",
  inactive: "Inactif",
  user: "Utilisateur",
  seller: "Vendeur",
  admin: "Admin",
  activate: "Activer",
  deactivate: "Désactiver",
  makeSeller: "Nommer vendeur",
  makeUser: "Nommer utilisateur",
};
// admin_users_el.js
export const admin_users_el = {
  usersTitle: "Διαχείριση χρηστών",
  name: "Όνομα",
  email: "Email",
  status: "Κατάσταση",
  role: "Ρόλος",
  actions: "Ενέργειες",
  active: "Ενεργός",
  inactive: "Ανενεργός",
  user: "Χρήστης",
  seller: "Πωλητής",
  admin: "Διαχειριστής",
  activate: "Ενεργοποίηση",
  deactivate: "Απενεργοποίηση",
  makeSeller: "Ορισμός ως πωλητής",
  makeUser: "Ορισμός ως χρήστης",
};
