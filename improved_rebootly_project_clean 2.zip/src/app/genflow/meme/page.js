import { useState } from 'react';
import { useTranslation } from 'next-i18next';
import { serverSideTranslations } from 'next-i18next/serverSideTranslations';

export default function TextToMemePage() {
  const { t } = useTranslation('common');
  const [description, setDescription] = useState('');
  const [memeUrl, setMemeUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerateMeme = async () => {
    setIsLoading(true);
    setMemeUrl('');

    try {
      // ❌ API خارجي لاحقًا
      const mockImage = 'https://api.memegen.link/images/custom/_/Funny_Meme_Goes_Here.png?background=https://i.imgur.com/aZkPzAL.jpeg';
      setTimeout(() => {
        setMemeUrl(mockImage);
        setIsLoading(false);
      }, 1500);
    } catch (err) {
      console.error(err);
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-6 text-[var(--neon)]">
        {t('TextToMeme.title')}
      </h1>

      <div className="max-w-2xl space-y-6">
        <textarea
          className="w-full p-4 rounded-xl bg-zinc-900 text-white"
          rows={3}
          placeholder={t('TextToMeme.placeholder')}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />

        <button
          className="bg-[var(--neon)] text-black font-bold px-6 py-3 rounded-xl hover:opacity-80"
          onClick={handleGenerateMeme}
          disabled={isLoading || !description}
        >
          {isLoading ? t('TextToMeme.loading') : t('TextToMeme.generate')}
        </button>

        {memeUrl && (
          <div className="mt-6">
            <h2 className="text-xl mb-4">{t('TextToMeme.preview')}</h2>
            <img src={memeUrl} alt="Generated Meme" className="rounded-xl w-full max-w-md" />
          </div>
        )}
      </div>
    </main>
  );
}

export async function getStaticProps({ locale }) {
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common'])),
    },
  };
}
