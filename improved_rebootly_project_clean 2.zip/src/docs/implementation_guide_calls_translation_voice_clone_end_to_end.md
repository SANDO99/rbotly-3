# دليل التنفيذ الشامل — مكالمات + ترجمة + استنساخ صوت (من الطرف للطرف)

> وثيقة عملية خطوة‑بخطوة بدون تشتيت. تغطي البنية، الربط، النماذج، عقود الـAPI/WS، الإعدادات، ونقاط الاختبار والإطلاق. تُكمل الملفات المنشورة في الورقة البيضاء: **Calls (Audio + Video) with Translation UI & Phone Bridge — Complete React + Signaling** و **Call Translation & Voice Clone — UX, Settings & FAQ**.

---

## 0) نظرة عامة (المكوّنات)

- **Client (Web/React):** صفحة/وحدة المكالمات (صوت+فيديو) + لوحة الترجمة + زر الجسر الهاتفي.
- **Signaling Server (WS):** تمرير الدعوات/العرض/الجواب/ICE بين المستخدمين (لا ينقل وسائط).
- **TURN/Coturn (VPS مستقل):** Relay للوسائط عند فشل P2P؛ منافذ UDP/TCP/TLS.
- **Media Gateway (WS):** بوابة الزمن الحقيقي لربط الواجهة مع خدمات الذكاء (ASR/MT/TTS/Voice‑Clone) عبر بروتوكول موحّد (start/media/partial/final/audio).
- **خدمات الذكاء مفتوحة المصدر:**
  - **ASR:** Whisper/faster‑whisper.
  - **MT:** M2M100 (أساسي) + OPUS‑MT (+ IndicTrans2 للغات جنوب آسيا).
  - **TTS:** Piper (طبيعي) + eSpeak NG (تغطية أساسية).
  - **Voice‑Clone:** Coqui XTTS‑v2 (اختياري؛ “التحدث بصوتي”).
- **Capabilities Service:** تُرجع قائمة اللغات/الأزواج/حالة الصوت (Natural/Basic/Captions) ديناميكيًا.
- **Phone Bridge (اختياري لاحقًا):** بوابة PSTN عبر مزود اتصالات (رقم موحّد + PIN جلسة).

---

## 1) هيكلة المستودع (Repo)

```
apps/
  web/                    # React + i18n + Calls UI (الملفات المضافة موجودة)
  signaling/              # خادم WebSocket للإشارات
  media-gateway/          # WS ينسّق جلسات ASR/MT/TTS/VC بين الكلاينت وخدمات الذكاء
services/
  asr-whisper/            # REST/WS لنسخ الصوت (Whisper)
  mt-m2m100/              # REST/WS للترجمة (M2M100 + OPUS-MT)
  tts-piper/              # REST/WS لتوليد الصوت الطبيعي
  tts-basic-espeak/       # REST/WS لصوت أساسي شامل اللغات
  voice-clone-xtts/       # REST/WS للاستنساخ وتخزين voiceprints
  capabilities/           # REST يعيد قدرات اللغات من الواقع
infra/
  turn/                   # إعداد Coturn + منافذ + شهادات TLS
  deploy/                 # قوالب Docker/Compose/K8s + .env.example
```

---

## 2) البيئة والمتغيّرات (Env)

- **العميل (apps/web/.env)**
  - `VITE_CALL_WS_URL=wss://<signaling-domain>`
  - `VITE_TURN_URL=turns:turn.<domain>:5349` (أو 443)
  - `VITE_TURN_USER=...` / `VITE_TURN_CRED=...`
- **الإشارات (apps/signaling/.env)**
  - `PORT=8080` (أو خلف Nginx على `/ws`)
  - (اختياري) سرّ JWT لو أضفت تحقق هوية.
- **البوابة (apps/media-gateway/.env)**
  - عناوين خدمات الذكاء: `ASR_URL=...`، `MT_URL=...`، `TTS_URL=...`، `BASIC_TTS_URL=...`، `VC_URL=...`
  - حدود الزمن والبتّ.
- **الخدمات (services/\*/.env)**
  - مسارات النماذج، نوع الجهاز (CPU/GPU)، حدود الحِمل.

إدارة الأسرار عبر: Vault/1Password أو Docker secrets؛ لا تُرفع للريبو.

---

## 3) TURN/Coturn (VPS منفصل)

**خطوات مختصرة:**

1. VPS عام + IP ثابت + نطاق `turn.<domain>`.
2. تثبيت Coturn وإصدار شهادة TLS (Let’s Encrypt) لـ 5349/TCP.
3. فتح المنافذ:
   - 3478/UDP و3478/TCP، 5349/TCP (TLS)، (اختياري 443/TCP TLS)، ومدى **UDP 49152–65535**.
4. تفعيل **Long‑Term Credentials** أو **TURN REST Auth** (سِر يولّد حسابات مؤقتة).
5. اختبار Trickle ICE من شبكات مختلفة حتى تظهر مسارات **relay** وتنجح المكالمة.

**ملاحظة:** الفيديو يستهلك باندويث أعلى؛ راقب NIC والRelay Ratio وأضف عقدًا جغرافية عند الحاجة.

---

## 4) Signaling WebSocket

**مسار الرسائل (JSON):**

- `auth {type, token?, userId}`
- `presence {type: 'presence', online: {<userId>: true}}`
- `call:invite {toUserId, callId}`
- `call:accept|decline|end {toUserId, callId}`
- `webrtc:offer|answer {toUserId, callId, offer|answer}`
- `webrtc:ice {toUserId, callId, candidate}`

**قبول (DoD):** مكالمة 1:1 تعمل صوتًا وفيديو عبر شبكات مختلفة بنسبة نجاح ICE ≥ 98%.

---

## 5) Media Gateway (WS واحد موحّد)

توفّر قناة واحدة للترجمة الصوتية بنمط بث:

- **from client → gateway:**
  - `start { sessionId, userId, listenLang, useMyVoice }`
  - `media { pcm16le, sampleRate, chunkMs }` (شظايا 200–300ms)
  - `stop {}`
- **from gateway → client:**
  - `partial { text, lang, timestamp }` (ASR جزئي)
  - `final { text, lang, timestamp }` (ASR نهائي)
  - `translated { text, srcLang, dstLang }` (MT)
  - `audio { dstLang, format: 'pcm16', chunk }` (TTS مجزّأ)
  - `state { level, hint }` (مؤشرات حالة: fallback/basic/captions)

**سير العمل:**

1. gateway يوجّه الصوت إلى **ASR** (Whisper)، ويتلقّى partial/final.
2. يرسل النص إلى **MT** حسب `listenLang`.
3. يمرّر النص إلى **TTS**:
   - إن كان `useMyVoice=true` ويحمل المستخدم بصمة صوت صالحة → **XTTS**.
   - وإلا Piper؛ وإن لم تتوفر لغة → eSpeak؛ وإن تعذر الصوت → Captions فقط.
4. يعود بالصوت كـ `audio` chunks + نص مترجم `translated`.

---

## 6) Capabilities Service (REST)

**Endpoint:** `GET /capabilities` **الاستجابة (مثال):**

```json
{
  "asr": ["ar", "el", "en", "fr", "es", "ur", "bn", "fa", "ps"],
  "mt": {
    "direct": [["ar","el"],["ar","fr"],["ur","el"], ["bn","en"], ["fa","el"], ["ps","ar"]],
    "pivot": "en"
  },
  "tts": {
    "natural": ["ar", "el", "en", "fr", "es"],
    "basic": ["ur", "bn", "fa"],
    "captionsOnly": ["ps"]
  },
  "voiceClone": true
}
```

**ملاحظة:** هذه القيم تُولَّد من الواقع (ما هو مثبّت ومتوافر فعليًا) وتتغير تلقائيًا.

---

## 7) خدمات الذكاء (نطاق الخدمات)

### 7.1 ASR — Whisper/faster‑whisper

- **مدخل WS**: PCM16 16kHz (أو 8kHz + resample في البوابة)، شظايا 200–300ms.
- **خروج**: `partial`/`final` نص + رمز اللغة (LID داخل Whisper).
- **أداء**: GPU يفضّل للكمون؛ CPU مقبول للحِمل الخفيف.

### 7.2 MT — M2M100 (+ OPUS‑MT + IndicTrans2)

- **عقدة أساسية**: M2M100 لاتجاهات مباشرة قدر الإمكان.
- **Fallback**: عبر الإنجليزية (pivot) عند غياب زوج مباشر.
- **واجهة**: REST/WS بسيط: `{text, srcLang?, dstLang} -> {text}`.

### 7.3 TTS — Piper + eSpeak NG

- **Piper**: أصوات طبيعية للغات المتوفّرة؛ صيغة PCM16 16kHz.
- **eSpeak NG**: يغطي أي لغة تقريبًا (جودة أساسية) — يستخدم فقط عند عدم توفر Piper/XTTS.

### 7.4 Voice‑Clone — Coqui XTTS‑v2 (اختياري)

- **Enroll (مرة واحدة):** رفع/تسجيل 30–60 ثانية → إنشاء Voiceprint مشفر وربطه بالمستخدم.
- **Synthesize:** `{text, lang, voiceId} -> audio PCM16`.
- **موافقة وحذف:** endpoints لإعادة التسجيل والحذف.

---

## 8) ربط الواجهة (Calls UI) بما سبق

- **CallContext/CallHUD/Incoming/Buttons** (موجودة): تتعامل مع WebRTC + Signaling + TURN.
- **TranslationPanel**: عند تفعيل الترجمة:
  1. يفتح WS إلى **Media Gateway**.
  2. يبدأ `start{ listenLang, useMyVoice }`.
  3. يبثّ صوت الميكروفون (نفس Stream الصوت للمكالمة أو نسخة مسجّلة) كـ `media`.
  4. يشغل الصوت الراجع **كـ مسار منفصل** أو `<audio>` عبر SourceBuffer.
  5. يعرض Captions من رسائل `partial/final/translated`.
- **PhoneBridgeButton**: يضرب `/api/phone/start` ليعيد `{number, pin, expiresAt}`.

---

## 9) الهاتف (Phone Bridge) — اختيار لاحق

- **جلسة PIN**: المستخدم يضغط "Phone bridge" → السيرفر يولّد PIN مؤقت 2–3 دقائق.
- **المتصل الخارجي** يتصل بالرقم الموحّد ويدخل الـPIN → يربطه السيرفر بجلسة المستخدم.
- **Media**: من مزود الاتصالات إلى **Media Gateway** عبر WebSocket (8kHz μ‑law → 16kHz PCM).
- **نفس المسار**: ASR→MT→TTS باتجاهين.

---

## 10) الأمان والخصوصية (مكثّف وبسيط)

- **JWT** داخل إشارات WebSocket + حدود معدّل (rate limiting).
- **SRTP/DTLS** مشفّر تلقائيًا عبر WebRTC.
- **TURN REST Auth** (حسابات مؤقتة).
- **Voice‑Clone Opt‑in**: موافقة صريحة مرة واحدة + زر حذف فوري + تخزين voiceprint مشفر فقط.
- **Logs** بلا محتوى صوتي/نصي حساس؛ معرّفات جلسات فقط.

---

## 11) المراقبة (Observability)

- **مكالمات**: ICE success, relay ratio, call drop rate.
- **ASR/MT/TTS**: latency p50/p95، أخطاء، fallback counts.
- **Gateway**: زمن round‑trip من `media` إلى `audio` و`translated`.
- **SLO**: كمون ≤ 1.5s؛ فوالب الصوت < 10%؛ نجاح الاتصال ≥ 98%.

---

## 12) الاختبارات (QA)

- شبكات: منزل/هاتف/شركة (UDP محجوب) → تأكد من relay عبر TURN.
- لغات: AR↔EL، AR↔FR، AR↔EN، AR↔ES، UR↔EL، BN↔EN، FA↔EL، PS (Captions/Basic).
- تغيير Listen‑in أثناء المكالمة.
- تشغيل/إيقاف الكاميرا والمايك.
- Voice‑Clone: تفعيل/تعطيل أثناء المكالمة + حذف وإعادة تسجيل.

---

## 13) خطة الإطلاق (Phases)

- **P0**: WebRTC + TURN + Signaling (صوت/فيديو) + Captions (ASR) → إنتاج.
- **P1**: MT + TTS (Natural/Basic) + Capabilities Service.
- **P2**: Voice‑Clone (اختياري) + إعدادات/FAQ + مراقبة كاملة.
- **P3**: Phone Bridge (اختياري) + أرقام محلية إضافية.

---

## 14) قبول نهائي (Definition of Done)

- المكالمة تعمل صوت/فيديو عبر شبكات مختلفة.
- الترجمة الصوتية تعمل لأي لغة مختارة من القائمة، مع فوالب سلسة.
- i18n (AR/EN/FR/EL) لجميع النصوص الجديدة.
- الإعدادات وFAQ وفق الوثيقة، بدون تنبيهات مزعجة داخل المكالمة.
- المراقبة فعّالة وتحقق SLO.

---

## 15) ملاحظات تشغيلية

- حد أقصى مبدئي للفيديو 360p\@15fps لتقليل الحمل؛ ارفع تدريجيًا حسب القياسات.
- قصّ الصوت إلى 200–300ms لزمن استجابة منخفض.
- حافظ على فصل TURN عن باقي الخدمات؛ أضف عقدًا عند زيادة الجمهور.
- حدّد جداول صيانة لأصوات Piper وتدريب أصوات جديدة حسب الطلبات.

---

**انتهى الدليل.** أي بند تريد تحويله الآن إلى مهام تنفيذية تفصيلية (Tickets)، قل لي وأنشّطها بندًا بندًا في ورقة منفصلة.

