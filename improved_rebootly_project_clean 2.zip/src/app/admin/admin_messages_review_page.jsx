// AdminMessagesReviewPage.js - صفحة مراجعة الرسائل مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const admin_messages_review_en = {
  messagesReviewTitle: "Messages Review",
  from: "From",
  email: "Email",
  date: "Date",
  status: "Status",
  read: "Read",
  unread: "Unread",
  actions: "Actions",
  view: "View",
  markRead: "Mark as Read",
  markUnread: "Mark as Unread",
};
export const admin_messages_review_ar = {
  messagesReviewTitle: "مراجعة الرسائل",
  from: "من",
  email: "البريد الإلكتروني",
  date: "التاريخ",
  status: "الحالة",
  read: "مقروءة",
  unread: "غير مقروءة",
  actions: "إجراءات",
  view: "عرض",
  markRead: "تعيين كمقروءة",
  markUnread: "تعيين كغير مقروءة",
};
export const admin_messages_review_fr = {
  messagesReviewTitle: "Revue des messages",
  from: "De",
  email: "E-mail",
  date: "Date",
  status: "Statut",
  read: "Lu",
  unread: "Non lu",
  actions: "Actions",
  view: "Voir",
  markRead: "Marquer comme lu",
  markUnread: "Marquer comme non lu",
};
export const admin_messages_review_el = {
  messagesReviewTitle: "Αξιολόγηση μηνυμάτων",
  from: "Από",
  email: "Email",
  date: "Ημερομηνία",
  status: "Κατάσταση",
  read: "Διαβασμένο",
  unread: "Μη αναγνωσμένο",
  actions: "Ενέργειες",
  view: "Προβολή",
  markRead: "Σήμανση ως διαβασμένο",
  markUnread: "Σήμανση ως μη αναγνωσμένο",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: admin_messages_review_en,
  ar: admin_messages_review_ar,
  fr: admin_messages_review_fr,
  el: admin_messages_review_el,
};

const mockMessages = [
  { id: 1, from: "Ali Khaled", email: "ali@example.com", date: "2025-08-07", status: "unread" },
  { id: 2, from: "Julia Petit", email: "julia@example.com", date: "2025-08-06", status: "read" },
  { id: 3, from: "Ziad Tarek", email: "ziad@example.com", date: "2025-08-05", status: "unread" },
];

export default function AdminMessagesReviewPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [messages, setMessages] = useState(mockMessages);

  const handleToggleRead = (id) => {
    setMessages(messages.map(m => m.id === id ? {
      ...m,
      status: m.status === "read" ? "unread" : "read"
    } : m));
  };

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("messagesReviewTitle")}</h1>
      <table className="w-full table-auto text-left border">
        <thead>
          <tr className="bg-zinc-900">
            <th className="p-2 border">#</th>
            <th className="p-2 border">{t("from")}</th>
            <th className="p-2 border">{t("email")}</th>
            <th className="p-2 border">{t("date")}</th>
            <th className="p-2 border">{t("status")}</th>
            <th className="p-2 border">{t("actions")}</th>
          </tr>
        </thead>
        <tbody>
          {messages.map((m, i) => (
            <tr key={m.id} className="border-t">
              <td className="p-2 border">{i + 1}</td>
              <td className="p-2 border">{m.from}</td>
              <td className="p-2 border">{m.email}</td>
              <td className="p-2 border">{m.date}</td>
              <td className="p-2 border">
                <span className={
                  m.status === "read" ? "text-green-400" : "text-yellow-400"
                }>
                  {t(m.status)}
                </span>
              </td>
              <td className="p-2 border flex gap-2">
                <button className="bg-blue-700 hover:bg-blue-800 text-white px-3 py-1 rounded">
                  {t("view")}
                </button>
                <button
                  onClick={() => handleToggleRead(m.id)}
                  className="bg-gray-600 hover:bg-gray-700 text-white px-3 py-1 rounded"
                >
                  {m.status === "read" ? t("markUnread") : t("markRead")}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}
