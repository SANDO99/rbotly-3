// AdminProductsReviewPage.js - مراجعة المنتجات (Canva)
// مع دعم الترجمة الرباعية EN, AR, FR, EL

import { useState } from "react";
import { admin_products_review_en } from "./admin_products_review_en";
import { admin_products_review_ar } from "./admin_products_review_ar";
import { admin_products_review_fr } from "./admin_products_review_fr";
import { admin_products_review_el } from "./admin_products_review_el";

const translations = {
  en: admin_products_review_en,
  ar: admin_products_review_ar,
  fr: admin_products_review_fr,
  el: admin_products_review_el,
};

// بيانات وهمية للمنتجات كمثال
const mockProducts = [
  { id: 1, name: "Botly Voice Pack", type: "voice", status: "pending", owner: "sara@example.com" },
  { id: 2, name: "Mixtral Bot", type: "bot", status: "approved", owner: "john@example.com" },
  { id: 3, name: "Educational Dataset", type: "file", status: "rejected", owner: "ali@example.com" },
];

export default function AdminProductsReviewPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [products, setProducts] = useState(mockProducts);

  // أماكن الربط مع API للموافقة أو الرفض مستقبلاً
  const handleApprove = (id) => {
    // TODO: ربط مع API لاعتماد المنتج
    setProducts(products.map(p => p.id === id ? { ...p, status: "approved" } : p));
  };
  const handleReject = (id) => {
    // TODO: ربط مع API لرفض المنتج
    setProducts(products.map(p => p.id === id ? { ...p, status: "rejected" } : p));
  };

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("productsReviewTitle")}</h1>
      <table className="w-full table-auto text-left border">
        <thead>
          <tr className="bg-zinc-900">
            <th className="p-2 border">#</th>
            <th className="p-2 border">{t("name")}</th>
            <th className="p-2 border">{t("type")}</th>
            <th className="p-2 border">{t("owner")}</th>
            <th className="p-2 border">{t("status")}</th>
            <th className="p-2 border">{t("actions")}</th>
          </tr>
        </thead>
        <tbody>
          {products.map((p, i) => (
            <tr key={p.id} className="border-t">
              <td className="p-2 border">{i + 1}</td>
              <td className="p-2 border">{p.name}</td>
              <td className="p-2 border">{t(p.type)}</td>
              <td className="p-2 border">{p.owner}</td>
              <td className="p-2 border">
                <span className={
                  p.status === "approved" ? "text-green-400" :
                  p.status === "pending" ? "text-yellow-400" : "text-red-400"
                }>
                  {t(p.status)}
                </span>
              </td>
              <td className="p-2 border flex gap-2">
                {p.status !== "approved" && (
                  <button onClick={() => handleApprove(p.id)} className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded">
                    {t("approve")}
                  </button>
                )}
                {p.status !== "rejected" && (
                  <button onClick={() => handleReject(p.id)} className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded">
                    {t("reject")}
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}

// ----------- ملفات الترجمة الأربعة (مثال) -----------
// admin_products_review_en.js
export const admin_products_review_en = {
  productsReviewTitle: "Products Review",
  name: "Name",
  type: "Type",
  voice: "Voice Extension",
  bot: "Bot",
  file: "File",
  owner: "Owner",
  status: "Status",
  approved: "Approved",
  pending: "Pending",
  rejected: "Rejected",
  actions: "Actions",
  approve: "Approve",
  reject: "Reject",
};
// admin_products_review_ar.js
export const admin_products_review_ar = {
  productsReviewTitle: "مراجعة المنتجات",
  name: "الاسم",
  type: "النوع",
  voice: "إضافة صوت",
  bot: "بوت",
  file: "ملف",
  owner: "المالك",
  status: "الحالة",
  approved: "معتمد",
  pending: "بانتظار المراجعة",
  rejected: "مرفوض",
  actions: "إجراءات",
  approve: "اعتماد",
  reject: "رفض",
};
// admin_products_review_fr.js
export const admin_products_review_fr = {
  productsReviewTitle: "Revue des produits",
  name: "Nom",
  type: "Type",
  voice: "Extension vocale",
  bot: "Bot",
  file: "Fichier",
  owner: "Propriétaire",
  status: "Statut",
  approved: "Approuvé",
  pending: "En attente",
  rejected: "Rejeté",
  actions: "Actions",
  approve: "Approuver",
  reject: "Rejeter",
};
// admin_products_review_el.js
export const admin_products_review_el = {
  productsReviewTitle: "Αξιολόγηση προϊόντων",
  name: "Όνομα",
  type: "Τύπος",
  voice: "Φωνητική επέκταση",
  bot: "Bot",
  file: "Αρχείο",
  owner: "Ιδιοκτήτης",
  status: "Κατάσταση",
  approved: "Εγκρίθηκε",
  pending: "Σε αναμονή",
  rejected: "Απορρίφθηκε",
  actions: "Ενέργειες",
  approve: "Έγκριση",
  reject: "Απόρριψη",
};
