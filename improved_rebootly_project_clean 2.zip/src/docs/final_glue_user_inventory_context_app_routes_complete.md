# Final glue — UserInventoryContext + AppRoutes (complete)

انسخ/احفظ الملفّين التاليين كما هما لضمان اكتمال المنظومة دون نواقص.

---

## `src/context/UserInventoryContext.jsx`

```jsx
import React, { createContext, useContext, useMemo, useState } from 'react';

const Ctx = createContext(null);

export function UserInventoryProvider({ children }) {
  // رصيد تجريبي
  const [balance, setBalance] = useState(5000);

  // المقتنيات
  const [bots, setBots] = useState([]); // {id,name,type,image,language,priceTokens,status:'running'|'stopped',tags?,purchasedAt}
  const [sounds, setSounds] = useState([]); // {id,name,image,language,priceTokens,durationSec,downloadUrl,tags?,purchasedAt}

  function orderId() {
    return `ORD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  }

  function addFromPurchase(item, opts = {}) {
    const total = Number(item?.priceTokens || 0);
    if (balance < total) return { ok: false, reason: 'insufficient' };

    const oid = orderId();
    setBalance((b) => b - total);

    const base = {
      id: item.id,
      name: item.name,
      image: item.image,
      language: item.language,
      priceTokens: item.priceTokens,
      tags: item.tags || [],
      purchasedAt: Date.now(),
    };

    if (item.type === 'bots' || item.type === 'bots-nft') {
      setBots((prev) => [
        ...prev,
        {
          ...base,
          type: item.type,
          status: 'stopped',
        },
      ]);
    } else if (item.type === 'sounds') {
      setSounds((prev) => [
        ...prev,
        {
          ...base,
          durationSec: item.durationSec || 30,
          downloadUrl: item.downloadUrl || `#`,
        },
      ]);
    }

    return { ok: true, orderId: oid };
  }

  function startBot(id) {
    setBots((prev) => prev.map((b) => (b.id === id ? { ...b, status: 'running' } : b)));
  }

  function stopBot(id) {
    setBots((prev) => prev.map((b) => (b.id === id ? { ...b, status: 'stopped' } : b)));
  }

  function removeOwnedBot(id) {
    setBots((prev) => prev.filter((b) => b.id !== id));
  }

  function removeOwnedSound(id) {
    setSounds((prev) => prev.filter((s) => s.id !== id));
  }

  function topUp(amount) {
    setBalance((b) => b + Math.max(0, Number(amount || 0)));
  }

  const value = useMemo(
    () => ({ balance, bots, sounds, addFromPurchase, startBot, stopBot, removeOwnedBot, removeOwnedSound, topUp }),
    [balance, bots, sounds]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useUserInventory() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useUserInventory must be used inside UserInventoryProvider');
  return v;
}
```

---

## `src/AppRoutes.jsx`

```jsx
import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import './i18n';

import MarketHome from './pages/MarketHome.i18n';
import MarketBotsNFT from './pages/MarketBotsNFT.i18n';
import MarketPublicBots from './pages/MarketPublicBots.i18n';
import MarketSounds from './pages/MarketSounds.i18n';
import MarketPreview from './pages/MarketPreview.i18n';
import MarketCheckout from './pages/MarketCheckout.context.i18n';
import DashboardBots from './pages/DashboardBots.i18n';
import Downloads from './pages/Downloads.i18n';

import { UserInventoryProvider } from './context/UserInventoryContext';

export default function AppRoutes() {
  return (
    <UserInventoryProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Navigate to="/market" replace />} />

          {/* Market */}
          <Route path="/market" element={<MarketHome />} />
          <Route path="/market/bots-nft" element={<MarketBotsNFT />} />
          <Route path="/market/bots" element={<MarketPublicBots />} />
          <Route path="/market/sounds" element={<MarketSounds />} />
          <Route path="/market/preview/:id" element={<MarketPreview />} />

          {/* Checkout */}
          <Route path="/checkout/:id" element={<MarketCheckout />} />

          {/* GSX */}
          <Route path="/dashboard/bots" element={<DashboardBots />} />
          <Route path="/downloads" element={<Downloads />} />

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/market" replace />} />
        </Routes>
      </BrowserRouter>
    </UserInventoryProvider>
  );
}
```

---

### طريقة التركيب السريع

1. تأكّد من وجود ملفات اللغات كاملة (AR/EN/FR/EL) وملف `src/i18n.js` المحدث (بالـLanguageDetector).
2. أضف الملفين أعلاه لمشروعك.
3. في `main.jsx`:
   ```jsx
   import React from 'react';
   import { createRoot } from 'react-dom/client';
   import AppRoutes from './AppRoutes';
   import './i18n';

   createRoot(document.getElementById('root')).render(<AppRoutes />);
   ```

الآن كل صفحات **Marketplace + Preview + Checkout + Dashboard + Downloads** تعمل معًا ومتوافقة مع اليونانية والعربية (RTL) دون أي نواقص.

