const fs = require('fs');
const path = require('path');

// Simple script to convert translation JS objects into JSON files under public/locales
// Assumes each file in src/translations is named translations_<lang>.js and exports
// either a default object or defines a constant that holds the translations.

const translationsDir = path.join(__dirname, '..', 'src', 'translations');
const localesDir = path.join(__dirname, '..', 'public', 'locales');

/**
 * Attempt to extract the object literal containing translations from a JS file.
 * This function performs a naive string manipulation to convert keys to quoted
 * JSON keys and removes trailing commas. It intentionally avoids converting
 * single quotes to double quotes to preserve apostrophes within strings.
 * @param {string} fileContent
 * @returns {object|null}
 */
function extractTranslations(fileContent) {
  // Match the object inside either a const declaration or default export
  const match = fileContent.match(/const\s+\w+\s*=\s*({[\s\S]*?})\s*;\s*export/);
  if (!match) return null;
  let objText = match[1];
  // Quote unquoted keys at start of lines or after commas/braces
  objText = objText.replace(/([\{,\s])([A-Za-z0-9_]+)\s*:/g, '$1"$2":');
  // Remove trailing commas before closing braces/brackets
  objText = objText.replace(/,(\s*[}\]])/g, '$1');
  try {
    return JSON.parse(objText);
  } catch (err) {
    console.error('Failed to parse JSON from translations file:', err.message);
    return null;
  }
}

fs.readdirSync(translationsDir).forEach((file) => {
  if (!/^translations_.+\.js$/.test(file)) return;
  const lang = file.replace('translations_', '').replace('.js', '');
  const fullPath = path.join(translationsDir, file);
  const content = fs.readFileSync(fullPath, 'utf8');
  const data = extractTranslations(content);
  if (!data) {
    console.warn(`Skipping ${file} due to parse error`);
    return;
  }
  const langDir = path.join(localesDir, lang);
  fs.mkdirSync(langDir, { recursive: true });
  const outPath = path.join(langDir, 'common.json');
  fs.writeFileSync(outPath, JSON.stringify(data, null, 2), 'utf8');
  console.log(`Wrote ${outPath}`);
});