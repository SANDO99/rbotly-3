// AdminModelControlPage.js - صفحة التحكم في النماذج مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const admin_model_control_en = {
  modelControlTitle: "Model Control",
  modelName: "Model Name",
  status: "Status",
  running: "Running",
  stopped: "Stopped",
  locked: "Locked",
  actions: "Actions",
  start: "Start",
  stop: "Stop",
  lock: "Lock",
  unlock: "Unlock",
};
export const admin_model_control_ar = {
  modelControlTitle: "التحكم في النماذج",
  modelName: "اسم النموذج",
  status: "الحالة",
  running: "يعمل",
  stopped: "متوقف",
  locked: "مقفل",
  actions: "إجراءات",
  start: "تشغيل",
  stop: "إيقاف",
  lock: "قفل",
  unlock: "فتح القفل",
};
export const admin_model_control_fr = {
  modelControlTitle: "Contrôle des modèles",
  modelName: "Nom du modèle",
  status: "Statut",
  running: "En cours",
  stopped: "Arrêté",
  locked: "Verrouillé",
  actions: "Actions",
  start: "Démarrer",
  stop: "Arrêter",
  lock: "Verrouiller",
  unlock: "Déverrouiller",
};
export const admin_model_control_el = {
  modelControlTitle: "Έλεγχος μοντέλων",
  modelName: "Όνομα μοντέλου",
  status: "Κατάσταση",
  running: "Σε λειτουργία",
  stopped: "Διακόπηκε",
  locked: "Κλειδωμένο",
  actions: "Ενέργειες",
  start: "Εκκίνηση",
  stop: "Διακοπή",
  lock: "Κλείδωμα",
  unlock: "Ξεκλείδωμα",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: admin_model_control_en,
  ar: admin_model_control_ar,
  fr: admin_model_control_fr,
  el: admin_model_control_el,
};

// بيانات وهمية للنماذج
const mockModels = [
  { id: 1, name: "Whisper ASR", status: "running" },
  { id: 2, name: "Mixtral LLM", status: "stopped" },
  { id: 3, name: "Coqui TTS", status: "locked" },
];

export default function AdminModelControlPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [models, setModels] = useState(mockModels);

  // أماكن الربط مع API للتحكم الفعلي بالنماذج
  const handleChangeStatus = (id, action) => {
    setModels(models.map(m => {
      if (m.id !== id) return m;
      if (action === "start") return { ...m, status: "running" };
      if (action === "stop") return { ...m, status: "stopped" };
      if (action === "lock") return { ...m, status: "locked" };
      if (action === "unlock") return { ...m, status: "stopped" };
      return m;
    }));
  };

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("modelControlTitle")}</h1>
      <table className="w-full table-auto text-left border">
        <thead>
          <tr className="bg-zinc-900">
            <th className="p-2 border">#</th>
            <th className="p-2 border">{t("modelName")}</th>
            <th className="p-2 border">{t("status")}</th>
            <th className="p-2 border">{t("actions")}</th>
          </tr>
        </thead>
        <tbody>
          {models.map((m, i) => (
            <tr key={m.id} className="border-t">
              <td className="p-2 border">{i + 1}</td>
              <td className="p-2 border">{m.name}</td>
              <td className="p-2 border">
                <span className={
                  m.status === "running" ? "text-green-400" :
                  m.status === "stopped" ? "text-yellow-400" : "text-red-400"
                }>
                  {t(m.status)}
                </span>
              </td>
              <td className="p-2 border flex gap-2">
                {m.status !== "running" && m.status !== "locked" && (
                  <button onClick={() => handleChangeStatus(m.id, "start")} className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded">
                    {t("start")}
                  </button>
                )}
                {m.status === "running" && (
                  <button onClick={() => handleChangeStatus(m.id, "stop")} className="bg-yellow-500 hover:bg-yellow-600 text-black px-3 py-1 rounded">
                    {t("stop")}
                  </button>
                )}
                {m.status !== "locked" && (
                  <button onClick={() => handleChangeStatus(m.id, "lock")} className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded">
                    {t("lock")}
                  </button>
                )}
                {m.status === "locked" && (
                  <button onClick={() => handleChangeStatus(m.id, "unlock")} className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded">
                    {t("unlock")}
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}
