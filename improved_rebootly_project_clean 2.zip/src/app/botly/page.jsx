// BotlyChatPage.js - صفحة بوتلي المساعد الذكي (Canva) مع دعم الترجمة الرباعية وهيكل جاهز للـ Agents وAPI Services

import { useState } from "react";
import { translations_en } from "./translations_en";
import { translations_ar } from "./translations_ar";
import { translations_fr } from "./translations_fr";
import { translations_el } from "./translations_el";

// ---- خدمات الربط مع الأجندة والوكلاء (Agents/Dispatcher) ----
// هنا مستقبلاً سيتم ربط كل الأوامر بالاجانب/الخدمات الخارجية
async function dispatchToAgent(command) {
  // TODO: هنا تمرير الطلب للأجندة الذكية
  // مثال (mock): إذا الأمر فيه "طقس" رد بجملة ثابتة
  if (command.toLowerCase().includes("طقس") || command.toLowerCase().includes("weather")) {
    return "حالة الطقس اليوم صافية";
  }
  // مستقبلًا هنا ربط Mixtral / Whisper / Coqui XTTS / Tavily / Deepgram / ...
  return "تم استلام الأمر! سيتم تنفيذ الطلب قريبًا...";
}

// --- مكوّن عرض الرسائل ---
function BotlyMessageList({ messages }) {
  return (
    <div className="flex flex-col gap-3">
      {messages.map((msg, idx) => (
        <div
          key={idx}
          className={
            msg.from === "bot"
              ? "self-start bg-blue-900 text-white px-4 py-2 rounded-2xl shadow"
              : "self-end bg-[var(--neon)] text-black px-4 py-2 rounded-2xl shadow"
          }
        >
          {msg.text}
        </div>
      ))}
    </div>
  );
}

// --- أزرار الصوت (المجاني + المدفوع) مع أماكن ربط الخدمات مستقبلاً ---
function BotlyVoiceButtons({ t, onFreeMic, onPremiumMic }) {
  return (
    <div className="flex gap-2">
      {/* زر الميكروفون المجاني */}
      <button
        className="bg-blue-800 hover:bg-blue-900 text-white px-3 py-2 rounded-full shadow"
        title={t("freeMic")}
        onClick={onFreeMic}
      >
        <span role="img" aria-label="mic">🎤</span>
      </button>
      {/* زر الميكروفون المدفوع */}
      <button
        className="bg-yellow-400 hover:bg-yellow-500 text-black px-3 py-2 rounded-full shadow"
        title={t("premiumMic")}
        onClick={onPremiumMic}
      >
        <span role="img" aria-label="gold mic">🎤</span>
      </button>
    </div>
  );
}

// --- شريط الإدخال ---
function BotlyInputBar({ t, onSend, onFreeMic, onPremiumMic }) {
  const [input, setInput] = useState("");
  return (
    <div className="flex gap-2 items-center px-2 pb-4">
      <BotlyVoiceButtons t={t} onFreeMic={onFreeMic} onPremiumMic={onPremiumMic} />
      <input
        type="text"
        className="flex-1 px-4 py-2 rounded-xl bg-zinc-800 text-white focus:outline-none"
        placeholder={t("typeMessage")}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={async (e) => {
          if (e.key === "Enter" && input.trim()) {
            await onSend(input);
            setInput("");
          }
        }}
      />
      <button
        onClick={async () => {
          if (input.trim()) {
            await onSend(input);
            setInput("");
          }
        }}
        className="bg-[var(--neon)] text-black font-bold px-4 py-2 rounded-xl shadow hover:scale-105 transition"
      >
        {t("send")}
      </button>
    </div>
  );
}

// ---- ملفات الترجمة الرباعية ----
const languages = {
  en: translations_en,
  ar: translations_ar,
  fr: translations_fr,
  el: translations_el,
};

// --- الصفحة الرئيسية ---
export default function BotlyChatPage({ locale = "en" }) {
  const t = (key) => languages[locale][key] || key;
  const [messages, setMessages] = useState([
    { from: "bot", text: t("placeholderBotMessage") },
  ]);

  // ربط زر الإرسال بالأجندة الذكية
  const handleSend = async (text) => {
    setMessages((msgs) => [...msgs, { from: "user", text }]);
    // تمرير الأمر للأجندة (Agent Dispatcher)
    const botReply = await dispatchToAgent(text);
    setMessages((msgs) => [
      ...msgs,
      { from: "bot", text: botReply },
    ]);
  };

  // أماكن ربط الميكروفونات بالخدمات الخارجية مستقبلاً
  const handleFreeMic = () => {
    // TODO: هنا سيتم ربط التسجيل الصوتي بالنموذج المجاني (Phi-3 أو غيره)
    alert('سيتم ربط الميكروفون المجاني هنا لاحقًا!');
  };
  const handlePremiumMic = () => {
    // TODO: هنا سيتم ربط التسجيل الصوتي بسلسلة Mixtral + Whisper + Coqui XTTS أو أي API مدفوع
    alert('سيتم ربط الميكروفون المدفوع هنا لاحقًا!');
  };

  return (
    <main className="min-h-screen bg-black flex flex-col justify-between items-center p-0">
      <div className="w-full max-w-md flex flex-col flex-1">
        <header className="bg-zinc-900 p-4 text-center rounded-b-2xl shadow-xl">
          <h1 className="text-2xl font-bold text-[var(--neon)]">{t("chatWithBot")}</h1>
        </header>
        <div className="flex-1 overflow-y-auto px-2 py-4">
          <BotlyMessageList messages={messages} />
        </div>
        <BotlyInputBar
          t={t}
          onSend={handleSend}
          onFreeMic={handleFreeMic}
          onPremiumMic={handlePremiumMic}
        />
      </div>
    </main>
  );
}

// ----------------- ملفات الترجمة الأربعة (مثال، وكل ملف مستقل عن الآخر) -----------------
// translations_en.js
export const translations_en = {
  chatWithBot: "Chat with Botly",
  typeMessage: "Type your message...",
  send: "Send",
  freeMic: "Free Mic",
  premiumMic: "Premium Mic",
  placeholderBotMessage: "Hello! How can I assist you today?",
  placeholderUserMessage: "Your message...",
};
// translations_ar.js
export const translations_ar = {
  chatWithBot: "الدردشة مع بوتلي",
  typeMessage: "اكتب رسالتك...",
  send: "إرسال",
  freeMic: "ميكروفون مجاني",
  premiumMic: "ميكروفون مدفوع",
  placeholderBotMessage: "مرحبًا! كيف يمكنني مساعدتك اليوم؟",
  placeholderUserMessage: "رسالتك...",
};
// translations_fr.js
export const translations_fr = {
  chatWithBot: "Discuter avec Botly",
  typeMessage: "Écrivez votre message...",
  send: "Envoyer",
  freeMic: "Micro gratuit",
  premiumMic: "Micro premium",
  placeholderBotMessage: "Bonjour! Comment puis-je vous aider aujourd'hui?",
  placeholderUserMessage: "Votre message...",
};
// translations_el.js
export const translations_el = {
  chatWithBot: "Συνομιλία με τον Botly",
  typeMessage: "Πληκτρολογήστε το μήνυμά σας...",
  send: "Αποστολή",
  freeMic: "Δωρεάν μικρόφωνο",
  premiumMic: "Premium μικρόφωνο",
  placeholderBotMessage: "Γεια σας! Πώς μπορώ να σας βοηθήσω σήμερα;",
  placeholderUserMessage: "Το μήνυμά σας...",
};
