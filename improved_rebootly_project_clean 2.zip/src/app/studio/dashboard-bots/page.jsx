import React from "react";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { useUserInventory } from "../context/UserInventoryContext";
import { useBotStudio } from "../context/BotStudioContext";

export default function DashboardBots(){
  const { t } = useTranslation();
  const inv = useUserInventory();
  const studio = useBotStudio();

  return (
    <div className="min-h-screen w-full bg-[#05060a] text-cyan-50">
      <div className="mx-auto max-w-7xl px-5 py-8">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <h1 className="text-2xl font-extrabold text-cyan-100">{t('MY_BOTS',{defaultValue:'My Bots'})}</h1>
            <div className="text-sm text-cyan-300/70">{t('BALANCE',{defaultValue:'Balance'})}: <span className="font-mono">{inv.balance}</span></div>
          </div>
          <button onClick={()=> inv.topUp(500)} className="rounded-xl border border-cyan-300/40 bg-black/30 px-3 py-1.5 text-xs hover:bg-cyan-500/10">
            {t('TOP_UP',{defaultValue:'Top up +500'})}
          </button>
        </div>

        {inv.bots.length === 0 ? (
          <div className="rounded-2xl border border-cyan-300/30 bg-black/30 p-6 text-cyan-200">
            {t('NO_BOTS_YET',{defaultValue:'You have no bots yet.'})}
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {inv.bots.map((b)=>{
              const activePlan = studio.isActive(String(b.id));
              return (
                <div key={b.id} className="group rounded-2xl border border-cyan-300/20 bg-[#0a0f16] p-4 shadow-md">
                  <div className="flex items-center gap-3">
                    <img src={b.image} alt={b.name} className="h-14 w-14 rounded-xl object-cover ring-1 ring-cyan-300/30"/>
                    <div className="mr-auto">
                      <div className="font-semibold text-cyan-100">{b.name}</div>
                      <div className="text-xs text-cyan-300/70">{b.type}</div>
                    </div>
                    <span className={`rounded-full px-2 py-0.5 text-[10px] ${activePlan ? 'border border-emerald-400/40 bg-emerald-400/10 text-emerald-200' : 'border border-rose-400/40 bg-rose-400/10 text-rose-200'}`}>
                      {activePlan ? t('PLAN_ACTIVE',{defaultValue:'Active'}) : t('PLAN_INACTIVE',{defaultValue:'Inactive'})}
                    </span>
                  </div>

                  <div className="mt-4 flex items-center gap-2">
                    {b.status === 'running' ? (
                      <button onClick={()=> inv.stopBot(b.id)} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10">{t('STOP',{defaultValue:'Stop'})}</button>
                    ) : (
                      <button onClick={()=> inv.startBot(b.id)} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10">{t('START',{defaultValue:'Start'})}</button>
                    )}
                    <Link to={`/dashboard/bots/${b.id}/train`} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10">
                      {t('TRAIN',{defaultValue:'Train'})}
                    </Link>
                    <button onClick={()=> inv.removeOwnedBot(b.id)} className="ml-auto rounded-lg border border-rose-300/30 px-3 py-1.5 text-xs text-rose-200 hover:bg-rose-500/10">
                      {t('REMOVE',{defaultValue:'Remove'})}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
