import React, { useEffect, useMemo, useRef, useState } from "react";
import { HashRouter, Routes, Route, Navigate, Link, useNavigate, useParams } from "react-router-dom";
import { motion } from "framer-motion";

// ============================================================================
// Rbotly Marketplace — Single-File App
// - Neon Blue on Dark theme
// - React Router v6 (HashRouter so it works on any static host)
// - Pages: /market, /market/bots-nft, /market/bots, /market/sounds,
//          /market/preview/:id, /checkout/:id
// - 4 languages: AR, EN, FR, EL  (with RTL for Arabic)
// - Mock data + buttons wired to real routes via <Link/> / useNavigate()
// ----------------------------------------------------------------------------
// Usage:
//   1) Put this as App.jsx (or index.jsx) in a React project with tailwind (optional).
//   2) Ensure react-router-dom + framer-motion installed.
//   3) Render <RbotlyApp/> at the root.
// ============================================================================

// --- i18n ---
const DICT = {
  ar: {
    MARKETPLACE_TITLE: "سوق Rbotly",
    HERO_SUBTITLE: "استكشف بوتات NFT والبوتات العامة وحِزم الأصوات.",
    SEARCH_PLACEHOLDER: "ابحث عن بوت أو صوت...",
    FILTERS: "الفلاتر",
    CATEGORY: "القسم",
    LANGUAGE: "اللغة",
    PRICE: "السعر",
    TAGS: "الوسوم (افصل بفواصل ,)",
    BOTS_NFT: "بوتات NFT",
    PUBLIC_BOTS: "بوتات عامة",
    SOUNDS: "الأصوات",
    VIEW_ALL: "تصفح الكل",
    TRY: "جرّب",
    BROWSE: "تصفّح",
    BUY: "شراء",
    ALL: "الكل",
    MIN: "الأدنى",
    MAX: "الأعلى",
    TOKENS: "توكن",
    NO_RESULTS: "لا توجد نتائج مطابقة.",
    BACK: "رجوع إلى السوق",
    // sounds
    GENDER: "الفئة الصوتية", GENDER_ALL: "الكل", GENDER_MALE: "رجل", GENDER_FEMALE: "امرأة", GENDER_CHILD: "طفل",
    PREVIEW: "معاينة", STOP: "إيقاف", DURATION: "المدة",
    // preview
    PAGE_TITLE_PREVIEW: "معاينة البوت", BUY_NOW: "اشترِ الآن", RESET: "إعادة ضبط الجلسة",
    INPUT_PLACEHOLDER: "اكتب رسالة للتجربة...", SEND: "إرسال", FREE_TRIAL: "تجربة مجانية: حتى 5 رسائل أو 500 توكن",
    MESSAGES: "رسائل", LIMIT_REACHED: "انتهت التجربة المجانية. قم بالشراء لمواصلة الاستخدام.", NOT_FOUND: "غير موجود", TRY_LEFT: "المتبقي", DESC: "الوصف",
    // nft/bots pages
    PAGE_TITLE_NFT: "بوتات NFT", PAGE_SUB_NFT: "بوتات NFT نصنعها ونطرحها للبيع.",
    PAGE_TITLE_PUBLIC: "بوتات عامة", PAGE_SUB_PUBLIC: "بوتات يرفعها المستخدمون.",
    // sounds page
    PAGE_TITLE_SOUNDS: "الأصوات", PAGE_SUB_SOUNDS: "مكتبة أصوات جاهزة.",
    // checkout
    TITLE_CHECKOUT: "الدفع", ITEM: "المنتج", TYPE: "النوع", PRICE: "السعر", BALANCE: "رصيدي", TOTAL: "الإجمالي",
    TERMS: "أوافق على الشروط والأحكام", PAY: "ادفع بالتوكن", INSUFFICIENT: "الرصيد غير كافٍ", PROCESSING: "جارٍ المعالجة...",
    SUCCESS: "تم الدفع بنجاح", SUCCESS_DESC_NFT: "تم سكّ الـNFT وإضافته إلى حسابك.", SUCCESS_DESC_BOT: "تمت إضافة البوت إلى لوحتك.", SUCCESS_DESC_SOUND: "الصوت جاهز للتنزيل.",
    DELIVERY: "خيارات التسليم", HOST_ON_PLATFORM: "استخدامه على المنصة", DOWNLOAD_FILES: "تنزيل الملفات",
    SUMMARY: "ملخص الطلب", QTY: "الكمية", ONE: "واحد", ID: "المعرف", BAL_AFTER: "الرصيد بعد الدفع", ORDER_ID: "رقم الطلب",
    CATEGORY_NFT: "NFT", CATEGORY_PUBLIC: "عام", CATEGORY_SOUND: "صوت",
    SORT_DEFAULT: "الأحدث", SORT_PRICE_ASC: "السعر ↑", SORT_PRICE_DESC: "السعر ↓", SORT_DURATION_ASC: "المدة ↑", SORT_DURATION_DESC: "المدة ↓",
    RESET_FILTERS: "إعادة تعيين",
  },
  en: {
    MARKETPLACE_TITLE: "Rbotly Marketplace",
    HERO_SUBTITLE: "Discover NFT bots, public bots, and voice packs.",
    SEARCH_PLACEHOLDER: "Search for a bot or voice...",
    FILTERS: "Filters",
    CATEGORY: "Category",
    LANGUAGE: "Language",
    PRICE: "Price",
    TAGS: "Tags (comma-separated)",
    BOTS_NFT: "Bots NFT",
    PUBLIC_BOTS: "Public Bots",
    SOUNDS: "Sounds",
    VIEW_ALL: "View all",
    TRY: "Try",
    BROWSE: "Browse",
    BUY: "Buy",
    ALL: "All",
    MIN: "Min",
    MAX: "Max",
    TOKENS: "Token",
    NO_RESULTS: "No matching results.",
    BACK: "Back to Market",
    GENDER: "Voice Type", GENDER_ALL: "All", GENDER_MALE: "Male", GENDER_FEMALE: "Female", GENDER_CHILD: "Child",
    PREVIEW: "Preview", STOP: "Stop", DURATION: "Duration",
    PAGE_TITLE_PREVIEW: "Bot Preview", BUY_NOW: "Buy Now", RESET: "Reset Session",
    INPUT_PLACEHOLDER: "Type a message to try...", SEND: "Send", FREE_TRIAL: "Free trial: up to 5 messages or 500 tokens",
    MESSAGES: "messages", LIMIT_REACHED: "Free trial ended. Please purchase to continue.", NOT_FOUND: "Not found", TRY_LEFT: "left", DESC: "Description",
    PAGE_TITLE_NFT: "Bots NFT", PAGE_SUB_NFT: "NFT bots made by us.",
    PAGE_TITLE_PUBLIC: "Public Bots", PAGE_SUB_PUBLIC: "Bots uploaded by users.",
    PAGE_TITLE_SOUNDS: "Sounds", PAGE_SUB_SOUNDS: "Library of ready voices.",
    TITLE_CHECKOUT: "Checkout", ITEM: "Item", TYPE: "Type", PRICE: "Price", BALANCE: "My balance", TOTAL: "Total",
    TERMS: "I agree to the Terms & Conditions", PAY: "Pay with tokens", INSUFFICIENT: "Insufficient balance", PROCESSING: "Processing...",
    SUCCESS: "Payment successful", SUCCESS_DESC_NFT: "NFT minted and added.", SUCCESS_DESC_BOT: "Bot added to your dashboard.", SUCCESS_DESC_SOUND: "Voice ready in downloads.",
    DELIVERY: "Delivery options", HOST_ON_PLATFORM: "Use on platform", DOWNLOAD_FILES: "Download files",
    SUMMARY: "Order Summary", QTY: "Qty", ONE: "One", ID: "ID", BAL_AFTER: "Balance after payment", ORDER_ID: "Order ID",
    CATEGORY_NFT: "NFT", CATEGORY_PUBLIC: "Public", CATEGORY_SOUND: "Sound",
    SORT_DEFAULT: "Newest", SORT_PRICE_ASC: "Price ↑", SORT_PRICE_DESC: "Price ↓", SORT_DURATION_ASC: "Duration ↑", SORT_DURATION_DESC: "Duration ↓",
    RESET_FILTERS: "Reset",
  },
  fr: {
    MARKETPLACE_TITLE: "Marché Rbotly",
    HERO_SUBTITLE: "Découvrez des bots NFT, des bots publics et des packs de voix.",
    SEARCH_PLACEHOLDER: "Recherchez un bot ou une voix...",
    FILTERS: "Filtres",
    CATEGORY: "Catégorie",
    LANGUAGE: "Langue",
    PRICE: "Prix",
    TAGS: "Mots-clés (séparés par des virgules)",
    BOTS_NFT: "Bots NFT",
    PUBLIC_BOTS: "Bots publics",
    SOUNDS: "Voix",
    VIEW_ALL: "Tout voir",
    TRY: "Essayer",
    BROWSE: "Parcourir",
    BUY: "Acheter",
    ALL: "Tous",
    MIN: "Min",
    MAX: "Max",
    TOKENS: "Jeton",
    NO_RESULTS: "Aucun résultat correspondant.",
    BACK: "Retour au Marché",
    GENDER: "Type de voix", GENDER_ALL: "Tous", GENDER_MALE: "Homme", GENDER_FEMALE: "Femme", GENDER_CHILD: "Enfant",
    PREVIEW: "Aperçu", STOP: "Arrêter", DURATION: "Durée",
    PAGE_TITLE_PREVIEW: "Aperçu du bot", BUY_NOW: "Acheter", RESET: "Réinitialiser",
    INPUT_PLACEHOLDER: "Écrivez un message pour tester...", SEND: "Envoyer", FREE_TRIAL: "Essai gratuit : 5 messages ou 500 jetons",
    MESSAGES: "messages", LIMIT_REACHED: "Essai terminé. Achetez pour continuer.", NOT_FOUND: "Introuvable", TRY_LEFT: "restants", DESC: "Description",
    PAGE_TITLE_NFT: "Bots NFT", PAGE_SUB_NFT: "Bots NFT conçus par nous.",
    PAGE_TITLE_PUBLIC: "Bots publics", PAGE_SUB_PUBLIC: "Bots ajoutés par les utilisateurs.",
    PAGE_TITLE_SOUNDS: "Voix", PAGE_SUB_SOUNDS: "Bibliothèque de voix prêtes.",
    TITLE_CHECKOUT: "Paiement", ITEM: "Article", TYPE: "Type", PRICE: "Prix", BALANCE: "Mon solde", TOTAL: "Total",
    TERMS: "J'accepte les Conditions Générales", PAY: "Payer avec des jetons", INSUFFICIENT: "Solde insuffisant", PROCESSING: "Traitement...",
    SUCCESS: "Paiement réussi", SUCCESS_DESC_NFT: "NFT frappé et ajouté.", SUCCESS_DESC_BOT: "Bot ajouté à votre tableau de bord.", SUCCESS_DESC_SOUND: "Voix disponible.",
    DELIVERY: "Options de livraison", HOST_ON_PLATFORM: "Utiliser sur la plateforme", DOWNLOAD_FILES: "Télécharger les fichiers",
    SUMMARY: "Récapitulatif", QTY: "Qté", ONE: "Un", ID: "ID", BAL_AFTER: "Solde après paiement", ORDER_ID: "ID Commande",
    CATEGORY_NFT: "NFT", CATEGORY_PUBLIC: "Public", CATEGORY_SOUND: "Voix",
    SORT_DEFAULT: "Plus récent", SORT_PRICE_ASC: "Prix ↑", SORT_PRICE_DESC: "Prix ↓", SORT_DURATION_ASC: "Durée ↑", SORT_DURATION_DESC: "Durée ↓",
    RESET_FILTERS: "Réinitialiser",
  },
  el: {
    MARKETPLACE_TITLE: "Αγορά Rbotly",
    HERO_SUBTITLE: "Ανακάλυψε NFT bots, δημόσια bots και πακέτα φωνών.",
    SEARCH_PLACEHOLDER: "Αναζήτησε bot ή φωνή...",
    FILTERS: "Φίλτρα",
    CATEGORY: "Κατηγορία",
    LANGUAGE: "Γλώσσα",
    PRICE: "Τιμή",
    TAGS: "Ετικέτες (χωρίζονται με κόμμα)",
    BOTS_NFT: "Bots NFT",
    PUBLIC_BOTS: "Δημόσια Bots",
    SOUNDS: "Ήχοι",
    VIEW_ALL: "Προβολή όλων",
    TRY: "Δοκίμασε",
    BROWSE: "Περιήγηση",
    BUY: "Αγορά",
    ALL: "Όλα",
    MIN: "Ελάχιστο",
    MAX: "Μέγιστο",
    TOKENS: "Token",
    NO_RESULTS: "Δεν βρέθηκαν αποτελέσματα.",
    BACK: "Πίσω στην Αγορά",
    GENDER: "Τύπος φωνής", GENDER_ALL: "Όλα", GENDER_MALE: "Άνδρας", GENDER_FEMALE: "Γυναίκα", GENDER_CHILD: "Παιδί",
    PREVIEW: "Προεπισκόπηση", STOP: "Διακοπή", DURATION: "Διάρκεια",
    PAGE_TITLE_PREVIEW: "Προεπισκόπηση Bot", BUY_NOW: "Αγορά τώρα", RESET: "Επαναφορά",
    INPUT_PLACEHOLDER: "Γράψε μήνυμα για δοκιμή...", SEND: "Αποστολή", FREE_TRIAL: "Δωρεάν δοκιμή: 5 μηνύματα ή 500 tokens",
    MESSAGES: "μηνύματα", LIMIT_REACHED: "Η δοκιμή ολοκληρώθηκε.", NOT_FOUND: "Δεν βρέθηκε", TRY_LEFT: "υπόλοιπο", DESC: "Περιγραφή",
    PAGE_TITLE_NFT: "Bots NFT", PAGE_SUB_NFT: "NFT bots από εμάς.",
    PAGE_TITLE_PUBLIC: "Δημόσια Bots", PAGE_SUB_PUBLIC: "Bots από χρήστες.",
    PAGE_TITLE_SOUNDS: "Ήχοι", PAGE_SUB_SOUNDS: "Βιβλιοθήκη φωνών.",
    TITLE_CHECKOUT: "Πληρωμή", ITEM: "Αντικείμενο", TYPE: "Τύπος", PRICE: "Τιμή", BALANCE: "Υπόλοιπο", TOTAL: "Σύνολο",
    TERMS: "Αποδέχομαι τους Όρους", PAY: "Πληρωμή με tokens", INSUFFICIENT: "Μη επαρκές υπόλοιπο", PROCESSING: "Επεξεργασία...",
    SUCCESS: "Η πληρωμή ολοκληρώθηκε", SUCCESS_DESC_NFT: "Το NFT κόπηκε.", SUCCESS_DESC_BOT: "Το bot προστέθηκε.", SUCCESS_DESC_SOUND: "Το πακέτο φωνής έτοιμο.",
    DELIVERY: "Επιλογές παράδοσης", HOST_ON_PLATFORM: "Χρήση στην πλατφόρμα", DOWNLOAD_FILES: "Λήψη αρχείων",
    SUMMARY: "Σύνοψη", QTY: "Ποσ.", ONE: "Ένα", ID: "ID", BAL_AFTER: "Υπόλοιπο μετά", ORDER_ID: "Κωδ. Παραγγελίας",
    CATEGORY_NFT: "NFT", CATEGORY_PUBLIC: "Δημόσιο", CATEGORY_SOUND: "Ήχος",
    SORT_DEFAULT: "Νεότερα", SORT_PRICE_ASC: "Τιμή ↑", SORT_PRICE_DESC: "Τιμή ↓", SORT_DURATION_ASC: "Διάρκεια ↑", SORT_DURATION_DESC: "Διάρκεια ↓",
    RESET_FILTERS: "Επαναφορά",
  },
};

function useI18n(lang) { return (k) => DICT[lang]?.[k] ?? DICT.en[k] ?? k; }
function useRTL(lang){ useEffect(()=>{ document.documentElement.dir = lang==='ar' ? 'rtl' : 'ltr'; document.documentElement.lang = lang; }, [lang]); }

// --- Mock data ---
const MOCK = {
  nfts: [
    { id:"nft-guardian-01", type:"bots-nft", name:"Guardian AI", description:"Bot NFT للحماية والمراقبة الذكية.", image:"https://placehold.co/640x360/png", priceTokens:1200, language:"ar", tags:["security","monitoring"], createdAt:1722100000000 },
    { id:"nft-mentor-02", type:"bots-nft", name:"Mentor AI", description:"Bot NFT للتعليم والدروس القصيرة.", image:"https://placehold.co/640x360/png", priceTokens:950, language:"en", tags:["education"], createdAt:1722200000000 },
    { id:"nft-stylist-03", type:"bots-nft", name:"Stylist AI", description:"Bot NFT لموضة ولبس يومي.", image:"https://placehold.co/640x360/png", priceTokens:720, language:"fr", tags:["lifestyle","fashion"], createdAt:1722300000000 },
    { id:"nft-trader-04", type:"bots-nft", name:"Trader AI", description:"Bot NFT مساعد تداول أساسي.", image:"https://placehold.co/640x360/png", priceTokens:1400, language:"el", tags:["finance"], createdAt:1722400000000 },
  ],
  bots: [
    { id:"public-researcher-01", type:"bots", name:"Researcher", description:"بوت للبحث الذكي عن المعلومات.", image:"https://placehold.co/640x360/png", priceTokens:300, language:"ar", tags:["research","web"], createdAt:1722200000000 },
    { id:"public-writer-02", type:"bots", name:"Writer", description:"بوت كتابة مقالات ومنشورات.", image:"https://placehold.co/640x360/png", priceTokens:280, language:"fr", tags:["writing"], createdAt:1722300000000 },
    { id:"public-coach-03", type:"bots", name:"Coach", description:"بوت نصائح يومية وتحفيز.", image:"https://placehold.co/640x360/png", priceTokens:260, language:"en", tags:["productivity"], createdAt:1722400000000 },
  ],
  sounds: [
    { id:"voice-orion", type:"sounds", name:"Orion Male", description:"صوت ذكوري واضح للرواية.", image:"https://placehold.co/640x360/png", priceTokens:150, language:"en", gender:"male", durationSec:38, tags:["male","narration","tts"], previewUrl:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3", createdAt:1722250000000 },
    { id:"voice-lyra", type:"sounds", name:"Lyra Female", description:"صوت أنثوي دافئ لفيديوهات قصيرة.", image:"https://placehold.co/640x360/png", priceTokens:160, language:"el", gender:"female", durationSec:25, tags:["female","shorts"], previewUrl:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3", createdAt:1722260000000 },
    { id:"voice-samir", type:"sounds", name:"Samir Arabic", description:"صوت عربي محايد للبرامج الحوارية.", image:"https://placehold.co/640x360/png", priceTokens:170, language:"ar", gender:"male", durationSec:42, tags:["male","neutral"], previewUrl:"https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3", createdAt:1722270000000 },
  ],
};

// Helpers
const CATS = [
  {key:"all", label:{ar:"الكل", en:"All", fr:"Tous", el:"Όλα"}},
  {key:"bots-nft", label:{ar:"بوتات NFT", en:"Bots NFT", fr:"Bots NFT", el:"Bots NFT"}},
  {key:"bots", label:{ar:"بوتات عامة", en:"Public Bots", fr:"Bots publics", el:"Δημόσια Bots"}},
  {key:"sounds", label:{ar:"الأصوات", en:"Sounds", fr:"Voix", el:"Ήχοι"}},
];

function Chip({children}){ return (<span className="inline-flex items-center gap-2 rounded-full border border-cyan-300/30 bg-cyan-300/10 px-2.5 py-1 text-xs text-cyan-100">{children}</span>); }
function Panel({children}){ return (<div className="rounded-2xl border border-cyan-300/30 bg-gradient-to-b from-cyan-400/10 to-cyan-400/5 p-4 shadow-[0_0_30px_rgba(0,229,255,0.12)]">{children}</div>); }

// =====================================================================================
// Home Page (/market)
// =====================================================================================
function HomePage(){
  const [lang, setLang] = useState('ar');
  const t = useI18n(lang); useRTL(lang);
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('all');
  const [langFilter, setLangFilter] = useState('all');
  const [minP, setMinP] = useState('');
  const [maxP, setMaxP] = useState('');
  const [tags, setTags] = useState('');
  const nav = useNavigate();

  function match(item){
    const text = (item.name + ' ' + item.description).toLowerCase();
    if(q && !text.includes(q.toLowerCase())) return false;
    if(langFilter !== 'all' && item.language !== langFilter) return false;
    const p = item.priceTokens ?? 0;
    if(minP !== '' && p < Number(minP)) return false;
    if(maxP !== '' && p > Number(maxP)) return false;
    const tagList = tags.split(',').map(s=>s.trim().toLowerCase()).filter(Boolean);
    if(tagList.length){
      const itemTags = (item.tags||[]).map(s=>s.toLowerCase());
      if(!tagList.every(tg => itemTags.includes(tg))) return false;
    }
    return true;
  }

  const data = useMemo(()=>{
    const bundles = {
      'bots-nft': MOCK.nfts.filter(match),
      'bots': MOCK.bots.filter(match),
      'sounds': MOCK.sounds.filter(match),
    };
    return cat === 'all' ? bundles : { [cat]: bundles[cat] };
  }, [q, cat, langFilter, minP, maxP, tags, lang]);

  const onTry = (item) => nav(`/market/preview/${item.id}`);
  const onBuy = (item) => nav(`/checkout/${item.id}`);
  const onBrowse = (item) => {
    if(item.type === 'bots-nft') nav('/market/bots-nft');
    else if(item.type === 'bots') nav('/market/bots');
    else nav('/market/sounds');
  };

  const Section = ({title, href, items}) => (
    <section className="mb-10">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h3 className="text-lg font-bold text-cyan-100">{title}</h3>
          <Chip>{items.length} items</Chip>
        </div>
        <Link to={href} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-sm text-cyan-50 hover:bg-cyan-500/10">{t('VIEW_ALL')}</Link>
      </div>
      {items.length === 0 ? (
        <div className="rounded-xl border border-cyan-300/25 bg-black/30 p-4 text-center text-cyan-100/80">{t('NO_RESULTS')}</div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.slice(0,6).map(item => (
            <Card key={item.id} item={item} t={t} onTry={onTry} onBuy={onBuy} onBrowse={onBrowse}/>
          ))}
        </div>
      )}
    </section>
  );

  return (
    <div className="min-h-screen w-full bg-[#05060a] bg-[radial-gradient(1200px_600px_at_10%_-10%,rgba(0,229,255,0.08),transparent_40%),radial-gradient(900px_500px_at_90%_0%,rgba(0,229,255,0.06),transparent_35%)] text-cyan-50">
      <div className="mx-auto max-w-6xl px-5 py-8">
        <header className="mb-6">
          <div className="mb-2 flex flex-wrap items-center justify-between gap-3">
            <motion.h1 initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} className="text-[clamp(26px,4vw,42px)] font-extrabold tracking-wide text-cyan-100 drop-shadow-[0_0_22px_rgba(0,229,255,0.18)]">{t('MARKETPLACE_TITLE')}</motion.h1>
            <select value={lang} onChange={e=>setLang(e.target.value)} className="min-w-[140px] rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 outline-none focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20">
              <option value="ar">العربية</option><option value="en">English</option><option value="fr">Français</option><option value="el">Ελληνικά</option>
            </select>
          </div>
          <p className="text-cyan-100/80">{t('HERO_SUBTITLE')}</p>
        </header>

        <Panel>
          <div className="mb-3 flex items-center justify-between">
            <strong className="text-cyan-100">{t('FILTERS')}</strong>
            <div className="flex flex-wrap gap-2"><Chip>AR/EN/FR/EL</Chip><Chip>Neon UI</Chip><Chip>Mock Data</Chip></div>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
            <input value={q} onChange={e=>setQ(e.target.value)} placeholder={t('SEARCH_PLACEHOLDER')} className="col-span-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 sm:col-span-2 lg:col-span-5"/>
            <select value={cat} onChange={e=>setCat(e.target.value)} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100">{CATS.map(c=> <option key={c.key} value={c.key}>{c.label[lang] ?? c.key}</option>)}</select>
            <select value={langFilter} onChange={e=>setLangFilter(e.target.value)} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100"><option value="all">{t('ALL')}</option><option value="ar">العربية</option><option value="en">English</option><option value="fr">Français</option><option value="el">Ελληνικά</option></select>
            <input type="number" value={minP} onChange={e=>setMinP(e.target.value)} placeholder={t('MIN')} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100"/>
            <input type="number" value={maxP} onChange={e=>setMaxP(e.target.value)} placeholder={t('MAX')} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100"/>
            <input value={tags} onChange={e=>setTags(e.target.value)} placeholder={t('TAGS')} className="col-span-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 sm:col-span-2 lg:col-span-5"/>
          </div>
        </Panel>

        {(cat==='all'||cat==='bots-nft') && <Section title={t('BOTS_NFT')} href="/market/bots-nft" items={data['bots-nft']||[]}/>}        
        {(cat==='all'||cat==='bots') && <Section title={t('PUBLIC_BOTS')} href="/market/bots" items={data['bots']||[]}/>}        
        {(cat==='all'||cat==='sounds') && <Section title={t('SOUNDS')} href="/market/sounds" items={data['sounds']||[]}/>}
      </div>
    </div>
  );
}

function Card({ t, item, onTry, onBuy, onBrowse }){
  return (
    <motion.div layout initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} className="group relative flex flex-col overflow-hidden rounded-2xl border border-cyan-300/25 bg-gradient-to-b from-cyan-400/10 to-cyan-400/5 shadow-[0_0_24px_rgba(0,229,255,0.12)]">
      <div className="aspect-video w-full overflow-hidden bg-black/60">
        {/* eslint-disable-next-line jsx-a11y/alt-text */}
        <img src={item.image} alt={item.name} className="h-full w-full object-cover opacity-90 transition-opacity group-hover:opacity-100"/>
      </div>
      <div className="p-4">
        <div className="font-semibold tracking-wide text-cyan-100">{item.name}</div>
        <div className="mt-1 line-clamp-2 text-sm text-cyan-100/80">{item.description}</div>
        <div className="mt-3 flex items-center justify-between">
          <div className="font-mono text-cyan-200">{item.priceTokens} {t('TOKENS')}</div>
          <div className="flex gap-2">
            <button onClick={()=>onTry?.(item)} className="rounded-md border border-cyan-300/40 px-3 py-1.5 text-sm text-cyan-50 hover:bg-cyan-500/10">{t('TRY')}</button>
            <button onClick={()=>onBrowse?.(item)} className="rounded-md border border-cyan-300/40 px-3 py-1.5 text-sm text-cyan-50 hover:bg-cyan-500/10">{t('BROWSE')}</button>
            <button onClick={()=>onBuy?.(item)} className="rounded-md border border-cyan-300/40 px-3 py-1.5 text-sm text-cyan-50 hover:bg-cyan-500/10">{t('BUY')}</button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// =====================================================================================
// Bots NFT Page
// =====================================================================================
function BotsNFTPage(){
  const [lang, setLang] = useState('ar'); const t = useI18n(lang); useRTL(lang);
  const [q, setQ] = useState(''); const [langFilter, setLangFilter] = useState('all'); const [minP,setMinP]=useState(''); const [maxP,setMaxP]=useState(''); const [tags,setTags]=useState(''); const [sort,setSort]=useState('default');
  const nav = useNavigate();
  function match(item){ const text=(item.name+" "+item.description).toLowerCase(); if(q && !text.includes(q.toLowerCase())) return false; if(langFilter!=='all'&&item.language!==langFilter) return false; const p=item.priceTokens||0; if(minP!==''&&p<Number(minP))return false; if(maxP!==''&&p>Number(maxP))return false; const tagList=tags.split(',').map(s=>s.trim().toLowerCase()).filter(Boolean); if(tagList.length){ const its=(item.tags||[]).map(s=>s.toLowerCase()); if(!tagList.every(tg=>its.includes(tg))) return false;} return true; }
  const filtered = useMemo(()=>{ let list = MOCK.nfts.filter(match); if(sort==='price-asc') list=[...list].sort((a,b)=>a.priceTokens-b.priceTokens); else if(sort==='price-desc') list=[...list].sort((a,b)=>b.priceTokens-a.priceTokens); else list=[...list].sort((a,b)=> (b.createdAt||0)-(a.createdAt||0)); return list; }, [q,langFilter,minP,maxP,tags,sort,lang]);
  const onTry = (item)=> nav(`/market/preview/${item.id}`);
  const onBuy = (item)=> nav(`/checkout/${item.id}`);
  const reset = ()=>{ setQ(''); setLangFilter('all'); setMinP(''); setMaxP(''); setTags(''); setSort('default'); };
  return (
    <Frame title={t('PAGE_TITLE_NFT')} back toLang={[lang,setLang]} subtitle={t('PAGE_SUB_NFT')}>
      <Panel>
        <div className="mb-3 flex items-center justify-between">
          <strong className="text-cyan-100">{t('FILTERS')}</strong>
          <div className="flex gap-2"><Chip>NFT</Chip><Chip>Neon</Chip><Chip>{filtered.length} items</Chip></div>
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-6">
          <input value={q} onChange={e=>setQ(e.target.value)} placeholder={t('SEARCH_PLACEHOLDER')} className="col-span-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 sm:col-span-2 lg:col-span-6"/>
          <select value={langFilter} onChange={e=>setLangFilter(e.target.value)} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100"><option value="all">{t('ALL')}</option><option value="ar">العربية</option><option value="en">English</option><option value="fr">Français</option><option value="el">Ελληνικά</option></select>
          <input type="number" value={minP} onChange={e=>setMinP(e.target.value)} placeholder={t('MIN')} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100"/>
          <input type="number" value={maxP} onChange={e=>setMaxP(e.target.value)} placeholder={t('MAX')} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100"/>
          <input value={tags} onChange={e=>setTags(e.target.value)} placeholder={t('TAGS')} className="col-span-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 sm:col-span-2 lg:col-span-3"/>
          <select value={sort} onChange={e=>setSort(e.target.value)} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100"><option value="default">{t('SORT_DEFAULT')}</option><option value="price-asc">{t('SORT_PRICE_ASC')}</option><option value="price-desc">{t('SORT_PRICE_DESC')}</option></select>
          <button onClick={reset} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">{t('RESET_FILTERS')}</button>
        </div>
      </Panel>
      {filtered.length===0? (<div className="rounded-2xl border border-cyan-300/25 bg-black/30 p-6 text-center text-cyan-100/80">{t('NO_RESULTS')}</div>) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">{filtered.map(item => (<Card key={item.id} t={t} item={item} onTry={onTry} onBuy={onBuy}/>))}</div>
      )}
    </Frame>
  );
}

// =====================================================================================
// Public Bots Page
// =====================================================================================
function PublicBotsPage(){
  const [lang,setLang]=useState('ar'); const t=useI18n(lang); useRTL(lang);
  const [q,setQ]=useState(''); const [langFilter,setLangFilter]=useState('all'); const [minP,setMinP]=useState(''); const [maxP,setMaxP]=useState(''); const [tags,setTags]=useState(''); const [sort,setSort]=useState('default');
  const nav = useNavigate();
  function match(item){ const text=(item.name+" "+item.description).toLowerCase(); if(q && !text.includes(q.toLowerCase())) return false; if(langFilter!=='all'&&item.language!==langFilter) return false; const p=item.priceTokens||0; if(minP!==''&&p<Number(minP))return false; if(maxP!==''&&p>Number(maxP))return false; const tagList=tags.split(',').map(s=>s.trim().toLowerCase()).filter(Boolean); if(tagList.length){ const its=(item.tags||[]).map(s=>s.toLowerCase()); if(!tagList.every(tg=>its.includes(tg))) return false;} return true; }
  const filtered = useMemo(()=>{ let list = MOCK.bots.filter(match); if(sort==='price-asc') list=[...list].sort((a,b)=>a.priceTokens-b.priceTokens); else if(sort==='price-desc') list=[...list].sort((a,b)=>b.priceTokens-a.priceTokens); else list=[...list].sort((a,b)=> (b.createdAt||0)-(a.createdAt||0)); return list; }, [q,langFilter,minP,maxP,tags,sort,lang]);
  const onTry = (item)=> nav(`/market/preview/${item.id}`); const onBuy=(item)=> nav(`/checkout/${item.id}`);
  const reset=()=>{ setQ(''); setLangFilter('all'); setMinP(''); setMaxP(''); setTags(''); setSort('default'); };
  return (
    <Frame title={t('PAGE_TITLE_PUBLIC')} back toLang={[lang,setLang]} subtitle={t('PAGE_SUB_PUBLIC')}>
      <Panel>
        <div className="mb-3 flex items-center justify-between"><strong className="text-cyan-100">{t('FILTERS')}</strong><div className="flex gap-2"><Chip>Public</Chip><Chip>Neon</Chip><Chip>{filtered.length} items</Chip></div></div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-6">
          <input value={q} onChange={e=>setQ(e.target.value)} placeholder={t('SEARCH_PLACEHOLDER')} className="col-span-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 sm:col-span-2 lg:col-span-6"/>
          <select value={langFilter} onChange={e=>setLangFilter(e.target.value)} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100"><option value="all">{t('ALL')}</option><option value="ar">العربية</option><option value="en">English</option><option value="fr">Français</option><option value="el">Ελληνικά</option></select>
          <input type="number" value={minP} onChange={e=>setMinP(e.target.value)} placeholder={t('MIN')} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100"/>
          <input type="number" value={maxP} onChange={e=>setMaxP(e.target.value)} placeholder={t('MAX')} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100"/>
          <input value={tags} onChange={e=>setTags(e.target.value)} placeholder={t('TAGS')} className="col-span-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 sm:col-span-2 lg:col-span-3"/>
          <select value={sort} onChange={e=>setSort(e.target.value)} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100"><option value="default">{t('SORT_DEFAULT')}</option><option value="price-asc">{t('SORT_PRICE_ASC')}</option><option value="price-desc">{t('SORT_PRICE_DESC')}</option></select>
          <button onClick={reset} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">{t('RESET_FILTERS')}</button>
        </div>
      </Panel>
      {filtered.length===0? (<div className="rounded-2xl border border-cyan-300/25 bg-black/30 p-6 text-center text-cyan-100/80">{t('NO_RESULTS')}</div>) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">{filtered.map(item => (<Card key={item.id} t={t} item={item} onTry={onTry} onBuy={onBuy}/>))}</div>
      )}
    </Frame>
  );
}

// =====================================================================================
// Sounds Page
// =====================================================================================
function SoundsPage(){
  const [lang,setLang]=useState('ar'); const t=useI18n(lang); useRTL(lang);
  const [q,setQ]=useState(''); const [langFilter,setLangFilter]=useState('all'); const [gender,setGender]=useState('all'); const [minP,setMinP]=useState(''); const [maxP,setMaxP]=useState(''); const [tags,setTags]=useState(''); const [sort,setSort]=useState('default'); const [playingId,setPlayingId]=useState(null);
  const nav = useNavigate(); const audioRef = useRef(null);
  useEffect(()=>{ if(!audioRef.current){ audioRef.current = new Audio(); audioRef.current.addEventListener('ended', ()=> setPlayingId(null)); } return ()=>{ audioRef.current?.pause(); }; },[]);
  function match(item){ const text=(item.name+" "+item.description).toLowerCase(); if(q && !text.includes(q.toLowerCase())) return false; if(langFilter!=='all'&&item.language!==langFilter) return false; if(gender!=='all'&&item.gender!==gender) return false; const p=item.priceTokens||0; if(minP!==''&&p<Number(minP))return false; if(maxP!==''&&p>Number(maxP))return false; const tagList=tags.split(',').map(s=>s.trim().toLowerCase()).filter(Boolean); if(tagList.length){ const its=(item.tags||[]).map(s=>s.toLowerCase()); if(!tagList.every(tg=>its.includes(tg))) return false;} return true; }
  const filtered = useMemo(()=>{ let list=MOCK.sounds.filter(match); if(sort==='price-asc') list=[...list].sort((a,b)=>a.priceTokens-b.priceTokens); else if(sort==='price-desc') list=[...list].sort((a,b)=>b.priceTokens-a.priceTokens); else if(sort==='dur-asc') list=[...list].sort((a,b)=> (a.durationSec||0)-(b.durationSec||0)); else if(sort==='dur-desc') list=[...list].sort((a,b)=> (b.durationSec||0)-(a.durationSec||0)); else list=[...list].sort((a,b)=> (b.createdAt||0)-(a.createdAt||0)); return list; }, [q,langFilter,gender,minP,maxP,tags,sort,lang]);
  const onPreview = (item)=>{ if(!audioRef.current) return; if(playingId===item.id){ audioRef.current.pause(); setPlayingId(null); return; } try{ audioRef.current.src=item.previewUrl||''; audioRef.current.currentTime=0; audioRef.current.play(); setPlayingId(item.id);}catch(e){ setPlayingId(null);} };
  const onBuy = (item)=> nav(`/checkout/${item.id}`);
  const reset=()=>{ setQ(''); setLangFilter('all'); setGender('all'); setMinP(''); setMaxP(''); setTags(''); setSort('default'); };
  return (
    <Frame title={t('PAGE_TITLE_SOUNDS')} back toLang={[lang,setLang]} subtitle={t('PAGE_SUB_SOUNDS')}>
      <Panel>
        <div className="mb-3 flex items-center justify-between"><strong className="text-cyan-100">{t('FILTERS')}</strong><div className="flex gap-2"><Chip>Sounds</Chip><Chip>Neon</Chip><Chip>{filtered.length} items</Chip></div></div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-7">
          <input value={q} onChange={e=>setQ(e.target.value)} placeholder={t('SEARCH_PLACEHOLDER')} className="col-span-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 sm:col-span-2 lg:col-span-7"/>
          <select value={langFilter} onChange={e=>setLangFilter(e.target.value)} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100"><option value="all">{t('ALL')}</option><option value="ar">العربية</option><option value="en">English</option><option value="fr">Français</option><option value="el">Ελληνικά</option></select>
          <select value={gender} onChange={e=>setGender(e.target.value)} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100"><option value="all">{t('GENDER_ALL')}</option><option value="male">{t('GENDER_MALE')}</option><option value="female">{t('GENDER_FEMALE')}</option><option value="child">{t('GENDER_CHILD')}</option></select>
          <input type="number" value={minP} onChange={e=>setMinP(e.target.value)} placeholder={t('MIN')} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100"/>
          <input type="number" value={maxP} onChange={e=>setMaxP(e.target.value)} placeholder={t('MAX')} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100"/>
          <input value={tags} onChange={e=>setTags(e.target.value)} placeholder={t('TAGS')} className="col-span-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 sm:col-span-2 lg:col-span-3"/>
          <select value={sort} onChange={e=>setSort(e.target.value)} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100"><option value="default">{t('SORT_DEFAULT')}</option><option value="price-asc">{t('SORT_PRICE_ASC')}</option><option value="price-desc">{t('SORT_PRICE_DESC')}</option><option value="dur-asc">{t('SORT_DURATION_ASC')}</option><option value="dur-desc">{t('SORT_DURATION_DESC')}</option></select>
          <button onClick={reset} className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">{t('RESET_FILTERS')}</button>
        </div>
      </Panel>
      {filtered.length===0? (<div className="rounded-2xl border border-cyan-300/25 bg-black/30 p-6 text-center text-cyan-100/80">{t('NO_RESULTS')}</div>) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">{filtered.map(item => (
          <motion.div key={item.id} layout initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} className="group relative flex flex-col overflow-hidden rounded-2xl border border-cyan-300/25 bg-gradient-to-b from-cyan-400/10 to-cyan-400/5 shadow-[0_0_24px_rgba(0,229,255,0.12)]">
            <div className="aspect-video w-full overflow-hidden bg-black/60"><img src={item.image} alt={item.name} className="h-full w-full object-cover opacity-90"/></div>
            <div className="p-4">
              <div className="font-semibold tracking-wide text-cyan-100">{item.name}</div>
              <div className="mt-1 line-clamp-2 text-sm text-cyan-100/80">{item.description}</div>
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-3"><div className="font-mono text-cyan-200">{item.priceTokens} {t('TOKENS')}</div><Chip>{t('DURATION')}: {formatDuration(item.durationSec)}</Chip></div>
                <div className="flex gap-2">
                  <button onClick={()=>onPreview(item)} className={`rounded-md border border-cyan-300/40 px-3 py-1.5 text-sm text-cyan-50 hover:bg-cyan-500/10 ${playingId===item.id? 'animate-pulse':''}`}>{playingId===item.id? t('STOP'):t('PREVIEW')}</button>
                  <button onClick={()=>onBuy(item)} className="rounded-md border border-cyan-300/40 px-3 py-1.5 text-sm text-cyan-50 hover:bg-cyan-500/10">{t('BUY')}</button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}</div>
      )}
    </Frame>
  );
}

function formatDuration(sec){ const s=Math.max(0,Math.floor(sec||0)); const m=Math.floor(s/60); const r=s%60; return `${m}:${String(r).padStart(2,'0')}`; }

// =====================================================================================
// Preview Page (/market/preview/:id)
// =====================================================================================
const LIMIT_MSGS = 5; const LIMIT_TOKENS = 500;
function PreviewPage(){
  const [lang,setLang]=useState('ar'); const t=useI18n(lang); useRTL(lang);
  const { id } = useParams();
  const catalog = [...MOCK.nfts, ...MOCK.bots];
  const bot = useMemo(()=> catalog.find(b=>b.id===id) || null, [id]);
  const [messages,setMessages]=useState(()=> bot? [{role:'assistant', content:`Hi, I'm ${bot.name}. This is a demo chat.`}] : []);
  const [input,setInput]=useState(''); const [tokensUsed,setTokensUsed]=useState(messages.reduce((s,m)=> s+estimateTokens(m.content),0)); const [userMsgs,setUserMsgs]=useState(0); const [isStreaming,setIsStreaming]=useState(false);
  const chatRef = useRef(null); useEffect(()=>{ chatRef.current && (chatRef.current.scrollTop = chatRef.current.scrollHeight); },[messages,isStreaming]);
  const limitReached = userMsgs>=LIMIT_MSGS || tokensUsed>=LIMIT_TOKENS;
  const nav = useNavigate();
  if(!bot){ return (
    <div className="min-h-screen w-full bg-[#05060a] text-cyan-50"><div className="mx-auto max-w-5xl px-5 py-10"><Link to="/market" className="inline-block rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">← {t('BACK')}</Link><div className="mt-6 rounded-2xl border border-cyan-300/30 bg-black/30 p-6 text-center text-cyan-100/85">{t('NOT_FOUND')}</div></div></div>
  ); }

  const msgsLeft = Math.max(0, LIMIT_MSGS - userMsgs); const tokensLeft = Math.max(0, LIMIT_TOKENS - tokensUsed);
  function send(){ const text=input.trim(); if(!text||limitReached||isStreaming) return; const newMsgs=[...messages,{role:'user',content:text}]; setMessages(newMsgs); setInput(''); setUserMsgs(n=>n+1); setTokensUsed(x=> x+estimateTokens(text)); setIsStreaming(true); const reply=`Demo reply from ${bot.name}: "${text.slice(0,120)}"`; const rt=estimateTokens(reply); setTimeout(()=>{ setMessages(m=>[...m,{role:'assistant',content:reply}]); setTokensUsed(x=> x+rt); setIsStreaming(false); },600); }
  function reset(){ const greeting=`Hi, I'm ${bot.name}. This is a demo chat.`; setMessages([{role:'assistant', content:greeting}]); setUserMsgs(0); setTokensUsed(estimateTokens(greeting)); setInput(''); }

  return (
    <Frame title={t('PAGE_TITLE_PREVIEW')} back toLang={[lang,setLang]}>
      {/* Bot header */}
      <div className="mb-5 grid grid-cols-1 gap-4 md:grid-cols-[240px,1fr]">
        <div className="overflow-hidden rounded-2xl border border-cyan-300/30 bg-black/50 shadow-[0_0_24px_rgba(0,229,255,0.12)]"><img src={bot.image} alt={bot.name} className="h-full w-full object-cover"/></div>
        <div className="flex flex-col justify-center">
          <h2 className="text-2xl font-extrabold tracking-wide text-cyan-100">{bot.name}</h2>
          <div className="mt-2 text-cyan-100/85"><span className="font-semibold">{t('DESC')}:</span> {bot.description}</div>
          <div className="mt-3 flex flex-wrap items-center gap-2"><Chip>{bot.type==='bots-nft'? 'NFT':'Public'}</Chip><Chip>{bot.priceTokens} {t('TOKENS')}</Chip>{bot.tags?.slice(0,3).map(tg=> <Chip key={tg}>#{tg}</Chip>)}</div>
        </div>
      </div>

      {/* Trial meters */}
      <div className="mb-4 grid grid-cols-1 gap-3 md:grid-cols-2">
        <Meter title={t('FREE_TRIAL')} right={`${msgsLeft} ${t('MESSAGES')} · ${tokensLeft} ${t('TOKENS')} ${t('TRY_LEFT')}`} value={userMsgs/LIMIT_MSGS}/>
        <Meter title={t('TOKENS')} right={`${tokensUsed} / ${LIMIT_TOKENS}`} value={tokensUsed/LIMIT_TOKENS}/>
      </div>

      {/* Chat */}
      <div className="mb-3 h-[52vh] min-h-[360px] w-full overflow-y-auto rounded-2xl border border-cyan-300/30 bg-gradient-to-b from-cyan-400/10 to-cyan-400/5 p-4" ref={chatRef}>
        <div className="mx-auto flex max-w-3xl flex-col gap-2">
          {messages.map((m,i)=> <Bubble key={i} role={m.role}>{m.content}</Bubble>)}
          {isStreaming && <Bubble role="assistant">▌</Bubble>}
          {limitReached && <div className="mt-4 rounded-xl border border-cyan-300/30 bg-black/40 p-3 text-center text-cyan-100/85">{t('LIMIT_REACHED')}</div>}
        </div>
      </div>

      {/* Input bar */}
      <div className="flex flex-wrap items-center gap-2">
        <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{ if(e.key==='Enter') send(); }} placeholder={t('INPUT_PLACEHOLDER')} disabled={limitReached||isStreaming} className="flex-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 disabled:opacity-60"/>
        <button onClick={send} disabled={limitReached||isStreaming} className="rounded-xl border border-cyan-300/30 bg-black/40 px-4 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10 disabled:opacity-50">{t('SEND')}</button>
        <button onClick={reset} className="rounded-xl border border-cyan-300/30 bg-black/40 px-4 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">{t('RESET')}</button>
        <div className="grow"/>
        <button onClick={()=> nav(`/checkout/${bot.id}`)} className="rounded-xl border border-cyan-300/40 bg-cyan-500/10 px-4 py-2 text-sm font-semibold text-cyan-50 hover:bg-cyan-500/20">{t('BUY_NOW')}</button>
      </div>
    </Frame>
  );
}

function estimateTokens(text=''){ const words=String(text).trim().split(/\s+/).filter(Boolean).length; return Math.round(words*1.3); }
function Bubble({role, children}){ const isUser=role==='user'; return (<div className={`flex ${isUser? 'justify-end':'justify-start'}`}><div className={`max-w-[85%] rounded-2xl border px-3 py-2 text-sm leading-6 shadow-[0_0_18px_rgba(0,229,255,0.10)] ${isUser? 'border-cyan-300/40 bg-cyan-400/10 text-cyan-50':'border-cyan-300/25 bg-black/40 text-cyan-100'}`}>{children}</div></div>); }
function Meter({title,right,value=0}){ return (<div className="rounded-xl border border-cyan-300/30 bg-black/40 p-3"><div className="mb-1 flex items-center justify-between text-xs text-cyan-100/80"><span>{title}</span><span>{right}</span></div><div className="h-2 w-full overflow-hidden rounded-full bg-cyan-300/10"><div className="h-full bg-cyan-300/60" style={{width:`${Math.min(100,Math.max(0,value*100))}%`}}/></div></div>); }

// =====================================================================================
// Checkout Page (/checkout/:id)
// =====================================================================================
function CheckoutPage(){
  const [lang,setLang]=useState('ar'); const t=useI18n(lang); useRTL(lang);
  const { id } = useParams();
  const item = useMemo(()=> [...MOCK.nfts, ...MOCK.bots, ...MOCK.sounds].find(x=>x.id===id) || null, [id]);
  const [balance,setBalance]=useState(2000); const [accept,setAccept]=useState(false); const [delivery,setDelivery]=useState('host'); const [processing,setProcessing]=useState(false); const [success,setSuccess]=useState(false); const [orderId,setOrderId]=useState('');
  if(!item){ return (<div className="min-h-screen w-full bg-[#05060a] text-cyan-50"><div className="mx-auto max-w-5xl px-5 py-10"><Link to="/market" className="inline-block rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">← {t('BACK')}</Link><div className="mt-6 rounded-2xl border border-cyan-300/30 bg-black/30 p-6 text-center text-cyan-100/85">{t('NOT_FOUND')}</div></div></div>); }
  const total=item.priceTokens||0; const canPay= accept && !processing && balance>=total;
  function categoryLabel(type){ if(type==='bots-nft') return t('CATEGORY_NFT'); if(type==='bots') return t('CATEGORY_PUBLIC'); return t('CATEGORY_SOUND'); }
  function generateOrderId(){ const n=Date.now().toString(36).toUpperCase(); const r=Math.random().toString(36).slice(2,6).toUpperCase(); return `CHK-${n}-${r}`; }
  function pay(){ if(!canPay) return; setProcessing(true); const id=generateOrderId(); setOrderId(id); setTimeout(()=>{ setBalance(b=> b-total); setProcessing(false); setSuccess(true); }, 900); }
 
  return (
    <Frame title={t('TITLE_CHECKOUT')} back toLang={[lang,setLang]}>
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-[1.1fr,0.9fr]">
        <div className="space-y-5">
          <div className="overflow-hidden rounded-2xl border border-cyan-300/30 bg-black/40 shadow-[0_0_24px_rgba(0,229,255,0.12)]">
            <div className="aspect-video w-full overflow-hidden"><img src={item.image} alt={item.name} className="h-full w-full object-cover opacity-95"/></div>
            <div className="p-4">
              <div className="mb-1 text-sm text-cyan-100/70">{t('ITEM')}</div>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <div className="text-lg font-bold text-cyan-100">{item.name}</div>
                  <div className="mt-1 text-cyan-100/80">{item.description}</div>
                  <div className="mt-2 flex flex-wrap gap-2"><Chip>{t('TYPE')}: {categoryLabel(item.type)}</Chip><Chip>{t('ID')}: {item.id}</Chip></div>
                </div>
                <div className="text-right"><div className="text-sm text-cyan-100/70">{t('PRICE')}</div><div className="font-mono text-xl text-cyan-100">{item.priceTokens} {t('TOKENS')}</div></div>
              </div>
            </div>
          </div>

          {item.type!=="bots-nft" && (
            <Panel>
              <div className="mb-2 text-cyan-100">{t('DELIVERY')}</div>
              <div className="flex flex-col gap-2 sm:flex-row">
                <label className={`flex flex-1 cursor-pointer items-center gap-3 rounded-xl border px-3 py-2 ${delivery==='host'? 'border-cyan-300/70 bg-cyan-400/10':'border-cyan-300/30 bg-black/30'}`}>
                  <input type="radio" name="delivery" className="accent-cyan-400" checked={delivery==='host'} onChange={()=>setDelivery('host')}/>
                  <span className="text-cyan-100">{t('HOST_ON_PLATFORM')}</span>
                </label>
                <label className={`flex flex-1 cursor-pointer items-center gap-3 rounded-xl border px-3 py-2 ${delivery==='download'? 'border-cyan-300/70 bg-cyan-400/10':'border-cyan-300/30 bg-black/30'}`}>
                  <input type="radio" name="delivery" className="accent-cyan-400" checked={delivery==='download'} onChange={()=>setDelivery('download')}/>
                  <span className="text-cyan-100">{t('DOWNLOAD_FILES')}</span>
                </label>
              </div>
            </Panel>
          )}

          <label className="flex items-start gap-3 rounded-2xl border border-cyan-300/30 bg-black/30 p-4">
            <input type="checkbox" className="mt-1.5 accent-cyan-400" checked={accept} onChange={()=> setAccept(v=>!v) }/>
            <div><div className="text-cyan-100">{t('TERMS')}</div><div className="text-xs text-cyan-100/70">{!accept && t('TERMS')}</div></div>
          </label>
        </div>

        <div className="space-y-5">
          <Panel>
            <div className="mb-3 text-cyan-100">{t('SUMMARY')}</div>
            <Row k={t('ITEM')} v={item.name}/>
            <Row k={t('QTY')} v={t('ONE')}/>
            <Row k={t('TYPE')} v={categoryLabel(item.type)}/>
            <Row k={t('PRICE')} v={`${item.priceTokens} ${t('TOKENS')}`}/>
            <div className="mt-4 h-px w-full bg-cyan-300/20"/>
            <Row k={t('BALANCE')} v={`${balance} ${t('TOKENS')}`}/>
            <Row k={t('TOTAL')} v={`${total} ${t('TOKENS')}`}/>
            <Row k={t('BAL_AFTER')} v={`${Math.max(0,balance-total)} ${t('TOKENS')}`}/>
            <div className="mt-4 flex items-center gap-2">
              <button onClick={()=> alert('Top up flow')} className="rounded-xl border border-cyan-300/30 bg-black/30 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">Top up</button>
              <div className="grow"/>
              <button disabled={!canPay} onClick={pay} className={`rounded-xl px-4 py-2 text-sm font-semibold ${canPay? 'border border-cyan-300/40 bg-cyan-500/10 text-cyan-50 hover:bg-cyan-500/20':'border border-cyan-300/20 bg-black/30 text-cyan-100/60'}`}>{processing? t('PROCESSING') : balance<total? t('INSUFFICIENT'): t('PAY')}</button>
            </div>
          </Panel>

          {success && (
            <div className="rounded-2xl border border-cyan-300/40 bg-black/40 p-4 shadow-[0_0_24px_rgba(0,229,255,0.18)]">
              <div className="mb-1 text-lg font-bold text-cyan-100">✅ {t('SUCCESS')}</div>
              <div className="text-cyan-100/85">{item.type==='bots-nft' && t('SUCCESS_DESC_NFT')}{item.type==='bots' && t('SUCCESS_DESC_BOT')}{item.type==='sounds' && t('SUCCESS_DESC_SOUND')}</div>
              <div className="mt-3 grid grid-cols-1 gap-2 text-sm text-cyan-100/85 sm:grid-cols-2">
                <div><div className="text-cyan-100/70">{t('ORDER_ID')}</div><div className="font-mono">{orderId}</div></div>
                <div><div className="text-cyan-100/70">{t('BAL_AFTER')}}</div><div className="font-mono">{balance} {t('TOKENS')}</div></div>
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-2">
                {(item.type==='bots' || item.type==='bots-nft') && (<Link to="/dashboard/bots" className="rounded-xl border border-cyan-300/40 bg-cyan-500/10 px-3 py-2 text-sm font-medium text-cyan-50 hover:bg-cyan-500/20">Dashboard</Link>)}
                {item.type==='sounds' && (<Link to="/downloads" className="rounded-xl border border-cyan-300/40 bg-cyan-500/10 px-3 py-2 text-sm font-medium text-cyan-50 hover:bg-cyan-500/20">Downloads</Link>)}
                <Link to="/market" className="rounded-xl border border-cyan-300/40 bg-black/30 px-3 py-2 text-sm text-cyan-50 hover:bg-cyan-500/10">{t('BACK')}</Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </Frame>
  );
}

function Row({k,v}){ return (<div className="mt-2 flex items-center justify-between text-sm text-cyan-100/80"><span>{k}</span><span className="font-mono">{v}</span></div>); }

// =====================================================================================
// Frame wrapper + common header
// =====================================================================================
function Frame({title, subtitle, children, back, toLang}){
  const [lang,setLang] = toLang||[]; const t = useI18n(lang||'ar');
  return (
    <div className="min-h-screen w-full bg-[#05060a] bg-[radial-gradient(1200px_600px_at_10%_-10%,rgba(0,229,255,0.08),transparent_40%),radial-gradient(900px_500px_at_90%_0%,rgba(0,229,255,0.06),transparent_35%)] text-cyan-50">
      <div className="mx-auto max-w-6xl px-5 py-8">
        <header className="mb-6">
          <div className="mb-2 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              {back && (<Link to="/market" className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">← {t('BACK')}</Link>)}
              <motion.h1 initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} className="text-[clamp(24px,3.4vw,36px)] font-extrabold tracking-wide text-cyan-100 drop-shadow-[0_0_22px_rgba(0,229,255,0.18)]">{title}</motion.h1>
            </div>
            {toLang && (
              <select value={lang} onChange={e=>setLang(e.target.value)} className="min-w-[140px] rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 outline-none focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20">
                <option value="ar">العربية</option><option value="en">English</option><option value="fr">Français</option><option value="el">Ελληνικά</option>
              </select>
            )}
          </div>
          {subtitle && <p className="text-cyan-100/80">{subtitle}</p>}
        </header>
        {children}
      </div>
    </div>
  );
}

// =====================================================================================
// Root App with Routes
// =====================================================================================
export default function RbotlyApp(){
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/market" replace/>} />
        <Route path="/market" element={<HomePage/>} />
        <Route path="/market/bots-nft" element={<BotsNFTPage/>} />
        <Route path="/market/bots" element={<PublicBotsPage/>} />
        <Route path="/market/sounds" element={<SoundsPage/>} />
        <Route path="/market/preview/:id" element={<PreviewPage/>} />
        <Route path="/checkout/:id" element={<CheckoutPage/>} />
        {/* Optional placeholders */}
        <Route path="/downloads" element={<Placeholder title="Downloads"/>} />
        <Route path="/dashboard/bots" element={<Placeholder title="Dashboard / My Bots"/>} />
        <Route path="*" element={<NotFound/>} />
      </Routes>
    </HashRouter>
  );
}

function Placeholder({title}){ return (<div className="min-h-screen w-full bg-[#05060a] text-cyan-50"><div className="mx-auto max-w-5xl px-5 py-10"><Link to="/market" className="inline-block rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">← Back</Link><div className="mt-6 rounded-2xl border border-cyan-300/30 bg-black/30 p-6 text-center text-cyan-100/85">{title}</div></div></div>); }
function NotFound(){ return (<div className="min-h-screen w-full bg-[#05060a] text-cyan-50"><div className="mx-auto max-w-5xl px-5 py-10"><Link to="/market" className="inline-block rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">← Back</Link><div className="mt-6 rounded-2xl border border-cyan-300/30 bg-black/30 p-6 text-center text-cyan-100/85">404 — Route not found</div></div></div>); }
