// UserActivityLogPage.js - صفحة سجل النشاط مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const user_activity_log_page_en = {
  activityLogTitle: "Activity Log",
  date: "Date",
  activity: "Activity",
  detail: "Detail",
  login: "Login",
  logout: "Logout",
  order: "Order placed",
  updateProfile: "Profile updated",
  download: "Downloaded a file",
  noActivity: "No activity recorded.",
};
export const user_activity_log_page_ar = {
  activityLogTitle: "سجل النشاط",
  date: "التاريخ",
  activity: "النشاط",
  detail: "التفاصيل",
  login: "تسجيل دخول",
  logout: "تسجيل خروج",
  order: "تم تنفيذ طلب",
  updateProfile: "تم تعديل الملف الشخصي",
  download: "تم تحميل ملف",
  noActivity: "لا يوجد نشاط مسجل.",
};
export const user_activity_log_page_fr = {
  activityLogTitle: "Journal d'activité",
  date: "Date",
  activity: "Activité",
  detail: "Détail",
  login: "Connexion",
  logout: "Déconnexion",
  order: "Commande passée",
  updateProfile: "Profil mis à jour",
  download: "Fichier téléchargé",
  noActivity: "Aucune activité enregistrée.",
};
export const user_activity_log_page_el = {
  activityLogTitle: "Καταγραφή δραστηριότητας",
  date: "Ημερομηνία",
  activity: "Δραστηριότητα",
  detail: "Λεπτομέρεια",
  login: "Σύνδεση",
  logout: "Αποσύνδεση",
  order: "Εκτελέστηκε παραγγελία",
  updateProfile: "Ενημερώθηκε το προφίλ",
  download: "Λήψη αρχείου",
  noActivity: "Δεν καταγράφηκε δραστηριότητα.",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: user_activity_log_page_en,
  ar: user_activity_log_page_ar,
  fr: user_activity_log_page_fr,
  el: user_activity_log_page_el,
};

const mockLogs = [
  { id: 1, date: "2025-08-08", activity: "login", detail: "Web App" },
  { id: 2, date: "2025-08-08", activity: "order", detail: "Purchased GenFlow Tool" },
  { id: 3, date: "2025-08-07", activity: "download", detail: "EduBotX.zip" },
  { id: 4, date: "2025-08-06", activity: "updateProfile", detail: "Changed email address" },
  { id: 5, date: "2025-08-05", activity: "logout", detail: "Web App" },
];

export default function UserActivityLogPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [logs] = useState(mockLogs);

  return (
    <main className="min-h-screen bg-black text-white p-6 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("activityLogTitle")}</h1>
      {logs.length === 0 ? (
        <div className="text-lg text-center text-gray-400 py-16">{t("noActivity")}</div>
      ) : (
        <table className="w-full table-auto text-left border">
          <thead>
            <tr className="bg-zinc-900">
              <th className="p-2 border">#</th>
              <th className="p-2 border">{t("date")}</th>
              <th className="p-2 border">{t("activity")}</th>
              <th className="p-2 border">{t("detail")}</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((log, i) => (
              <tr key={log.id} className="border-t">
                <td className="p-2 border">{i + 1}</td>
                <td className="p-2 border">{log.date}</td>
                <td className="p-2 border">{t(log.activity)}</td>
                <td className="p-2 border">{log.detail}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </main>
  );
}
