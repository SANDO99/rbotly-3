import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { useAuth } from './AuthContext';
import { NFTMintService } from '../services/NFTMintService';

/*
 * Unified UserInventoryContext
 *
 * This context manages user balances, owned bots and sounds, and order history.
 * It automatically triggers an NFT mint job when the user purchases an NFT bot.
 * State is persisted to localStorage keyed by userId.  Admin functions such as
 * viewing all orders or issuing refunds are included.  Use this as the single
 * source of truth for user inventories across the app.
 */

const Ctx = createContext(null);

function makeDefaultRecord() {
  return { balance: 5000, bots: [], sounds: [] };
}

function orderId() {
  return `ORD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
}

export function UserInventoryProvider({ children }) {
  const { role, user } = useAuth();
  // Use username as a persistent identifier; fallback to guest
  const uid = user?.username || 'guest';

  // Persist user inventories and orders in localStorage
  const [usersStore, setUsersStore] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('rb_inv') || '{}');
    } catch {
      return {};
    }
  });
  const [orders, setOrders] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('rb_orders') || '[]');
    } catch {
      return [];
    }
  });

  // Persist to localStorage whenever stores change
  useEffect(() => {
    try {
      localStorage.setItem('rb_inv', JSON.stringify(usersStore));
    } catch {}
  }, [usersStore]);
  useEffect(() => {
    try {
      localStorage.setItem('rb_orders', JSON.stringify(orders));
    } catch {}
  }, [orders]);

  // Ensure a record exists for the current user
  useEffect(() => {
    setUsersStore((prev) => (prev[uid] ? prev : { ...prev, [uid]: makeDefaultRecord() }));
  }, [uid]);

  const rec = usersStore[uid] || makeDefaultRecord();

  /**
   * Add a purchased item to the user's inventory.
   * If the item is an NFT bot, automatically create a mint job.  Returns
   * { ok: true, orderId } on success or { ok: false, reason } on failure.
   */
  function addFromPurchase(item, opts = {}) {
    const total = Number(item?.priceTokens || 0);
    const delivery = opts.delivery || 'host';
    const have = rec.balance;
    if (have < total) return { ok: false, reason: 'insufficient' };

    const oid = orderId();
    const now = Date.now();

    // Update user inventory
    setUsersStore((prev) => {
      const cur = prev[uid] || makeDefaultRecord();
      let bots = cur.bots;
      let sounds = cur.sounds;
      const base = {
        id: item.id,
        name: item.name,
        image: item.image,
        language: item.language,
        priceTokens: item.priceTokens,
        tags: item.tags || [],
        purchasedAt: now,
      };
      if (item.type === 'bots' || item.type === 'bots-nft') {
        bots = [...bots, { ...base, type: item.type, status: 'stopped' }];
      } else if (item.type === 'sounds') {
        sounds = [...sounds, { ...base, durationSec: item.durationSec || 30, downloadUrl: item.downloadUrl || '#' }];
      }
      return { ...prev, [uid]: { ...cur, balance: cur.balance - total, bots, sounds } };
    });

    // Create order record
    const baseOrder = {
      id: oid,
      userId: uid,
      name: item.name,
      itemId: item.id,
      type: item.type,
      amount: total,
      delivery,
      createdAt: now,
      status: 'paid',
    };
    const orderWithMint =
      item.type === 'bots-nft'
        ? { ...baseOrder, nftMint: { status: 'queued' } }
        : baseOrder;
    setOrders((prev) => [...prev, orderWithMint]);

    // Automatically start NFT mint job for NFT bots
    if (item.type === 'bots-nft') {
      NFTMintService.startMint({
        orderId: oid,
        item,
        userId: uid,
        onUpdate: (partial) => {
          setOrders((prevOrders) =>
            prevOrders.map((o) =>
              o.id === oid ? { ...o, nftMint: { ...(o.nftMint || {}), ...partial } } : o
            )
          );
        },
      }).catch((err) => {
        setOrders((prevOrders) =>
          prevOrders.map((o) =>
            o.id === oid
              ? { ...o, nftMint: { status: 'failed', error: String(err?.message || err) } }
              : o
          )
        );
      });
    }

    return { ok: true, orderId: oid };
  }

  // Bot and sound operations
  function startBot(id) {
    setUsersStore((prev) => {
      const cur = prev[uid] || makeDefaultRecord();
      return {
        ...prev,
        [uid]: {
          ...cur,
          bots: cur.bots.map((b) => (b.id === id ? { ...b, status: 'running' } : b)),
        },
      };
    });
  }
  function stopBot(id) {
    setUsersStore((prev) => {
      const cur = prev[uid] || makeDefaultRecord();
      return {
        ...prev,
        [uid]: {
          ...cur,
          bots: cur.bots.map((b) => (b.id === id ? { ...b, status: 'stopped' } : b)),
        },
      };
    });
  }
  function removeOwnedBot(id) {
    setUsersStore((prev) => {
      const cur = prev[uid] || makeDefaultRecord();
      return {
        ...prev,
        [uid]: { ...cur, bots: cur.bots.filter((b) => b.id !== id) },
      };
    });
  }
  function removeOwnedSound(id) {
    setUsersStore((prev) => {
      const cur = prev[uid] || makeDefaultRecord();
      return {
        ...prev,
        [uid]: { ...cur, sounds: cur.sounds.filter((s) => s.id !== id) },
      };
    });
  }
  function topUp(amount) {
    const inc = Math.max(0, Number(amount || 0));
    setUsersStore((prev) => {
      const cur = prev[uid] || makeDefaultRecord();
      return { ...prev, [uid]: { ...cur, balance: cur.balance + inc } };
    });
  }

  /**
   * Refund an order and remove associated inventory items.  Admin only.
   */
  function refundOrder(oid) {
    setOrders((prevOrders) => {
      const o = prevOrders.find((x) => x.id === oid);
      if (!o || o.status !== 'paid') return prevOrders;
      setUsersStore((prev) => {
        const cur = prev[o.userId] || makeDefaultRecord();
        let bots = cur.bots;
        let sounds = cur.sounds;
        if (o.type === 'bots' || o.type === 'bots-nft') bots = bots.filter((b) => b.id !== o.itemId);
        if (o.type === 'sounds') sounds = sounds.filter((s) => s.id !== o.itemId);
        return {
          ...prev,
          [o.userId]: {
            ...cur,
            balance: cur.balance + o.amount,
            bots,
            sounds,
          },
        };
      });
      return prevOrders.map((x) =>
        x.id === oid ? { ...x, status: 'refunded', refundedAt: Date.now() } : x
      );
    });
  }

  const myOrders = useMemo(() => orders.filter((o) => o.userId === uid), [orders, uid]);
  const allOrders = orders; // for admin use

  const value = useMemo(
    () => ({
      balance: rec.balance,
      bots: rec.bots,
      sounds: rec.sounds,
      orders: myOrders,
      addFromPurchase,
      startBot,
      stopBot,
      removeOwnedBot,
      removeOwnedSound,
      topUp,
      allOrders,
      refundOrder,
    }),
    [rec.balance, rec.bots, rec.sounds, myOrders, allOrders]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useUserInventory() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useUserInventory must be used inside UserInventoryProvider');
  return v;
}