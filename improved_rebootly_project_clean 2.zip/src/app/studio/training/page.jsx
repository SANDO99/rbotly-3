import React, { useEffect, useMemo, useRef, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { useUserInventory } from "../context/UserInventoryContext";
import { useBotStudio } from "../context/BotStudioContext";

// Monthly subscription gating — price comes from env (editable later)
const MONTHLY_PRICE = (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.VITE_STUDIO_MONTHLY_PRICE) || null;

export default function BotTrainingStudio(){
  const { t } = useTranslation();
  const { id } = useParams(); // bot id
  const inv = useUserInventory();
  const studio = useBotStudio();

  const bot = useMemo(()=> inv.bots.find(b => String(b.id) === String(id)) || null, [inv.bots, id]);

  useEffect(()=>{ studio.ensure(id); }, [id]);

  if(!bot){
    return (
      <div className="min-h-screen w-full bg-[#05060a] text-cyan-50">
        <div className="mx-auto max-w-4xl p-6">
          <div className="rounded-2xl border border-cyan-300/30 bg-black/40 p-6 text-cyan-100/90">
            {t('BOT_NOT_FOUND', { defaultValue: 'Bot not found' })}
          </div>
          <div className="mt-4">
            <Link to="/dashboard/bots" className="rounded-lg border border-cyan-300/30 px-3 py-1.5 hover:bg-cyan-500/10">{t('BACK_TO_MY_BOTS', { defaultValue:'Back to My Bots' })}</Link>
          </div>
        </div>
      </div>
    );
  }

  const active = studio.isActive(id);
  const state = studio.get(id);
  const conf = state.config;
  const datasets = state.datasets;
  const jobs = state.jobs;

  return (
    <div className="min-h-screen w-full bg-[#05060a] text-cyan-50">
      <header className="sticky top-0 z-30 border-b border-cyan-300/20 bg-[#070a10]/80 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3">
          <img src={bot.image} alt="bot" className="h-12 w-12 rounded-2xl object-cover ring-1 ring-cyan-300/30" />
          <div className="mr-auto">
            <div className="text-lg font-extrabold text-cyan-100">{bot.name}</div>
            <div className="text-xs text-cyan-300/70">{bot.type}</div>
          </div>
          {active ? (
            <div className="flex items-center gap-2">
              <span className="rounded-full border border-emerald-400/40 bg-emerald-400/10 px-2 py-0.5 text-xs text-emerald-200">{t('PLAN_ACTIVE',{defaultValue:'Plan active'})}</span>
              <button onClick={()=> studio.expire(id)} className="rounded-lg border border-cyan-300/30 px-3 py-1.5 text-xs hover:bg-cyan-500/10">{t('STOP_TEMP',{defaultValue:'Stop (dev)'} )}</button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <span className="rounded-full border border-rose-400/40 bg-rose-400/10 px-2 py-0.5 text-xs text-rose-200">{t('PLAN_INACTIVE',{defaultValue:'Plan inactive'})}</span>
            </div>
          )}
          <Link to="/dashboard/bots" className="rounded-lg border border-cyan-300/30 px-3 py-1.5 text-xs hover:bg-cyan-500/10">{t('BACK_TO_MY_BOTS',{defaultValue:'Back'})}</Link>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6">
        {!active && (
          <div className="mb-6 rounded-2xl border border-cyan-300/30 bg-black/40 p-5">
            <div className="mb-2 text-sm text-cyan-200">{t('MONTHLY_PLAN_REQUIRED',{defaultValue:'Monthly plan is required to use the studio.'})}</div>
            <div className="flex flex-wrap items-end gap-3">
              <div className="text-2xl font-extrabold text-cyan-100">{MONTHLY_PRICE ? MONTHLY_PRICE : t('PRICE_TBD',{defaultValue:'—'})}</div>
              <button onClick={()=> studio.activateMonthly(id)} className="rounded-xl border border-cyan-300/40 bg-cyan-500/10 px-4 py-2 text-sm font-semibold hover:bg-cyan-500/20">
                {t('ACTIVATE_PLAN',{defaultValue:'Activate plan'})}
              </button>
            </div>
          </div>
        )}

        <Tabs active={active} botId={id} conf={conf} datasets={datasets} jobs={jobs} bot={bot} studio={studio} />
      </main>
    </div>
  );
}

function Tabs({ active, botId, conf, datasets, jobs, bot, studio }){
  const { t } = useTranslation();
  const [tab, setTab] = useState("overview");

  const TabBtn = ({ id, children }) => (
    <button onClick={()=> setTab(id)} className={`rounded-lg border border-cyan-300/20 px-3 py-1.5 text-xs hover:bg-cyan-500/10 ${tab===id? 'bg-cyan-500/10' : ''}`}>{children}</button>
  );

  return (
    <div>
      <div className="mb-4 flex flex-wrap gap-2">
        <TabBtn id="overview">{t('OVERVIEW',{defaultValue:'Overview'})}</TabBtn>
        <TabBtn id="data">{t('DATA',{defaultValue:'Data'})}</TabBtn>
        <TabBtn id="instructions">{t('INSTRUCTIONS',{defaultValue:'Instructions'})}</TabBtn>
        <TabBtn id="examples">{t('EXAMPLES',{defaultValue:'Examples'})}</TabBtn>
        <TabBtn id="testchat">{t('TEST_CHAT',{defaultValue:'Test Chat'})}</TabBtn>
        <TabBtn id="deploy">{t('DEPLOY',{defaultValue:'Deploy'})}</TabBtn>
        <TabBtn id="logs">{t('LOGS',{defaultValue:'Logs'})}</TabBtn>
      </div>

      {tab === 'overview' && <Overview active={active} botId={botId} bot={bot} studio={studio} conf={conf} datasets={datasets} />}
      {tab === 'data' && <DataTab active={active} botId={botId} datasets={datasets} />}
      {tab === 'instructions' && <InstructionsTab active={active} botId={botId} conf={conf} />}
      {tab === 'examples' && <ExamplesTab active={active} botId={botId} />}
      {tab === 'testchat' && <TestChatTab active={active} />}
      {tab === 'deploy' && <DeployTab active={active} />}
      {tab === 'logs' && <LogsTab active={active} jobs={jobs} />}
    </div>
  );
}

function Overview({ active, botId, bot, studio, conf, datasets }){
  const { t } = useTranslation();

  function exportConfig(){
    const payload = {
      bot: { id: botId, name: bot.name, type: bot.type, image: bot.image },
      config: studio.get(botId).config,
      datasets: (studio.get(botId).datasets || []).map(d => ({ id: d.id, filename: d.filename, size: d.size, lang: d.lang })),
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${bot.name.replace(/\s+/g,'_')}_studio_export.json`;
    a.click();
    setTimeout(()=> URL.revokeObjectURL(url), 5000);
  }

  return (
    <div className="rounded-2xl border border-cyan-300/30 bg-black/40 p-5 text-cyan-100/90">
      <div className="mb-1 text-sm text-cyan-200">{t('OVERVIEW_HINT',{defaultValue:'Configure your bot settings, add data, and test before starting.'})}</div>
      <div className="text-xs text-cyan-300/70">{active ? t('PLAN_ACTIVE_HINT',{defaultValue:'Your monthly plan is active.'}) : t('PLAN_INACTIVE_HINT',{defaultValue:'Activate the monthly plan to unlock all features.'})}</div>

      <div className="mt-4 flex flex-wrap gap-2">
        <button onClick={exportConfig} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10">{t('EXPORT_CONFIG',{defaultValue:'Download config (JSON)'})}</button>
      </div>
    </div>
  );
}

function DataTab({ active, botId, datasets }){
  const { t } = useTranslation();
  const studio = useBotStudio();
  const fileRef = useRef(null);
  const [recent, setRecent] = useState([]); // session-only downloads

  function exportDatasetsManifest(){
    const manifest = (studio.get(botId).datasets || []).map(d => ({ id:d.id, filename:d.filename, size:d.size, lang:d.lang, status:d.status }));
    const blob = new Blob([JSON.stringify({ botId, manifest, exportedAt: new Date().toISOString() }, null, 2)], { type:'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `datasets_manifest_${botId}.json`; a.click();
    setTimeout(()=> URL.revokeObjectURL(url), 4000);
  }

  return (
    <div className={`rounded-2xl border border-cyan-300/30 bg-black/40 p-5 ${!active ? 'opacity-60' : ''}`}>
      <div className="mb-3 text-sm font-semibold text-cyan-100">{t('UPLOAD_FILES',{defaultValue:'Upload knowledge files'})}</div>
      <div className="flex flex-wrap items-center gap-3">
        <input ref={fileRef} type="file" multiple disabled={!active} className="text-xs text-cyan-200" onChange={(e)=>{
          const files = Array.from(e.target.files || []);
          files.forEach(f => {
            studio.addDataset(botId, f);
            // keep a session-only download link for the original file
            const url = URL.createObjectURL(f);
            setRecent(prev => [{ name: f.name, size: f.size, url, ts: Date.now() }, ...prev]);
          });
          if(fileRef.current) fileRef.current.value = '';
        }} />
        <button disabled={!active} onClick={()=> studio.startEmbedJob(botId)} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10 disabled:opacity-50">
          {t('BUILD_INDEX',{defaultValue:'Build index'})}
        </button>
        <button onClick={exportDatasetsManifest} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10">{t('EXPORT_MANIFEST',{defaultValue:'Download datasets manifest'})}</button>
      </div>

      <div className="mt-4 grid gap-2 sm:grid-cols-2">
        {datasets.map(d => (
          <div key={d.id} className="rounded-xl border border-cyan-300/20 bg-black/30 p-3 text-xs text-cyan-100">
            <div className="font-mono">{d.filename}</div>
            <div className="text-cyan-300/70">{Math.round(d.size/1024)} KB · {d.lang} · {d.status}</div>
          </div>
        ))}
        {datasets.length === 0 && (
          <div className="rounded-xl border border-cyan-300/20 bg-black/20 p-3 text-xs text-cyan-300/70">{t('NO_FILES',{defaultValue:'No files yet.'})}</div>
        )}
      </div>

      <div className="mt-6">
        <div className="mb-2 text-xs text-cyan-300/80">{t('RECENT_UPLOADS',{defaultValue:'Recent uploads (this session)'})}</div>
        <div className="grid gap-2 sm:grid-cols-2">
          {recent.map(r => (
            <div key={r.ts + r.name} className="flex items-center justify-between rounded-xl border border-cyan-300/20 bg-black/30 p-3 text-xs text-cyan-100">
              <div className="font-mono">{r.name} · {Math.round(r.size/1024)} KB</div>
              <a href={r.url} download={r.name} className="rounded-md border border-cyan-300/30 px-2 py-1 hover:bg-cyan-500/10">{t('DOWNLOAD',{defaultValue:'Download'})}</a>
            </div>
          ))}
          {recent.length===0 && (
            <div className="rounded-xl border border-cyan-300/20 bg-black/20 p-3 text-xs text-cyan-300/70">{t('NO_RECENT',{defaultValue:'No uploads in this session.'})}</div>
          )}
        </div>
      </div>
    </div>
  );
}

function InstructionsTab({ active, botId, conf }){
  const { t } = useTranslation();
  const studio = useBotStudio();
  const [prompt, setPrompt] = useState(conf.prompt);
  const [language, setLanguage] = useState(conf.language);
  const [rag, setRag] = useState(conf.tools.rag);
  const [web, setWeb] = useState(conf.tools.web);

  useEffect(()=>{ setPrompt(conf.prompt); setLanguage(conf.language); setRag(conf.tools.rag); setWeb(conf.tools.web); }, [conf]);

  return (
    <div className={`rounded-2xl border border-cyan-300/30 bg-black/40 p-5 ${!active ? 'opacity-60' : ''}`}>
      <div className="mb-2 text-sm font-semibold text-cyan-100">{t('INSTRUCTIONS',{defaultValue:'Instructions'})}</div>
      <textarea disabled={!active} value={prompt} onChange={(e)=> setPrompt(e.target.value)} rows={6} className="w-full rounded-xl border border-cyan-300/20 bg-black/30 p-3 text-sm text-cyan-100 outline-none focus:border-cyan-300/50" placeholder={t('PROMPT_PLACEHOLDER',{defaultValue:'Describe the bot persona and rules...'})} />

      <div className="mt-3 grid gap-3 md:grid-cols-3">
        <div>
          <label className="mb-1 block text-xs text-cyan-300/80">{t('DEFAULT_LANGUAGE',{defaultValue:'Default language'})}</label>
          <select disabled={!active} value={language} onChange={(e)=> setLanguage(e.target.value)} className="w-full rounded-xl border border-cyan-300/20 bg-black/30 px-2 py-2 text-sm text-cyan-100">
            <option value="ar">العربية</option>
            <option value="en">English</option>
            <option value="fr">Français</option>
            <option value="el">Ελληνικά</option>
          </select>
        </div>
        <div className="flex items-center gap-2">
          <input disabled={!active} id="rag" type="checkbox" checked={rag} onChange={(e)=> setRag(e.target.checked)} />
          <label htmlFor="rag" className="text-sm text-cyan-100">RAG</label>
        </div>
        <div className="flex items-center gap-2">
          <input disabled={!active} id="web" type="checkbox" checked={web} onChange={(e)=> setWeb(e.target.checked)} />
          <label htmlFor="web" className="text-sm text-cyan-100">Web</label>
        </div>
      </div>

      <div className="mt-4">
        <button disabled={!active} onClick={()=> studio.setConfig(botId, { prompt, language, tools:{ rag, web } })} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10 disabled:opacity-50">
          {t('SAVE',{defaultValue:'Save'})}
        </button>
      </div>
    </div>
  );
}

function ExamplesTab({ active, botId }){
  const { t } = useTranslation();
  const studio = useBotStudio();
  const [q, setQ] = useState("");
  const [a, setA] = useState("");
  const examples = studio.get(botId).config.examples || [];

  return (
    <div className={`rounded-2xl border border-cyan-300/30 bg-black/40 p-5 ${!active ? 'opacity-60' : ''}`}>
      <div className="mb-2 text-sm font-semibold text-cyan-100">{t('EXAMPLES',{defaultValue:'Examples'})}</div>
      <div className="grid gap-2 sm:grid-cols-2">
        <input disabled={!active} value={q} onChange={(e)=> setQ(e.target.value)} placeholder={t('QUESTION',{defaultValue:'Question'})} className="rounded-xl border border-cyan-300/20 bg-black/30 px-3 py-2 text-sm text-cyan-100" />
        <input disabled={!active} value={a} onChange={(e)=> setA(e.target.value)} placeholder={t('ANSWER',{defaultValue:'Answer'})} className="rounded-xl border border-cyan-300/20 bg-black/30 px-3 py-2 text-sm text-cyan-100" />
      </div>
      <div className="mt-2">
        <button disabled={!active || !q || !a} onClick={()=>{ studio.addExample(botId, { q, a }); setQ(""); setA(""); }} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10 disabled:opacity-50">{t('ADD',{defaultValue:'Add'})}</button>
      </div>

      <div className="mt-4 grid gap-2">
        {examples.map(ex => (
          <div key={ex.id} className="flex items-center justify-between rounded-xl border border-cyan-300/20 bg-black/30 p-3 text-sm text-cyan-100">
            <div>
              <div className="font-semibold">Q: <span className="font-normal">{ex.q}</span></div>
              <div className="font-semibold">A: <span className="font-normal">{ex.a}</span></div>
            </div>
            <button disabled={!active} onClick={()=> studio.removeExample(botId, ex.id)} className="rounded-md border border-cyan-300/30 px-2 py-1 text-xs hover:bg-cyan-500/10">{t('REMOVE',{defaultValue:'Remove'})}</button>
          </div>
        ))}
        {examples.length === 0 && (
          <div className="rounded-xl border border-cyan-300/20 bg-black/20 p-3 text-xs text-cyan-300/70">{t('NO_EXAMPLES',{defaultValue:'No examples yet.'})}</div>
        )}
      </div>
    </div>
  );
}

function TestChatTab({ active }){
  const { t } = useTranslation();
  const [msg, setMsg] = useState("");
  const [messages, setMessages] = useState([]); // {id, role:'user'|'bot', text, atts:[{name,url,size}], files:[{name,url,size}]}
  const [atts, setAtts] = useState([]); // pending attachments before send
  const fileRef = useRef(null);

  const [recStatus, setRecStatus] = useState("idle");
  const mediaRef = useRef({ rec: null, chunks: [] });

  function onAttach(e){
    const files = Array.from(e.target.files || []);
    const next = files.map(f => ({ name: f.name, size: f.size, url: URL.createObjectURL(f), _revoke: true }));
    setAtts((prev)=> [...prev, ...next]);
    if(fileRef.current) fileRef.current.value = '';
  }

  async function startRec(){
    if(!active) return;
    if(!navigator.mediaDevices || !window.MediaRecorder){
      alert(t('MIC_NOT_SUPPORTED',{defaultValue:'Microphone not supported in this browser.'}));
      return;
    }
    try{
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(stream);
      mediaRef.current.chunks = [];
      rec.ondataavailable = (e)=>{ if(e.data.size>0) mediaRef.current.chunks.push(e.data); };
      rec.onstop = async()=>{
        const blob = new Blob(mediaRef.current.chunks, { type: 'audio/webm' });
        const url = URL.createObjectURL(blob);
        // add as attachment
        setAtts(prev => [...prev, { name: `voice_${Date.now()}.webm`, size: blob.size, url, _revoke: true }]);
        stream.getTracks().forEach(tr => tr.stop());
        setRecStatus('idle');
      };
      rec.start();
      mediaRef.current.rec = rec;
      setRecStatus('recording');
    }catch(err){
      alert(String(err?.message || err));
      setRecStatus('idle');
    }
  }

  function stopRec(){
    const rec = mediaRef.current.rec; if(rec && rec.state !== 'inactive'){ rec.stop(); }
  }

  function send(){
    if(!msg && atts.length===0) return;
    const userMsg = { id: crypto.randomUUID(), role:'user', text: msg, atts: atts.map(a=> ({ name:a.name, url:a.url, size:a.size })) };
    setMessages(prev => [...prev, userMsg]);
    setMsg(""); setAtts([]);
    // BOT mock reply — includes a generated downloadable file summarizing the user message
    setTimeout(()=>{
      const content = `Bot reply preview\n\nUser said: ${userMsg.text || '(no text)'}\nAttachments: ${userMsg.atts.length}`;
      const fileBlob = new Blob([content], { type:'text/plain' });
      const fileUrl = URL.createObjectURL(fileBlob);
      const botMsg = { id: crypto.randomUUID(), role:'bot', text: t('BOT_MOCK_REPLY',{defaultValue:'Received your message. Here is a summary file.'}), atts: [], files: [{ name:`reply_${Date.now()}.txt`, url:fileUrl, size:fileBlob.size, _revoke:true }] };
      setMessages(prev => [...prev, botMsg]);
    }, 600);
  }

  function exportChat(){
    const payload = messages.map(m => ({ role:m.role, text:m.text, atts:(m.atts||[]).map(a=>({name:a.name,url:a.url,size:a.size})), files:(m.files||[]).map(f=>({name:f.name,url:f.url,size:f.size})) }));
    const blob = new Blob([JSON.stringify({ exportedAt:new Date().toISOString(), items: payload }, null, 2)], { type:'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `chat_export_${Date.now()}.json`; a.click(); setTimeout(()=> URL.revokeObjectURL(url), 4000);
  }

  useEffect(()=>{
    return ()=>{
      // revoke any temporary object URLs
      const revoke = (arr=[])=> arr.forEach(x=>{ if(x._revoke) try{ URL.revokeObjectURL(x.url); } catch{} });
      messages.forEach(m=>{ revoke(m.atts); revoke(m.files); });
      revoke(atts);
    };
  }, [messages, atts]);

  return (
    <div className={`rounded-2xl border border-cyan-300/30 bg-black/40 p-5 ${!active ? 'opacity-60' : ''}`}>
      <div className="mb-2 flex items-center justify-between">
        <div className="text-sm font-semibold text-cyan-100">{t('TEST_CHAT',{defaultValue:'Test Chat'})}</div>
        <button onClick={exportChat} className="rounded-md border border-cyan-300/30 px-2 py-1 text-[11px] hover:bg-cyan-500/10">{t('EXPORT_CHAT',{defaultValue:'Export chat (.json)'})}</button>
      </div>

      {/* Messages */}
      <div className="mb-3 max-h-80 overflow-auto rounded-xl border border-cyan-300/20 bg-black/20 p-3">
        {messages.length===0 && (
          <div className="text-xs text-cyan-300/70">{t('NO_MESSAGES',{defaultValue:'No messages yet. Send a message to start.'})}</div>
        )}
        {messages.map(m => (
          <div key={m.id} className={`mb-3 ${m.role==='user'?'text-right':''}`}>
            <div className={`inline-block max-w-[90%] rounded-2xl px-3 py-2 text-sm ${m.role==='user' ? 'bg-cyan-500/10 border border-cyan-300/30' : 'bg-black/40 border border-cyan-300/20'}`}>
              <div className="mb-1 text-[11px] uppercase tracking-wide text-cyan-300/70">{m.role==='user'? t('YOU',{defaultValue:'You'}) : t('BOT',{defaultValue:'Bot'})}</div>
              <div className="whitespace-pre-wrap text-cyan-100">{m.text}</div>
              {(m.atts && m.atts.length>0) && (
                <div className="mt-2 space-y-1">
                  {m.atts.map((a,i)=> (
                    <div key={i} className="flex items-center justify-between rounded-lg border border-cyan-300/20 bg-black/30 px-2 py-1 text-[11px]">
                      <span className="font-mono">{a.name} · {Math.round(a.size/1024)} KB</span>
                      <a href={a.url} download={a.name} className="rounded border border-cyan-300/30 px-2 py-0.5 hover:bg-cyan-500/10">{t('DOWNLOAD',{defaultValue:'Download'})}</a>
                    </div>
                  ))}
                </div>
              )}
              {(m.files && m.files.length>0) && (
                <div className="mt-2 space-y-1">
                  {m.files.map((f,i)=> (
                    <div key={i} className="flex items-center justify-between rounded-lg border border-cyan-300/20 bg-black/30 px-2 py-1 text-[11px]">
                      <span className="font-mono">{f.name} · {Math.round(f.size/1024)} KB</span>
                      <a href={f.url} download={f.name} className="rounded border border-cyan-300/30 px-2 py-0.5 hover:bg-cyan-500/10">{t('DOWNLOAD',{defaultValue:'Download'})}</a>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Composer */}
      <div className="flex flex-wrap items-center gap-2">
        <input disabled={!active} value={msg} onChange={(e)=> setMsg(e.target.value)} placeholder={t('TYPE_MESSAGE',{defaultValue:'Type a message...'})} className="grow rounded-xl border border-cyan-300/20 bg-black/30 px-3 py-2 text-sm text-cyan-100" />
        <input ref={fileRef} type="file" multiple onChange={onAttach} disabled={!active} className="hidden" />
        <button disabled={!active} onClick={()=> fileRef.current?.click()} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10 disabled:opacity-50">{t('ATTACH',{defaultValue:'Attach'})}</button>
        <button disabled={!active || !msg && atts.length===0} onClick={send} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10 disabled:opacity-50">{t('SEND',{defaultValue:'Send'})}</button>
        <button disabled={!active || recStatus==='recording'} onClick={startRec} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10 disabled:opacity-50">{t('MIC_START',{defaultValue:'Start mic'})}</button>
        <button disabled={!active || recStatus!=='recording'} onClick={stopRec} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10 disabled:opacity-50">{t('MIC_STOP',{defaultValue:'Stop'})}</button>
      </div>

      {/* Pending attachments preview */}
      {(atts.length>0) && (
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {atts.map((a, i)=> (
            <div key={i} className="flex items-center justify-between rounded-xl border border-cyan-300/20 bg-black/30 p-2 text-[11px] text-cyan-100">
              <span className="font-mono">{a.name} · {Math.round(a.size/1024)} KB</span>
              <button onClick={()=> setAtts(prev=> prev.filter((_,idx)=> idx!==i))} className="rounded border border-cyan-300/30 px-2 py-0.5 hover:bg-cyan-500/10">{t('REMOVE',{defaultValue:'Remove'})}</button>
            </div>
          ))}
        </div>
      )}

      {!active && (<div className="mt-2 text-xs text-rose-200">{t('PLAN_REQUIRED_TO_CHAT',{defaultValue:'Activate the plan to chat here.'})}</div>)}
      {recStatus==='recording' && (<div className="mt-2 text-xs text-amber-200">{t('LISTENING',{defaultValue:'Listening… tap Stop when finished.'})}</div>)}
    </div>
  );
}

function DeployTab({ active }){
  const { t } = useTranslation();
  return (
    <div className={`rounded-2xl border border-cyan-300/30 bg-black/40 p-5 ${!active ? 'opacity-60' : ''}`}>
      <div className="mb-2 text-sm font-semibold text-cyan-100">{t('DEPLOY',{defaultValue:'Deploy'})}</div>
      <div className="text-xs text-cyan-300/80">{active ? t('READY_TO_START',{defaultValue:'Ready to start the managed runtime.'}) : t('NEED_PLAN',{defaultValue:'Activate the monthly plan first.'})}</div>
      <div className="mt-3 flex gap-2">
        <button disabled={!active} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10 disabled:opacity-50">{t('START',{defaultValue:'Start'})}</button>
        <button disabled={!active} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-xs hover:bg-cyan-500/10 disabled:opacity-50">{t('STOP',{defaultValue:'Stop'})}</button>
      </div>
    </div>
  );
}

function LogsTab({ active, jobs }){
  const { t } = useTranslation();
  return (
    <div className="rounded-2xl border border-cyan-300/30 bg-black/40 p-5">
      <div className="mb-2 text-sm font-semibold text-cyan-100">{t('LOGS',{defaultValue:'Logs'})}</div>
      <div className="grid gap-2">
        {jobs.map(j => (
          <div key={j.id} className="rounded-xl border border-cyan-300/20 bg-black/30 p-3 text-xs text-cyan-100">
            <div className="font-mono">{j.type} · {j.status} · {j.progress}%</div>
            <div className="text-cyan-300/70">{new Date(j.createdAt).toLocaleString()}</div>
          </div>
        ))}
        {jobs.length===0 && <div className="rounded-xl border border-cyan-300/20 bg-black/20 p-3 text-xs text-cyan-300/70">{t('NO_LOGS',{defaultValue:'No logs yet.'})}</div>}
      </div>
    </div>
  );
}
