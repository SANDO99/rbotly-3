// src/services/NFTMintService.js

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function rndHex(len = 64) {
  return (
    '0x' +
    Array.from({ length: len }, () => Math.floor(Math.random() * 16).toString(16)).join('')
  );
}

function rndToken() {
  return Math.floor(100000 + Math.random() * 900000);
}

export const NFTMintService = {
  mode:
    (typeof importMeta !== 'undefined' && importMeta?.env?.VITE_MINT_MODE) ||
    (typeof import.meta !== 'undefined' && import.meta.env?.VITE_MINT_MODE) ||
    'mock',

  /**
   * startMint — Begins minting an NFT and reports status updates via onUpdate.
   * @param {Object} args
   * @param {string} args.orderId
   * @param {Object} args.item (id,name,...)
   * @param {string} args.userId
   * @param {(partial)=>void} args.onUpdate // receives { status, txId?, tokenId?, metadataUri?, error? }
   * @returns {Promise<{jobId: string}>}
   */
  async startMint({ orderId, item, userId, onUpdate }) {
    if (this.mode === 'api') {
      // Example integration (unimplemented in mock):
      // const res = await fetch('/api/nft/mint', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ orderId, itemId:item.id, userId }) });
      // const { jobId } = await res.json();
      // // Polling
      // let done = false;
      // while (!done) {
      //   await delay(1500);
      //   const s = await fetch(`/api/nft/mint/${jobId}`).then((r) => r.json());
      //   onUpdate(s);
      //   done = s.status === 'minted' || s.status === 'failed';
      // }
      // return { jobId };
      throw new Error('API mode not implemented yet. Switch to mock or implement endpoints.');
    }

    // MOCK: Simulate queued -> minting -> minted with fake values
    onUpdate?.({ status: 'queued' });
    await delay(600);
    onUpdate?.({ status: 'minting' });
    await delay(1200);
    onUpdate?.({
      status: 'minted',
      chain: 'testnet',
      txId: rndHex(64),
      tokenId: rndToken(),
      metadataUri: `ipfs://Qm${Math.random().toString(36).slice(2, 10)}-${item.id}`,
    });
    return { jobId: 'mock-' + orderId };
  },
};