// voice_details_page.jsx
export const voice_details_page_en = {
  voiceDetailsTitle: "Voice Details",
  creator: "Creator",
  buy: "Buy",
  price: "Price",
  features: "Features",
  downloads: "Downloads",
  category: "Category",
  uploadDate: "Upload date",
  description: "Description",
  reviews: "Reviews",
  leaveReview: "Leave a Review",
  yourReview: "Your review...",
  send: "Send",
  sent: "Review sent!",
};
export const voice_details_page_ar = {
  voiceDetailsTitle: "تفاصيل الصوت",
  creator: "المنشئ",
  buy: "شراء",
  price: "السعر",
  features: "المميزات",
  downloads: "التنزيلات",
  category: "الفئة",
  uploadDate: "تاريخ الرفع",
  description: "الوصف",
  reviews: "التقييمات",
  leaveReview: "اترك تقييمًا",
  yourReview: "تقييمك...",
  send: "إرسال",
  sent: "تم إرسال التقييم!",
};
export const voice_details_page_fr = {
  voiceDetailsTitle: "Détails de la voix",
  creator: "Créateur",
  buy: "Acheter",
  price: "Prix",
  features: "Fonctionnalités",
  downloads: "Téléchargements",
  category: "Catégorie",
  uploadDate: "Date d'ajout",
  description: "Description",
  reviews: "Avis",
  leaveReview: "Laisser un avis",
  yourReview: "Votre avis...",
  send: "Envoyer",
  sent: "Avis envoyé !",
};
export const voice_details_page_el = {
  voiceDetailsTitle: "Λεπτομέρειες φωνής",
  creator: "Δημιουργός",
  buy: "Αγορά",
  price: "Τιμή",
  features: "Χαρακτηριστικά",
  downloads: "Λήψεις",
  category: "Κατηγορία",
  uploadDate: "Ημερομηνία ανάρτησης",
  description: "Περιγραφή",
  reviews: "Αξιολογήσεις",
  leaveReview: "Αφήστε μια αξιολόγηση",
  yourReview: "Η αξιολόγησή σας...",
  send: "Αποστολή",
  sent: "Η αξιολόγηση εστάλη!",
};

import { useState } from "react";

const translations = {
  en: voice_details_page_en,
  ar: voice_details_page_ar,
  fr: voice_details_page_fr,
  el: voice_details_page_el,
};

const mockVoice = {
  id: 1,
  name: "Arabic Male Voice",
  img: "/img/voice1.png",
  creator: "voicecraft@example.com",
  price: 12,
  downloads: 210,
  category: "Arabic",
  uploadDate: "2025-06-10",
  description: "Natural-sounding Arabic male voice with modern dialect support. Perfect for educational apps and customer service bots.",
  features: [
    "Emotional tone variations",
    "Fast response time",
    "Multiple Arabic dialects"
  ],
};
const mockReviews = [
  { id: 1, user: "Omar K.", date: "2025-07-22", text: "Perfect for our customer service bot!" },
  { id: 2, user: "Layla M.", date: "2025-08-05", text: "Sounds very natural and clear." },
];

export default function VoiceDetailsPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [reviews, setReviews] = useState(mockReviews);
  const [review, setReview] = useState("");
  const [sent, setSent] = useState(false);

  const handleSend = (e) => {
    e.preventDefault();
    if (!review.trim()) return;
    setReviews([
      ...reviews,
      { id: Date.now(), user: "You", date: new Date().toISOString().slice(0, 10), text: review }
    ]);
    setReview("");
    setSent(true);
    setTimeout(() => setSent(false), 1500);
  };

  return (
    <main className="min-h-screen bg-black text-white p-6 max-w-2xl mx-auto">
      <div className="flex gap-8 flex-col md:flex-row md:items-center mb-8">
        <div className="flex-shrink-0 w-48 h-48 bg-zinc-900 rounded-2xl flex items-center justify-center overflow-hidden">
          <img src={mockVoice.img} alt={mockVoice.name} className="max-w-full max-h-full" />
        </div>
        <div className="flex-1 flex flex-col gap-2">
          <h1 className="text-3xl font-bold text-[var(--neon)] mb-2">{mockVoice.name}</h1>
          <div className="text-xs text-gray-400">{t("creator")}: {mockVoice.creator}</div>
          <div className="text-lg font-semibold text-green-400 mb-1">{t("price")}: ${mockVoice.price}</div>
          <div className="flex gap-4 text-sm text-gray-400 mb-2">
            <span>{t("downloads")}: {mockVoice.downloads}</span>
            <span>{t("category")}: {mockVoice.category}</span>
            <span>{t("uploadDate")}: {mockVoice.uploadDate}</span>
          </div>
          <button className="bg-green-700 hover:bg-green-800 text-white px-4 py-2 rounded-xl w-max mt-2">{t("buy")}</button>
        </div>
      </div>
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-[var(--neon)] mb-2">{t("features")}</h2>
        <ul className="list-disc pl-6">
          {mockVoice.features.map((f, i) => <li key={i}>{f}</li>)}
        </ul>
      </div>
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-[var(--neon)] mb-2">{t("description")}</h2>
        <div className="bg-zinc-900 rounded-xl p-4 text-gray-200">{mockVoice.description}</div>
      </div>
      <div className="mb-12">
        <h2 className="text-xl font-semibold text-[var(--neon)] mb-3">{t("reviews")}</h2>
        <ul className="flex flex-col gap-3 mb-4">
          {reviews.map(r => (
            <li key={r.id} className="bg-zinc-900 rounded-xl p-3">
              <div className="font-bold text-sm mb-1">{r.user} <span className="text-xs text-gray-400 ml-2">[{r.date}]</span></div>
              <div>{r.text}</div>
            </li>
          ))}
        </ul>
        <form onSubmit={handleSend} className="flex flex-col gap-2">
          <textarea
            value={review}
            onChange={e => setReview(e.target.value)}
            className="w-full min-h-[60px] p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none"
            placeholder={t("yourReview")}
          />
          <button
            type="submit"
            className="bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-xl w-max"
          >
            {t("send")}
          </button>
          {sent && <div className="text-green-400 font-semibold mt-1">{t("sent")}</div>}
        </form>
      </div>
    </main>
  );
}