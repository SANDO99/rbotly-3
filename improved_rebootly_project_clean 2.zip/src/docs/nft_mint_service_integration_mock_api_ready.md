# NFT Mint — Service + Integration (Mock + API‑ready)

> هذا يبني **من الصفر** كود سكّ الـNFT: خدمة Mint قابلة للاستبدال (Mock/Backend)، وربطها بصفحة الدفع عبر `UserInventoryContext`، مع عرض الحالة للمشرف فقط. **واجهة المستخدم العادي لا تتغيّر**.

---

## 1) `src/services/NFTMintService.js`

خدمة موحّدة للمِنْت: تعمل بوضع **Mock** الآن، وجاهزة لوصل API لاحقًا.

```js
// src/services/NFTMintService.js

function delay(ms){ return new Promise(r => setTimeout(r, ms)); }
function rndHex(len=64){ return '0x' + Array.from({length:len}, ()=> Math.floor(Math.random()*16).toString(16)).join(''); }
function rndToken(){ return Math.floor(100000 + Math.random()*900000); }

export const NFTMintService = {
  mode: (typeof importMeta !== 'undefined' && importMeta?.env?.VITE_MINT_MODE) || (typeof import.meta !== 'undefined' && import.meta.env?.VITE_MINT_MODE) || 'mock',

  /**
   * startMint — يبدأ سكّ NFT ويبلغ عن الحالة عبر onUpdate
   * @param {Object} args
   * @param {string} args.orderId
   * @param {Object} args.item  (id,name,...)
   * @param {string} args.userId
   * @param {(partial)=>void} args.onUpdate  // يتلقى { status, txId?, tokenId?, metadataUri?, error? }
   * @returns {Promise<{jobId:string}>}
   */
  async startMint({ orderId, item, userId, onUpdate }){
    if(this.mode === 'api'){
      // مثال تكامل API (استبدل المسارات لاحقًا):
      // const res = await fetch('/api/nft/mint', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ orderId, itemId:item.id, userId }) });
      // const { jobId } = await res.json();
      // // polling
      // let done=false; while(!done){ await delay(1500); const s = await fetch(`/api/nft/mint/${jobId}`).then(r=>r.json()); onUpdate(s); done = (s.status==='minted' || s.status==='failed'); }
      // return { jobId };
      throw new Error('API mode not implemented yet. Switch to mock or implement endpoints.');
    }

    // MOCK: تسلسل queued -> minting -> minted مع قيم مزيّفة
    onUpdate?.({ status:'queued' });
    await delay(600);
    onUpdate?.({ status:'minting' });
    await delay(1200);
    onUpdate?.({ status:'minted', chain:'testnet', txId:rndHex(64), tokenId:rndToken(), metadataUri:`ipfs://Qm${Math.random().toString(36).slice(2,10)}-${item.id}` });
    return { jobId: 'mock-'+orderId };
  }
};
```

---

## 2) `src/context/UserInventoryContext.mint.jsx`

نسخة السياق المحدثة: تربط الشراء بالمستخدم، وتبدأ الـMint تلقائيًا للبوتات من نوع **NFT**، وتخزن حالة الـMint داخل **الطلب (Orders)** — مرئي للمشرف فقط.

```jsx
// src/context/UserInventoryContext.mint.jsx
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { useAuth } from './AuthContext';
import { NFTMintService } from '../services/NFTMintService';

const Ctx = createContext(null);
function makeDefaultRecord(){ return { balance: 5000, bots: [], sounds: [] }; }
function orderId(){ return `ORD-${Date.now()}-${Math.floor(Math.random()*1000)}`; }

export function UserInventoryProvider({ children }){
  const { currentUser } = useAuth();
  const uid = currentUser?.id || 'guest';

  const [usersStore, setUsersStore] = useState(()=>{ try { return JSON.parse(localStorage.getItem('rb_inv')||'{}'); } catch { return {}; } });
  const [orders, setOrders] = useState(()=>{ try { return JSON.parse(localStorage.getItem('rb_orders')||'[]'); } catch { return []; } });

  useEffect(()=>{ try { localStorage.setItem('rb_inv', JSON.stringify(usersStore)); } catch{} }, [usersStore]);
  useEffect(()=>{ try { localStorage.setItem('rb_orders', JSON.stringify(orders)); } catch{} }, [orders]);

  // تأمين سجل للمستخدم الحالي
  useEffect(()=>{ setUsersStore(prev => prev[uid] ? prev : { ...prev, [uid]: makeDefaultRecord() }); }, [uid]);
  const rec = usersStore[uid] || makeDefaultRecord();

  function addFromPurchase(item, opts={}){
    const total = Number(item?.priceTokens || 0);
    const delivery = opts.delivery || 'host';
    const have = (usersStore[uid]?.balance ?? 0);
    if(have < total) return { ok:false, reason:'insufficient' };

    const oid = orderId();
    const now = Date.now();

    // تحديث مخزون المستخدم
    setUsersStore(prev => {
      const cur = prev[uid] || makeDefaultRecord();
      let bots = cur.bots; let sounds = cur.sounds;
      const base = { id:item.id, name:item.name, image:item.image, language:item.language, priceTokens:item.priceTokens, tags:item.tags||[], purchasedAt: now };
      if(item.type==='bots' || item.type==='bots-nft') bots = [...bots, { ...base, type:item.type, status:'stopped' }];
      else if(item.type==='sounds') sounds = [...sounds, { ...base, durationSec:item.durationSec||30, downloadUrl:item.downloadUrl||'#' }];
      return { ...prev, [uid]: { ...cur, balance: cur.balance - total, bots, sounds } };
    });

    // إضافة الطلب
    const baseOrder = { id:oid, userId:uid, name:item.name, itemId:item.id, type:item.type, amount:total, delivery, createdAt:now, status:'paid' };
    const orderWithMint = (item.type==='bots-nft') ? { ...baseOrder, nftMint:{ status:'queued' } } : baseOrder;
    setOrders(prev => [ ...prev, orderWithMint ]);

    // إذا كان NFT، ابدأ عملية السكّ بالخلفية (Mock الآن / API لاحقًا)
    if(item.type==='bots-nft'){
      NFTMintService.startMint({ orderId: oid, item, userId: uid, onUpdate: (partial)=>{
        setOrders(prev => prev.map(o => o.id===oid ? { ...o, nftMint:{ ...(o.nftMint||{}), ...partial } } : o));
      }}).catch(err => {
        setOrders(prev => prev.map(o => o.id===oid ? { ...o, nftMint:{ status:'failed', error:String(err?.message||err) } } : o));
      });
    }

    return { ok:true, orderId: oid };
  }

  // عمليات البوت/الصوت
  function startBot(id){ setUsersStore(prev => { const cur=prev[uid]||makeDefaultRecord(); return { ...prev, [uid]: { ...cur, bots: cur.bots.map(b=>b.id===id?{...b, status:'running'}:b) } }; }); }
  function stopBot(id){ setUsersStore(prev => { const cur=prev[uid]||makeDefaultRecord(); return { ...prev, [uid]: { ...cur, bots: cur.bots.map(b=>b.id===id?{...b, status:'stopped'}:b) } }; }); }
  function removeOwnedBot(id){ setUsersStore(prev => { const cur=prev[uid]||makeDefaultRecord(); return { ...prev, [uid]: { ...cur, bots: cur.bots.filter(b=>b.id!==id) } }; }); }
  function removeOwnedSound(id){ setUsersStore(prev => { const cur=prev[uid]||makeDefaultRecord(); return { ...prev, [uid]: { ...cur, sounds: cur.sounds.filter(s=>s.id!==id) } }; }); }
  function topUp(amount){ const inc=Math.max(0,Number(amount||0)); setUsersStore(prev => { const cur=prev[uid]||makeDefaultRecord(); return { ...prev, [uid]: { ...cur, balance: cur.balance + inc } }; }); }

  // استرجاع
  function refundOrder(oid){
    setOrders(prevOrders => {
      const o = prevOrders.find(x=>x.id===oid);
      if(!o || o.status!=='paid') return prevOrders;
      setUsersStore(prev => {
        const cur = prev[o.userId] || makeDefaultRecord();
        let bots = cur.bots, sounds = cur.sounds;
        if(o.type==='bots' || o.type==='bots-nft') bots = bots.filter(b=>b.id!==o.itemId);
        if(o.type==='sounds') sounds = sounds.filter(s=>s.id!==o.itemId);
        return { ...prev, [o.userId]: { ...cur, balance: cur.balance + o.amount, bots, sounds } };
      });
      return prevOrders.map(x => x.id===oid ? { ...x, status:'refunded', refundedAt: Date.now() } : x);
    });
  }

  const myOrders = useMemo(()=> orders.filter(o=>o.userId===uid), [orders, uid]);
  const allOrders = orders; // للواجهة الإدارية فقط

  const value = useMemo(()=>({
    balance: rec.balance,
    bots: rec.bots,
    sounds: rec.sounds,
    orders: myOrders,
    addFromPurchase, startBot, stopBot, removeOwnedBot, removeOwnedSound, topUp,
    allOrders, refundOrder,
  }), [rec.balance, rec.bots, rec.sounds, myOrders, allOrders]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useUserInventory(){ const v = useContext(Ctx); if(!v) throw new Error('useUserInventory must be used inside UserInventoryProvider'); return v; }
```

> **ملحوظة**: هذه النسخة تحافظ على نفس API السابق، فلا تحتاج لتعديل صفحات الدفع/المعاينة؛ فقط استبدل الاستيراد لاستخدام هذا الملف بدلاً من النسخة القديمة.

---

## 3) (اختياري للتطوير فقط) تحديث صفحة المشرف لإظهار حالة السكّ

**المستخدم النهائي لن يراها** في الراوتر الآمن. هذا فقط لتتبع حالة الـMint أثناء التطوير.

```jsx
// src/pages/AdminOrders.i18n.jsx (محدّثة بعرض حالة Mint)
import React from 'react';
import { useTranslation } from 'react-i18next';
import { useUserInventory } from '../context/UserInventoryContext';
import { useAuth } from '../context/AuthContext';

export default function AdminOrders(){
  const { t } = useTranslation();
  const inv = useUserInventory();
  const { currentUser } = useAuth();
  if(currentUser?.role !== 'admin'){
    return <div className="min-h-screen w-full bg-[#05060a] text-cyan-50"><div className="mx-auto max-w-5xl px-5 py-10"><div className="rounded-2xl border border-cyan-300/30 bg-black/40 p-6 text-center text-cyan-100/85">{t('NOT_AUTHORIZED',{defaultValue:'Not authorized'})}</div></div></div>;
  }
  const fmt = (ts)=> new Date(ts).toLocaleString();
  return (
    <div className="min-h-screen w-full bg-[#05060a] text-cyan-50">
      <div className="mx-auto max-w-6xl px-5 py-8">
        <h1 className="mb-4 text-2xl font-extrabold text-cyan-100">{t('ADMIN_ORDERS_TITLE',{defaultValue:'All Orders (Admin)'})}</h1>
        <div className="overflow-x-auto rounded-2xl border border-cyan-300/30">
          <table className="min-w-full text-sm">
            <thead className="bg-black/40 text-cyan-200">
              <tr>
                <th className="px-3 py-2 text-left">{t('ORDER_ID',{defaultValue:'Order ID'})}</th>
                <th className="px-3 py-2 text-left">{t('USER',{defaultValue:'User'})}</th>
                <th className="px-3 py-2 text-left">{t('ITEM',{defaultValue:'Item'})}</th>
                <th className="px-3 py-2 text-left">{t('TYPE',{defaultValue:'Type'})}</th>
                <th className="px-3 py-2 text-left">{t('AMOUNT',{defaultValue:'Amount'})}</th>
                <th className="px-3 py-2 text-left">Mint</th>
                <th className="px-3 py-2 text-left">{t('DATE',{defaultValue:'Date'})}</th>
                <th className="px-3 py-2 text-left">{t('STATUS',{defaultValue:'Status'})}</th>
              </tr>
            </thead>
            <tbody>
              {inv.allOrders.map((o)=>{
                const m = o.nftMint || {}; // status, txId, tokenId, metadataUri
                return (
                  <tr key={o.id} className="odd:bg-black/30 even:bg-black/20 text-cyan-100">
                    <td className="px-3 py-2 font-mono">{o.id}</td>
                    <td className="px-3 py-2">{o.userId}</td>
                    <td className="px-3 py-2">{o.name}</td>
                    <td className="px-3 py-2">{o.type}</td>
                    <td className="px-3 py-2 font-mono">{o.amount}</td>
                    <td className="px-3 py-2">
                      {o.type==='bots-nft' ? (
                        <div className="space-y-1">
                          <div className="font-mono text-xs">status: {m.status||'-'}</div>
                          {m.tokenId && <div className="font-mono text-xs">tokenId: {m.tokenId}</div>}
                          {m.txId && <div className="font-mono text-xs">txId: {String(m.txId).slice(0,14)}…</div>}
                          {m.metadataUri && <div className="font-mono text-xs">meta: {m.metadataUri}</div>}
                        </div>
                      ) : (<span className="text-cyan-300/70">—</span>)}
                    </td>
                    <td className="px-3 py-2">{fmt(o.createdAt)}</td>
                    <td className="px-3 py-2">{o.status}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
```

---

## 4) كيف نفعّل ذلك الآن؟ (بدون كسر أي صفحة)

1. **أضف الملف** `src/services/NFTMintService.js`.
2. **استبدل** مزوّد المخزون بـ`UserInventoryContext.mint.jsx` بدل النسخة القديمة (اسم الملف يمكن أن يبقى `UserInventoryContext.jsx` لو أردت، المهم المحتوى).
3. لا تغيّر **صفحات Checkout/Preview** — هي بالفعل تستدعي `addFromPurchase` وستبدأ عملية الـMint تلقائيًا عند شراء **bots-nft**.
4. (اختياري للتطوير) استخدم مسار **/admin/orders** في بيئة التطوير فقط لتفقد حالة الـMint؛ في الإنتاج استعمل الراوتر الآمن الذي لا يعرّض الأدمن للمستخدم.

> الآن أصبح لدينا **كود سكّ NFT مكتمل** يعمل Mock، وجاهز للتبديل إلى **Backend API** لاحقًا (فقط بدّل `NFTMintService.mode = 'api'` وفعّل المسارات في السيرفر).

