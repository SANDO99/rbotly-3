// AdminNFTPurchaseRequestsPage.js - صفحة مراجعة طلبات شراء بوت NFT مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const admin_nft_purchase_requests_en = {
  nftPurchaseRequestsTitle: "NFT Bot Purchase Requests",
  buyer: "Buyer",
  bot: "Bot Name",
  date: "Request Date",
  status: "Status",
  approved: "Approved",
  pending: "Pending",
  rejected: "Rejected",
  actions: "Actions",
  approve: "Approve",
  reject: "Reject",
};
export const admin_nft_purchase_requests_ar = {
  nftPurchaseRequestsTitle: "مراجعة طلبات شراء بوت NFT",
  buyer: "المشتري",
  bot: "اسم البوت",
  date: "تاريخ الطلب",
  status: "الحالة",
  approved: "معتمد",
  pending: "بانتظار المراجعة",
  rejected: "مرفوض",
  actions: "إجراءات",
  approve: "اعتماد",
  reject: "رفض",
};
export const admin_nft_purchase_requests_fr = {
  nftPurchaseRequestsTitle: "Demandes d'achat de bots NFT",
  buyer: "Acheteur",
  bot: "Nom du bot",
  date: "Date de la demande",
  status: "Statut",
  approved: "Approuvé",
  pending: "En attente",
  rejected: "Rejeté",
  actions: "Actions",
  approve: "Approuver",
  reject: "Rejeter",
};
export const admin_nft_purchase_requests_el = {
  nftPurchaseRequestsTitle: "Αιτήσεις αγοράς NFT Bots",
  buyer: "Αγοραστής",
  bot: "Όνομα bot",
  date: "Ημερομηνία αίτησης",
  status: "Κατάσταση",
  approved: "Εγκρίθηκε",
  pending: "Σε αναμονή",
  rejected: "Απορρίφθηκε",
  actions: "Ενέργειες",
  approve: "Έγκριση",
  reject: "Απόρριψη",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: admin_nft_purchase_requests_en,
  ar: admin_nft_purchase_requests_ar,
  fr: admin_nft_purchase_requests_fr,
  el: admin_nft_purchase_requests_el,
};

const mockRequests = [
  { id: 1, buyer: "Ali Khaled", bot: "EduBotX", date: "2025-08-07", status: "pending" },
  { id: 2, buyer: "Sara Badr", bot: "Mixtral Pro", date: "2025-08-06", status: "approved" },
  { id: 3, buyer: "Lucas Dupont", bot: "ArtBot Mini", date: "2025-08-05", status: "rejected" },
];

export default function AdminNFTPurchaseRequestsPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [requests, setRequests] = useState(mockRequests);

  // أماكن الربط مع API لاعتماد أو رفض الطلب مستقبلاً
  const handleApprove = (id) => {
    setRequests(requests.map(r => r.id === id ? { ...r, status: "approved" } : r));
  };
  const handleReject = (id) => {
    setRequests(requests.map(r => r.id === id ? { ...r, status: "rejected" } : r));
  };

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("nftPurchaseRequestsTitle")}</h1>
      <table className="w-full table-auto text-left border">
        <thead>
          <tr className="bg-zinc-900">
            <th className="p-2 border">#</th>
            <th className="p-2 border">{t("buyer")}</th>
            <th className="p-2 border">{t("bot")}</th>
            <th className="p-2 border">{t("date")}</th>
            <th className="p-2 border">{t("status")}</th>
            <th className="p-2 border">{t("actions")}</th>
          </tr>
        </thead>
        <tbody>
          {requests.map((r, i) => (
            <tr key={r.id} className="border-t">
              <td className="p-2 border">{i + 1}</td>
              <td className="p-2 border">{r.buyer}</td>
              <td className="p-2 border">{r.bot}</td>
              <td className="p-2 border">{r.date}</td>
              <td className="p-2 border">
                <span className={
                  r.status === "approved" ? "text-green-400" :
                  r.status === "pending" ? "text-yellow-400" : "text-red-400"
                }>
                  {t(r.status)}
                </span>
              </td>
              <td className="p-2 border flex gap-2">
                {r.status !== "approved" && (
                  <button onClick={() => handleApprove(r.id)} className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded">
                    {t("approve")}
                  </button>
                )}
                {r.status !== "rejected" && (
                  <button onClick={() => handleReject(r.id)} className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded">
                    {t("reject")}
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}
