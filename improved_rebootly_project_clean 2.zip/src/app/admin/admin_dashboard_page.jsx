// AdminDashboardPage.js - لوحة تحكم المشرف (Canva)
// مع دعم الترجمة الرباعية EN, AR, FR, EL

import { useState } from "react";
import { admin_dashboard_en } from "./admin_dashboard_en";
import { admin_dashboard_ar } from "./admin_dashboard_ar";
import { admin_dashboard_fr } from "./admin_dashboard_fr";
import { admin_dashboard_el } from "./admin_dashboard_el";

// --- ملفات الترجمة لكل لغة ---
const translations = {
  en: admin_dashboard_en,
  ar: admin_dashboard_ar,
  fr: admin_dashboard_fr,
  el: admin_dashboard_el,
};

export default function AdminDashboardPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  // مثال بيانات وهمية للإحصائيات (سيتم ربطها بـ API لاحقاً)
  const stats = [
    { key: "users", value: 1200 },
    { key: "products", value: 250 },
    { key: "nftbots", value: 41 },
    { key: "addons", value: 9 },
    { key: "messages", value: 34 },
    { key: "mintLogs", value: 12 },
  ];

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">
        {t("dashboardTitle")}
      </h1>

      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {stats.map((stat) => (
          <div key={stat.key} className="bg-zinc-900 p-6 rounded-xl shadow-lg flex flex-col items-center">
            <h2 className="text-lg font-semibold mb-2">{t(stat.key)}</h2>
            <p className="text-4xl font-bold text-[var(--neon)]">{stat.value}</p>
          </div>
        ))}
      </section>

      {/* أماكن ربط أي Widgets أو رسومات مستقبلية */}
      {/* TODO: هنا يمكن ربط رسوم بيانية أو Widgets مستقبلية (مثلاً: نشاطات، أرباح، تحذيرات...) */}

      <section className="mt-10">
        <h3 className="text-xl font-bold mb-4">{t("quickActions")}</h3>
        <div className="flex flex-wrap gap-4">
          {/* أزرار الانتقال لصفحات الإدارة */}
          <a href="#/admin/users" className="bg-[var(--neon)] text-black px-4 py-2 rounded-xl shadow hover:scale-105 transition">
            {t("manageUsers")}
          </a>
          <a href="#/admin/products" className="bg-[var(--neon)] text-black px-4 py-2 rounded-xl shadow hover:scale-105 transition">
            {t("manageProducts")}
          </a>
          <a href="#/admin/nftbots" className="bg-[var(--neon)] text-black px-4 py-2 rounded-xl shadow hover:scale-105 transition">
            {t("reviewNFTBots")}
          </a>
          <a href="#/admin/addons" className="bg-[var(--neon)] text-black px-4 py-2 rounded-xl shadow hover:scale-105 transition">
            {t("reviewAddons")}
          </a>
          <a href="#/admin/messages" className="bg-[var(--neon)] text-black px-4 py-2 rounded-xl shadow hover:scale-105 transition">
            {t("viewMessages")}
          </a>
          <a href="#/admin/mintlogs" className="bg-[var(--neon)] text-black px-4 py-2 rounded-xl shadow hover:scale-105 transition">
            {t("mintLogs")}
          </a>
        </div>
      </section>
    </main>
  );
}

// -------------- ملفات الترجمة لكل لغة --------------
// admin_dashboard_en.js
export const admin_dashboard_en = {
  dashboardTitle: "Admin Dashboard",
  users: "Users",
  products: "Products",
  nftbots: "NFT Bots",
  addons: "Add-ons",
  messages: "Messages",
  mintLogs: "Mint Logs",
  quickActions: "Quick Actions",
  manageUsers: "Manage Users",
  manageProducts: "Manage Products",
  reviewNFTBots: "Review NFT Bots",
  reviewAddons: "Review Add-ons",
  viewMessages: "View Messages",
};
// admin_dashboard_ar.js
export const admin_dashboard_ar = {
  dashboardTitle: "لوحة تحكم المشرف",
  users: "المستخدمون",
  products: "المنتجات",
  nftbots: "بوتات NFT",
  addons: "الإضافات",
  messages: "الرسائل",
  mintLogs: "سجلات السك",
  quickActions: "إجراءات سريعة",
  manageUsers: "إدارة المستخدمين",
  manageProducts: "إدارة المنتجات",
  reviewNFTBots: "مراجعة بوتات NFT",
  reviewAddons: "مراجعة الإضافات",
  viewMessages: "عرض الرسائل",
};
// admin_dashboard_fr.js
export const admin_dashboard_fr = {
  dashboardTitle: "Tableau de bord administrateur",
  users: "Utilisateurs",
  products: "Produits",
  nftbots: "Bots NFT",
  addons: "Add-ons",
  messages: "Messages",
  mintLogs: "Journaux de Mint",
  quickActions: "Actions rapides",
  manageUsers: "Gérer les utilisateurs",
  manageProducts: "Gérer les produits",
  reviewNFTBots: "Revoir les bots NFT",
  reviewAddons: "Revoir les add-ons",
  viewMessages: "Voir les messages",
};
// admin_dashboard_el.js
export const admin_dashboard_el = {
  dashboardTitle: "Πίνακας διαχείρισης διαχειριστή",
  users: "Χρήστες",
  products: "Προϊόντα",
  nftbots: "NFT Bots",
  addons: "Πρόσθετα",
  messages: "Μηνύματα",
  mintLogs: "Αρχεία Mint",
  quickActions: "Γρήγορες ενέργειες",
  manageUsers: "Διαχείριση χρηστών",
  manageProducts: "Διαχείριση προϊόντων",
  reviewNFTBots: "Αξιολόγηση NFT Bots",
  reviewAddons: "Αξιολόγηση πρόσθετων",
  viewMessages: "Προβολή μηνυμάτων",
};
