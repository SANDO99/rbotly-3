import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";

// ------------------------------------------------------------
// Rbotly Marketplace — Home Page (Neon / 4 Languages / Mock)
// - TailwindCSS for styling
// - Framer Motion for subtle animations
// - Self-contained i18n (AR, EN, FR, EL)
// - Search + Filters (category, language, price min/max, tags)
// - Three sections: Bots NFT, Public Bots, Sounds
// - Mock data; links point to planned routes
// ------------------------------------------------------------

const DICT = {
  ar: {
    MARKETPLACE_TITLE: "سوق Rbotly",
    HERO_SUBTITLE: "استكشف بوتات NFT والبوتات العامة وحِزم الأصوات.",
    SEARCH_PLACEHOLDER: "ابحث عن بوت أو صوت...",
    FILTERS: "الفلاتر",
    CATEGORY: "القسم",
    LANGUAGE: "اللغة",
    PRICE: "السعر",
    TAGS: "الوسوم (افصل بفواصل ,)",
    BOTS_NFT: "بوتات NFT",
    PUBLIC_BOTS: "بوتات عامة",
    SOUNDS: "الأصوات",
    VIEW_ALL: "تصفح الكل",
    TRY: "جرّب",
    BROWSE: "تصفّح",
    BUY: "شراء",
    ALL: "الكل",
    MIN: "الأدنى",
    MAX: "الأعلى",
    TOKENS: "توكن",
    NO_RESULTS: "لا توجد نتائج مطابقة.",
  },
  en: {
    MARKETPLACE_TITLE: "Rbotly Marketplace",
    HERO_SUBTITLE: "Discover NFT bots, public bots, and voice packs.",
    SEARCH_PLACEHOLDER: "Search for a bot or voice...",
    FILTERS: "Filters",
    CATEGORY: "Category",
    LANGUAGE: "Language",
    PRICE: "Price",
    TAGS: "Tags (comma-separated)",
    BOTS_NFT: "Bots NFT",
    PUBLIC_BOTS: "Public Bots",
    SOUNDS: "Sounds",
    VIEW_ALL: "View all",
    TRY: "Try",
    BROWSE: "Browse",
    BUY: "Buy",
    ALL: "All",
    MIN: "Min",
    MAX: "Max",
    TOKENS: "Token",
    NO_RESULTS: "No matching results.",
  },
  fr: {
    MARKETPLACE_TITLE: "Marché Rbotly",
    HERO_SUBTITLE: "Découvrez des bots NFT, des bots publics et des packs de voix.",
    SEARCH_PLACEHOLDER: "Recherchez un bot ou une voix...",
    FILTERS: "Filtres",
    CATEGORY: "Catégorie",
    LANGUAGE: "Langue",
    PRICE: "Prix",
    TAGS: "Mots-clés (séparés par des virgules)",
    BOTS_NFT: "Bots NFT",
    PUBLIC_BOTS: "Bots publics",
    SOUNDS: "Voix",
    VIEW_ALL: "Tout voir",
    TRY: "Essayer",
    BROWSE: "Parcourir",
    BUY: "Acheter",
    ALL: "Tous",
    MIN: "Min",
    MAX: "Max",
    TOKENS: "Jeton",
    NO_RESULTS: "Aucun résultat correspondant.",
  },
  el: {
    MARKETPLACE_TITLE: "Αγορά Rbotly",
    HERO_SUBTITLE: "Ανακάλυψε NFT bots, δημόσια bots και πακέτα φωνών.",
    SEARCH_PLACEHOLDER: "Αναζήτησε bot ή φωνή...",
    FILTERS: "Φίλτρα",
    CATEGORY: "Κατηγορία",
    LANGUAGE: "Γλώσσα",
    PRICE: "Τιμή",
    TAGS: "Ετικέτες (χωρίζονται με κόμμα)",
    BOTS_NFT: "Bots NFT",
    PUBLIC_BOTS: "Δημόσια Bots",
    SOUNDS: "Ήχοι",
    VIEW_ALL: "Προβολή όλων",
    TRY: "Δοκίμασε",
    BROWSE: "Περιήγηση",
    BUY: "Αγορά",
    ALL: "Όλα",
    MIN: "Ελάχιστο",
    MAX: "Μέγιστο",
    TOKENS: "Token",
    NO_RESULTS: "Δεν βρέθηκαν αποτελέσματα.",
  },
};

const CATS = [
  { key: "all", label: { ar: "الكل", en: "All", fr: "Tous", el: "Όλα" } },
  { key: "bots-nft", label: { ar: "بوتات NFT", en: "Bots NFT", fr: "Bots NFT", el: "Bots NFT" } },
  { key: "bots", label: { ar: "بوتات عامة", en: "Public Bots", fr: "Bots publics", el: "Δημόσια Bots" } },
  { key: "sounds", label: { ar: "الأصوات", en: "Sounds", fr: "Voix", el: "Ήχοι" } },
];

const MOCK = {
  "bots-nft": [
    {
      id: "nft-guardian-01",
      type: "bots-nft",
      name: "Guardian AI",
      description: "Bot NFT للحماية والمراقبة الذكية.",
      image: "https://placehold.co/640x360/png",
      priceTokens: 1200,
      language: "ar",
      tags: ["security", "monitoring"],
    },
    {
      id: "nft-mentor-02",
      type: "bots-nft",
      name: "Mentor AI",
      description: "Bot NFT للتعليم والدروس القصيرة.",
      image: "https://placehold.co/640x360/png",
      priceTokens: 950,
      language: "en",
      tags: ["education"],
    },
    {
      id: "nft-stylist-03",
      type: "bots-nft",
      name: "Stylist AI",
      description: "Bot NFT لموضة ولبس يومي.",
      image: "https://placehold.co/640x360/png",
      priceTokens: 720,
      language: "fr",
      tags: ["lifestyle", "fashion"],
    },
    {
      id: "nft-trader-04",
      type: "bots-nft",
      name: "Trader AI",
      description: "Bot NFT مساعد تداول أساسي.",
      image: "https://placehold.co/640x360/png",
      priceTokens: 1400,
      language: "el",
      tags: ["finance"],
    },
  ],
  bots: [
    {
      id: "public-researcher-01",
      type: "bots",
      name: "Researcher",
      description: "بوت للبحث الذكي عن المعلومات.",
      image: "https://placehold.co/640x360/png",
      priceTokens: 300,
      language: "ar",
      tags: ["research", "web"],
    },
    {
      id: "public-writer-02",
      type: "bots",
      name: "Writer",
      description: "بوت كتابة مقالات ومنشورات.",
      image: "https://placehold.co/640x360/png",
      priceTokens: 280,
      language: "fr",
      tags: ["writing"],
    },
    {
      id: "public-coach-03",
      type: "bots",
      name: "Coach",
      description: "بوت نصائح يومية وتحفيز.",
      image: "https://placehold.co/640x360/png",
      priceTokens: 260,
      language: "en",
      tags: ["productivity"],
    },
  ],
  sounds: [
    {
      id: "voice-orion",
      type: "sounds",
      name: "Orion Male",
      description: "صوت ذكوري واضح للرواية.",
      image: "https://placehold.co/640x360/png",
      priceTokens: 150,
      language: "en",
      tags: ["male", "narration", "tts"],
    },
    {
      id: "voice-lyra",
      type: "sounds",
      name: "Lyra Female",
      description: "صوت أنثوي دافئ لفيديوهات قصيرة.",
      image: "https://placehold.co/640x360/png",
      priceTokens: 160,
      language: "el",
      tags: ["female", "shorts"],
    },
    {
      id: "voice-samir",
      type: "sounds",
      name: "Samir Arabic",
      description: "صوت عربي محايد للبرامج الحوارية.",
      image: "https://placehold.co/640x360/png",
      priceTokens: 170,
      language: "ar",
      tags: ["male", "neutral"],
    },
  ],
};

function useI18n(lang) {
  return (k) => (DICT[lang] && DICT[lang][k]) || DICT.en[k] || k;
}

function useRTL(lang) {
  useEffect(() => {
    const rtl = lang === "ar";
    document.documentElement.dir = rtl ? "rtl" : "ltr";
    document.documentElement.lang = lang;
  }, [lang]);
}

function Chip({ children }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-cyan-300/30 bg-cyan-300/10 px-2.5 py-1 text-xs text-cyan-100">
      {children}
    </span>
  );
}

function Card({ item, t, onTry, onBrowse, onBuy }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-cyan-300/25 bg-gradient-to-b from-cyan-400/10 to-cyan-400/5 shadow-[0_0_24px_rgba(0,229,255,0.12)]"
    >
      <div className="aspect-video w-full overflow-hidden bg-black/60">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={item.image}
          alt={item.name}
          className="h-full w-full object-cover opacity-90 transition-opacity duration-200 group-hover:opacity-100"
        />
      </div>
      <div className="p-4">
        <div className="font-semibold tracking-wide text-cyan-100">{item.name}</div>
        <div className="mt-1 line-clamp-2 text-sm text-cyan-100/80">{item.description}</div>
        <div className="mt-3 flex items-center justify-between">
          <div className="font-mono text-cyan-200">
            {item.priceTokens} {t("TOKENS")}
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => onTry?.(item)}
              className="rounded-md border border-cyan-300/40 px-3 py-1.5 text-sm text-cyan-50 hover:bg-cyan-500/10"
            >
              {t("TRY")}
            </button>
            <button
              onClick={() => onBrowse?.(item)}
              className="rounded-md border border-cyan-300/40 px-3 py-1.5 text-sm text-cyan-50 hover:bg-cyan-500/10"
            >
              {t("BROWSE")}
            </button>
            <button
              onClick={() => onBuy?.(item)}
              className="rounded-md border border-cyan-300/40 px-3 py-1.5 text-sm text-cyan-50 hover:bg-cyan-500/10"
            >
              {t("BUY")}
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function Section({ title, href, items, t, onTry, onBrowse, onBuy }) {
  return (
    <section className="mb-10">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h3 className="text-lg font-bold text-cyan-100">{title}</h3>
          <Chip>{items.length} items</Chip>
        </div>
        <a href={href} className="rounded-lg border border-cyan-300/40 px-3 py-1.5 text-sm text-cyan-50 hover:bg-cyan-500/10">
          {t("VIEW_ALL")}
        </a>
      </div>
      {items.length === 0 ? (
        <div className="rounded-xl border border-cyan-300/25 bg-black/30 p-4 text-center text-cyan-100/80">
          {t("NO_RESULTS")}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.slice(0, 6).map((item) => (
            <Card key={item.id} item={item} t={t} onTry={onTry} onBrowse={onBrowse} onBuy={onBuy} />
          ))}
        </div>
      )}
    </section>
  );
}

export default function MarketplaceHome() {
  const [lang, setLang] = useState("ar");
  const t = useI18n(lang);
  useRTL(lang);

  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const [langFilter, setLangFilter] = useState("all");
  const [minP, setMinP] = useState("");
  const [maxP, setMaxP] = useState("");
  const [tags, setTags] = useState("");

  const match = (item) => {
    const text = `${item.name} ${item.description}`.toLowerCase();
    if (q && !text.includes(q.toLowerCase())) return false;
    if (langFilter !== "all" && item.language !== langFilter) return false;
    const p = item.priceTokens ?? 0;
    if (minP !== "" && p < Number(minP)) return false;
    if (maxP !== "" && p > Number(maxP)) return false;
    const tagList = tags
      .split(",")
      .map((s) => s.trim().toLowerCase())
      .filter(Boolean);
    if (tagList.length) {
      const itemTags = (item.tags || []).map((s) => s.toLowerCase());
      const ok = tagList.every((tg) => itemTags.includes(tg));
      if (!ok) return false;
    }
    return true;
  };

  const filtered = useMemo(() => {
    const all = {
      "bots-nft": MOCK["bots-nft"].filter(match),
      bots: MOCK.bots.filter(match),
      sounds: MOCK.sounds.filter(match),
    };
    if (cat === "all") return all;
    return { [cat]: all[cat] };
  }, [q, cat, langFilter, minP, maxP, tags, lang]);

  const onTry = (item) => alert(`Try → ${item.name}`);
  const onBuy = (item) => alert(`Buy → ${item.name}`);
  const onBrowse = (item) => {
    if (item.type === "bots-nft") window.location.href = "/market/bots-nft";
    else if (item.type === "bots") window.location.href = "/market/bots";
    else window.location.href = "/market/sounds";
  };

  return (
    <div className="min-h-screen w-full bg-[#05060a] bg-[radial-gradient(1200px_600px_at_10%_-10%,rgba(0,229,255,0.08),transparent_40%),radial-gradient(900px_500px_at_90%_0%,rgba(0,229,255,0.06),transparent_35%)] text-cyan-50">
      <div className="mx-auto max-w-6xl px-5 py-8">
        {/* Header */}
        <header className="mb-6">
          <div className="mb-2 flex flex-wrap items-center justify-between gap-3">
            <motion.h1 initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="text-[clamp(26px,4vw,42px)] font-extrabold tracking-wide text-cyan-100 drop-shadow-[0_0_22px_rgba(0,229,255,0.18)]">
              {t("MARKETPLACE_TITLE")}
            </motion.h1>
            <select
              value={lang}
              onChange={(e) => setLang(e.target.value)}
              className="min-w-[140px] rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 outline-none ring-0 transition focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            >
              <option value="ar">العربية</option>
              <option value="en">English</option>
              <option value="fr">Français</option>
              <option value="el">Ελληνικά</option>
            </select>
          </div>
          <p className="text-cyan-100/80">{t("HERO_SUBTITLE")}</p>
        </header>

        {/* Filters panel */}
        <div className="mb-6 rounded-2xl border border-cyan-300/30 bg-gradient-to-b from-cyan-400/10 to-cyan-400/5 p-4 shadow-[0_0_30px_rgba(0,229,255,0.12)]">
          <div className="mb-3 flex items-center justify-between">
            <strong className="text-cyan-100">{t("FILTERS")}</strong>
            <div className="flex flex-wrap gap-2">
              <Chip>AR/EN/FR/EL</Chip>
              <Chip>Neon UI</Chip>
              <Chip>Mock Data</Chip>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("SEARCH_PLACEHOLDER")}
              className="col-span-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20 sm:col-span-2 lg:col-span-5"
            />
            <select
              value={cat}
              onChange={(e) => setCat(e.target.value)}
              className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            >
              {CATS.map((c) => (
                <option key={c.key} value={c.key}>
                  {c.label[lang] ?? c.key}
                </option>
              ))}
            </select>
            <select
              value={langFilter}
              onChange={(e) => setLangFilter(e.target.value)}
              className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            >
              <option value="all">{t("ALL")}</option>
              <option value="ar">العربية</option>
              <option value="en">English</option>
              <option value="fr">Français</option>
              <option value="el">Ελληνικά</option>
            </select>
            <input
              type="number"
              inputMode="numeric"
              value={minP}
              onChange={(e) => setMinP(e.target.value)}
              placeholder={t("MIN")}
              className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            />
            <input
              type="number"
              inputMode="numeric"
              value={maxP}
              onChange={(e) => setMaxP(e.target.value)}
              placeholder={t("MAX")}
              className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            />
            <input
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder={t("TAGS")}
              className="col-span-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20 sm:col-span-2 lg:col-span-5"
            />
          </div>
        </div>

        {/* Sections */}
        {(cat === "all" || cat === "bots-nft") && (
          <Section
            title={t("BOTS_NFT")}
            href="/market/bots-nft"
            items={(filtered["bots-nft"] || [])}
            t={t}
            onTry={onTry}
            onBrowse={onBrowse}
            onBuy={onBuy}
          />
        )}

        {(cat === "all" || cat === "bots") && (
          <Section
            title={t("PUBLIC_BOTS")}
            href="/market/bots"
            items={(filtered.bots || [])}
            t={t}
            onTry={onTry}
            onBrowse={onBrowse}
            onBuy={onBuy}
          />
        )}

        {(cat === "all" || cat === "sounds") && (
          <Section
            title={t("SOUNDS")}
            href="/market/sounds"
            items={(filtered.sounds || [])}
            t={t}
            onTry={onTry}
            onBrowse={onBrowse}
            onBuy={onBuy}
          />
        )}
      </div>
    </div>
  );
}
