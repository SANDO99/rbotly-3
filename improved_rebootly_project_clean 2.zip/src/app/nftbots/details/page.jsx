// NFTBotDetailsPage.js - صفحة تفاصيل بوت NFT مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const nft_bot_details_page_en = {
  botDetailsTitle: "NFT Bot Details",
  owner: "Owner",
  buy: "Buy",
  price: "Price",
  features: "Features",
  downloads: "Downloads",
  category: "Category",
  uploadDate: "Upload date",
  description: "Description",
  reviews: "Reviews",
  leaveReview: "Leave a Review",
  yourReview: "Your review...",
  send: "Send",
  sent: "Review sent!",
};
export const nft_bot_details_page_ar = {
  botDetailsTitle: "تفاصيل بوت NFT",
  owner: "المالك",
  buy: "شراء",
  price: "السعر",
  features: "المميزات",
  downloads: "التنزيلات",
  category: "الفئة",
  uploadDate: "تاريخ الرفع",
  description: "الوصف",
  reviews: "التقييمات",
  leaveReview: "اترك تقييمًا",
  yourReview: "تقييمك...",
  send: "إرسال",
  sent: "تم إرسال التقييم!",
};
export const nft_bot_details_page_fr = {
  botDetailsTitle: "Détails du bot NFT",
  owner: "Propriétaire",
  buy: "Acheter",
  price: "Prix",
  features: "Fonctionnalités",
  downloads: "Téléchargements",
  category: "Catégorie",
  uploadDate: "Date d'ajout",
  description: "Description",
  reviews: "Avis",
  leaveReview: "Laisser un avis",
  yourReview: "Votre avis...",
  send: "Envoyer",
  sent: "Avis envoyé !",
};
export const nft_bot_details_page_el = {
  botDetailsTitle: "Λεπτομέρειες NFT Bot",
  owner: "Ιδιοκτήτης",
  buy: "Αγορά",
  price: "Τιμή",
  features: "Χαρακτηριστικά",
  downloads: "Λήψεις",
  category: "Κατηγορία",
  uploadDate: "Ημερομηνία ανάρτησης",
  description: "Περιγραφή",
  reviews: "Αξιολογήσεις",
  leaveReview: "Αφήστε μια αξιολόγηση",
  yourReview: "Η αξιολόγησή σας...",
  send: "Αποστολή",
  sent: "Η αξιολόγηση εστάλη!",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: nft_bot_details_page_en,
  ar: nft_bot_details_page_ar,
  fr: nft_bot_details_page_fr,
  el: nft_bot_details_page_el,
};

const mockBot = {
  id: 1,
  name: "Mixtral NFT Bot",
  img: "/img/nft1.png",
  owner: "ahmed@example.com",
  price: 15,
  downloads: 320,
  category: "Education",
  uploadDate: "2025-07-15",
  description: "Mixtral is a compact AI assistant for mobile. Works offline, supports local TTS & STT, and can be trained with educational books.",
  features: [
    "Offline AI chat",
    "Supports voice commands",
    "Easy to train with your data",
  ],
};
const mockReviews = [
  { id: 1, user: "Sara B.", date: "2025-08-01", text: "Great bot for my school!" },
  { id: 2, user: "Lucas D.", date: "2025-08-03", text: "Very smart, works offline." },
];

export default function NFTBotDetailsPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [reviews, setReviews] = useState(mockReviews);
  const [review, setReview] = useState("");
  const [sent, setSent] = useState(false);

  const handleSend = (e) => {
    e.preventDefault();
    if (!review.trim()) return;
    setReviews([
      ...reviews,
      { id: Date.now(), user: "You", date: new Date().toISOString().slice(0, 10), text: review }
    ]);
    setReview("");
    setSent(true);
    setTimeout(() => setSent(false), 1500);
  };

  return (
    <main className="min-h-screen bg-black text-white p-6 max-w-2xl mx-auto">
      <div className="flex gap-8 flex-col md:flex-row md:items-center mb-8">
        <div className="flex-shrink-0 w-48 h-48 bg-zinc-900 rounded-2xl flex items-center justify-center overflow-hidden">
          <img src={mockBot.img} alt={mockBot.name} className="max-w-full max-h-full" />
        </div>
        <div className="flex-1 flex flex-col gap-2">
          <h1 className="text-3xl font-bold text-[var(--neon)] mb-2">{mockBot.name}</h1>
          <div className="text-xs text-gray-400">{t("owner")}: {mockBot.owner}</div>
          <div className="text-lg font-semibold text-green-400 mb-1">{t("price")}: ${mockBot.price}</div>
          <div className="flex gap-4 text-sm text-gray-400 mb-2">
            <span>{t("downloads")}: {mockBot.downloads}</span>
            <span>{t("category")}: {mockBot.category}</span>
            <span>{t("uploadDate")}: {mockBot.uploadDate}</span>
          </div>
          <button className="bg-green-700 hover:bg-green-800 text-white px-4 py-2 rounded-xl w-max mt-2">{t("buy")}</button>
        </div>
      </div>
      <div className="mb-6">
        <h2 className="text-xl font-semibold text-[var(--neon)] mb-2">{t("features")}</h2>
        <ul className="list-disc pl-6">
          {mockBot.features.map((f, i) => <li key={i}>{f}</li>)}
        </ul>
      </div>
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-[var(--neon)] mb-2">{t("description")}</h2>
        <div className="bg-zinc-900 rounded-xl p-4 text-gray-200">{mockBot.description}</div>
      </div>
      <div className="mb-12">
        <h2 className="text-xl font-semibold text-[var(--neon)] mb-3">{t("reviews")}</h2>
        <ul className="flex flex-col gap-3 mb-4">
          {reviews.map(r => (
            <li key={r.id} className="bg-zinc-900 rounded-xl p-3">
              <div className="font-bold text-sm mb-1">{r.user} <span className="text-xs text-gray-400 ml-2">[{r.date}]</span></div>
              <div>{r.text}</div>
            </li>
          ))}
        </ul>
        <form onSubmit={handleSend} className="flex flex-col gap-2">
          <textarea
            value={review}
            onChange={e => setReview(e.target.value)}
            className="w-full min-h-[60px] p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none"
            placeholder={t("yourReview")}
          />
          <button
            type="submit"
            className="bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-xl w-max"
          >
            {t("send")}
          </button>
          {sent && <div className="text-green-400 font-semibold mt-1">{t("sent")}</div>}
        </form>
      </div>
    </main>
  );
}
