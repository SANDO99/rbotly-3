import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import Backend from 'i18next-http-backend';

// Initialize i18next with HTTP backend. It will load translations from
// /locales/{lng}/common.json (see scripts/convert-translations.js).
i18n
  .use(Backend)
  .use(initReactI18next)
  .init({
    lng: 'en',
    fallbackLng: 'en',
    debug: false,
    backend: {
      loadPath: '/locales/{{lng}}/common.json'
    },
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;