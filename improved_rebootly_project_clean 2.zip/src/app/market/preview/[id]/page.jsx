import React, { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";

// ------------------------------------------------------------
// Rbotly — Marketplace / Preview Page
// - Neon Blue on Dark
// - 4 Languages (AR, EN, FR, EL)
// - Mock catalog (NFT + Public bots)
// - Chat preview (text-only) with FREE TRIAL limits:
//     • Up to 5 user messages OR 500 tokens
// - When limit is reached → disable input + CTA Buy Now
// - Links: Back to Market, Buy → /checkout/:id
// ------------------------------------------------------------

const DICT = {
  ar: {
    PAGE_TITLE: "معاينة البوت",
    BACK: "رجوع إلى السوق",
    BUY_NOW: "اشترِ الآن",
    RESET: "إعادة ضبط الجلسة",
    INPUT_PLACEHOLDER: "اكتب رسالة للتجربة...",
    SEND: "إرسال",
    FREE_TRIAL: "تجربة مجانية: حتى 5 رسائل أو 500 توكن",
    MESSAGES: "رسائل",
    TOKENS: "توكن",
    LIMIT_REACHED: "انتهت التجربة المجانية. قم بالشراء لمواصلة الاستخدام.",
    NOT_FOUND: "البوت غير موجود",
    TRY_LEFT: "المتبقي",
    DESC: "الوصف",
  },
  en: {
    PAGE_TITLE: "Bot Preview",
    BACK: "Back to Market",
    BUY_NOW: "Buy Now",
    RESET: "Reset Session",
    INPUT_PLACEHOLDER: "Type a message to try...",
    SEND: "Send",
    FREE_TRIAL: "Free trial: up to 5 messages or 500 tokens",
    MESSAGES: "messages",
    TOKENS: "tokens",
    LIMIT_REACHED: "Free trial ended. Please purchase to continue.",
    NOT_FOUND: "Bot not found",
    TRY_LEFT: "left",
    DESC: "Description",
  },
  fr: {
    PAGE_TITLE: "Aperçu du bot",
    BACK: "Retour au Marché",
    BUY_NOW: "Acheter",
    RESET: "Réinitialiser la session",
    INPUT_PLACEHOLDER: "Écrivez un message pour tester...",
    SEND: "Envoyer",
    FREE_TRIAL: "Essai gratuit : jusqu'à 5 messages ou 500 jetons",
    MESSAGES: "messages",
    TOKENS: "jetons",
    LIMIT_REACHED: "Essai terminé. Veuillez acheter pour continuer.",
    NOT_FOUND: "Bot introuvable",
    TRY_LEFT: "restants",
    DESC: "Description",
  },
  el: {
    PAGE_TITLE: "Προεπισκόπηση Bot",
    BACK: "Πίσω στην Αγορά",
    BUY_NOW: "Αγορά τώρα",
    RESET: "Επαναφορά συνεδρίας",
    INPUT_PLACEHOLDER: "Γράψε μήνυμα για δοκιμή...",
    SEND: "Αποστολή",
    FREE_TRIAL: "Δωρεάν δοκιμή: έως 5 μηνύματα ή 500 tokens",
    MESSAGES: "μηνύματα",
    TOKENS: "tokens",
    LIMIT_REACHED: "Η δοκιμή ολοκληρώθηκε. Αγόρασε για συνέχεια.",
    NOT_FOUND: "Το bot δεν βρέθηκε",
    TRY_LEFT: "υπόλοιπο",
    DESC: "Περιγραφή",
  },
};

const LIMIT_MSGS = 5; // user messages
const LIMIT_TOKENS = 500; // total estimated tokens (user + bot)

// Mock catalog (merged NFT + Public)
const CATALOG = [
  // NFT
  { id: "nft-guardian-01", type: "bots-nft", name: "Guardian AI", description: "Bot NFT للحماية والمراقبة الذكية.", image: "https://placehold.co/640x360/png", priceTokens: 1200, language: "ar", tags: ["security", "monitoring"] },
  { id: "nft-mentor-02", type: "bots-nft", name: "Mentor AI", description: "Bot NFT للتعليم والدروس القصيرة.", image: "https://placehold.co/640x360/png", priceTokens: 950, language: "en", tags: ["education"] },
  { id: "nft-stylist-03", type: "bots-nft", name: "Stylist AI", description: "Bot NFT لموضة ولبس يومي.", image: "https://placehold.co/640x360/png", priceTokens: 720, language: "fr", tags: ["lifestyle", "fashion"] },
  { id: "nft-trader-04", type: "bots-nft", name: "Trader AI", description: "Bot NFT مساعد تداول أساسي.", image: "https://placehold.co/640x360/png", priceTokens: 1400, language: "el", tags: ["finance"] },
  // Public
  { id: "public-researcher-01", type: "bots", name: "Researcher", description: "بوت للبحث الذكي عن المعلومات.", image: "https://placehold.co/640x360/png", priceTokens: 300, language: "ar", tags: ["research", "web"] },
  { id: "public-writer-02", type: "bots", name: "Writer", description: "بوت كتابة مقالات ومنشورات.", image: "https://placehold.co/640x360/png", priceTokens: 280, language: "fr", tags: ["writing"] },
  { id: "public-coach-03", type: "bots", name: "Coach", description: "بوت نصائح يومية وتحفيز.", image: "https://placehold.co/640x360/png", priceTokens: 260, language: "en", tags: ["productivity"] },
];

function useI18n(lang) {
  return (k) => (DICT[lang]?.[k] ?? DICT.en[k] ?? k);
}

function useRTL(lang) {
  useEffect(() => {
    const rtl = lang === "ar";
    document.documentElement.dir = rtl ? "rtl" : "ltr";
    document.documentElement.lang = lang;
  }, [lang]);
}

function Chip({ children }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-cyan-300/30 bg-cyan-300/10 px-2.5 py-1 text-xs text-cyan-100">
      {children}
    </span>
  );
}

function estimateTokens(text = "") {
  const words = String(text).trim().split(/\s+/).filter(Boolean).length;
  // rough estimate: ~1.3 tokens/word (varies by language)
  return Math.round(words * 1.3);
}

function BotHeader({ t, bot }) {
  return (
    <div className="mb-5 grid grid-cols-1 gap-4 md:grid-cols-[240px,1fr]">
      <div className="overflow-hidden rounded-2xl border border-cyan-300/30 bg-black/50 shadow-[0_0_24px_rgba(0,229,255,0.12)]">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={bot.image} alt={bot.name} className="h-full w-full object-cover" />
      </div>
      <div className="flex flex-col justify-center">
        <h2 className="text-2xl font-extrabold tracking-wide text-cyan-100">{bot.name}</h2>
        <div className="mt-2 text-cyan-100/85">
          <span className="font-semibold">{t("DESC")}:</span> {bot.description}
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <Chip>{bot.type === "bots-nft" ? "NFT" : "Public"}</Chip>
          <Chip>{bot.priceTokens} {t("TOKENS")}</Chip>
          {bot.tags?.slice(0, 3).map((tg) => (
            <Chip key={tg}>#{tg}</Chip>
          ))}
        </div>
      </div>
    </div>
  );
}

function Message({ role, children }) {
  const isUser = role === "user";
  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[85%] rounded-2xl border px-3 py-2 text-sm leading-6 shadow-[0_0_18px_rgba(0,229,255,0.10)] ${
          isUser
            ? "border-cyan-300/40 bg-cyan-400/10 text-cyan-50"
            : "border-cyan-300/25 bg-black/40 text-cyan-100"
        }`}
      >
        {children}
      </div>
    </div>
  );
}

export default function MarketPreviewPage() {
  const [lang, setLang] = useState("ar");
  const t = useI18n(lang);
  useRTL(lang);

  const [botId, setBotId] = useState(() => {
    // Try to infer from URL: /market/preview/:id or ?id=
    const path = typeof window !== "undefined" ? window.location.pathname : "/";
    const byPath = path.split("/preview/")[1];
    if (byPath) return byPath.split("/")[0];
    const sp = typeof window !== "undefined" ? new URLSearchParams(window.location.search) : null;
    return sp?.get("id") || "nft-guardian-01"; // default
  });

  const bot = useMemo(() => CATALOG.find((b) => b.id === botId), [botId]);

  const [messages, setMessages] = useState(() => {
    const greeting = `Hi, I'm ${bot?.name || "Rbotly Bot"}. This is a read-only demo chat. Ask me anything!`;
    return bot
      ? [
          { role: "assistant", content: greeting },
        ]
      : [];
  });
  const [input, setInput] = useState("");
  const [tokensUsed, setTokensUsed] = useState(() => messages.reduce((s, m) => s + estimateTokens(m.content), 0));
  const [userMsgs, setUserMsgs] = useState(0);
  const [isStreaming, setIsStreaming] = useState(false);

  const chatRef = useRef(null);
  useEffect(() => {
    if (!chatRef.current) return;
    chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [messages, isStreaming]);

  const limitReached = userMsgs >= LIMIT_MSGS || tokensUsed >= LIMIT_TOKENS;

  function send() {
    const text = input.trim();
    if (!text || limitReached || isStreaming) return;

    const newMsgs = [...messages, { role: "user", content: text }];
    const addTokens = estimateTokens(text);

    setMessages(newMsgs);
    setInput("");
    setUserMsgs((n) => n + 1);
    setTokensUsed((x) => x + addTokens);

    // Fake bot reply after a short delay
    setIsStreaming(true);
    const reply = `Demo reply from ${bot?.name || "Rbotly"}: I received — "${text.slice(0, 120)}". In the full version, this bot will use your selected model and tools.`;
    const replyTokens = estimateTokens(reply);
    setTimeout(() => {
      setMessages((m) => [...m, { role: "assistant", content: reply }]);
      setTokensUsed((x) => x + replyTokens);
      setIsStreaming(false);
    }, 650);
  }

  function resetSession() {
    setMessages([{ role: "assistant", content: `Hi, I'm ${bot?.name || "Rbotly Bot"}. This is a read-only demo chat. Ask me anything!` }]);
    setUserMsgs(0);
    setTokensUsed(estimateTokens(`Hi, I'm ${bot?.name || "Rbotly Bot"}. This is a read-only demo chat. Ask me anything!`));
    setInput("");
  }

  if (!bot) {
    return (
      <div className="min-h-screen w-full bg-[#05060a] text-cyan-50">
        <div className="mx-auto max-w-5xl px-5 py-10">
          <a href="/market" className="inline-block rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">← {t("BACK")}</a>
          <div className="mt-6 rounded-2xl border border-cyan-300/30 bg-black/30 p-6 text-center text-cyan-100/85">{t("NOT_FOUND")}</div>
        </div>
      </div>
    );
  }

  const msgsLeft = Math.max(0, LIMIT_MSGS - userMsgs);
  const tokensLeft = Math.max(0, LIMIT_TOKENS - tokensUsed);

  return (
    <div className="min-h-screen w-full bg-[#05060a] bg-[radial-gradient(1200px_600px_at_10%_-10%,rgba(0,229,255,0.08),transparent_40%),radial-gradient(900px_500px_at_90%_0%,rgba(0,229,255,0.06),transparent_35%)] text-cyan-50">
      <div className="mx-auto max-w-5xl px-5 py-8">
        {/* Header */}
        <header className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <a href="/market" className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">← {t("BACK")}</a>
            <motion.h1 initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="text-[clamp(24px,3.4vw,36px)] font-extrabold tracking-wide text-cyan-100 drop-shadow-[0_0_22px_rgba(0,229,255,0.18)]">
              {t("PAGE_TITLE")}
            </motion.h1>
          </div>
          <select value={lang} onChange={(e) => setLang(e.target.value)} className="min-w-[140px] rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 outline-none ring-0 transition focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20">
            <option value="ar">العربية</option>
            <option value="en">English</option>
            <option value="fr">Français</option>
            <option value="el">Ελληνικά</option>
          </select>
        </header>

        {/* Bot Header */}
        <BotHeader t={t} bot={bot} />

        {/* Trial meters */}
        <div className="mb-4 grid grid-cols-1 gap-3 md:grid-cols-2">
          <div className="rounded-xl border border-cyan-300/30 bg-black/40 p-3">
            <div className="mb-1 flex items-center justify-between text-xs text-cyan-100/80">
              <span>{t("FREE_TRIAL")}</span>
              <span>
                {msgsLeft} {t("MESSAGES")} · {tokensLeft} {t("TOKENS")} {t("TRY_LEFT")}
              </span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-cyan-300/10">
              <div className="h-full bg-cyan-300/60" style={{ width: `${Math.min(100, (userMsgs / LIMIT_MSGS) * 100)}%` }} />
            </div>
          </div>
          <div className="rounded-xl border border-cyan-300/30 bg-black/40 p-3">
            <div className="mb-1 flex items-center justify-between text-xs text-cyan-100/80">
              <span>{t("TOKENS")}</span>
              <span>
                {tokensUsed} / {LIMIT_TOKENS}
              </span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-cyan-300/10">
              <div className="h-full bg-cyan-300/60" style={{ width: `${Math.min(100, (tokensUsed / LIMIT_TOKENS) * 100)}%` }} />
            </div>
          </div>
        </div>

        {/* Chat */}
        <div className="mb-3 h-[52vh] min-h-[360px] w-full overflow-y-auto rounded-2xl border border-cyan-300/30 bg-gradient-to-b from-cyan-400/10 to-cyan-400/5 p-4" ref={chatRef}>
          <div className="mx-auto flex max-w-3xl flex-col gap-2">
            {messages.map((m, i) => (
              <Message key={i} role={m.role}>{m.content}</Message>
            ))}
            {isStreaming && <Message role="assistant">▌</Message>}
            {limitReached && (
              <div className="mt-4 rounded-xl border border-cyan-300/30 bg-black/40 p-3 text-center text-cyan-100/85">
                {t("LIMIT_REACHED")}
              </div>
            )}
          </div>
        </div>

        {/* Input bar */}
        <div className="flex flex-wrap items-center gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") send();
            }}
            placeholder={t("INPUT_PLACEHOLDER")}
            disabled={limitReached || isStreaming}
            className="flex-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 disabled:opacity-60 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
          />
          <button onClick={send} disabled={limitReached || isStreaming} className="rounded-xl border border-cyan-300/30 bg-black/40 px-4 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10 disabled:opacity-50">
            {t("SEND")}
          </button>
          <button onClick={resetSession} className="rounded-xl border border-cyan-300/30 bg-black/40 px-4 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10">
            {t("RESET")}
          </button>
          <div className="grow" />
          <button onClick={() => (window.location.href = `/checkout/${bot.id}`)} className="rounded-xl border border-cyan-300/40 bg-cyan-500/10 px-4 py-2 text-sm font-semibold text-cyan-50 hover:bg-cyan-500/20">
            {t("BUY_NOW")}
          </button>
        </div>
      </div>
    </div>
  );
}
