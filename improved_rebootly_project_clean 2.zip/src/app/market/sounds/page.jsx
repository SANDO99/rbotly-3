import React, { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";

// ------------------------------------------------------------
// Rbotly — Marketplace / Sounds
// - Neon Blue on Dark
// - 4 Languages (AR, EN, FR, EL)
// - Filters: search, language, gender, price min/max, tags, sort
// - Mock data; actions: Preview (audio), Buy (checkout)
// ------------------------------------------------------------

const DICT = {
  ar: {
    PAGE_TITLE: "الأصوات",
    PAGE_SUB: "مكتبة أصوات جاهزة. استمع للمعاينة ثم اشترِ مباشرة.",
    BACK: "رجوع إلى السوق",
    FILTERS: "الفلاتر",
    LANGUAGE: "اللغة",
    GENDER: "الفئة الصوتية",
    GENDER_ALL: "الكل",
    GENDER_MALE: "رجل",
    GENDER_FEMALE: "امرأة",
    GENDER_CHILD: "طفل",
    SEARCH_PLACEHOLDER: "ابحث داخل الأصوات...",
    ALL: "الكل",
    MIN: "الأدنى",
    MAX: "الأعلى",
    PRICE: "السعر",
    TAGS: "الوسوم (افصل بفواصل ,)",
    SORT_BY: "الترتيب",
    SORT_DEFAULT: "الأحدث",
    SORT_PRICE_ASC: "السعر ↑",
    SORT_PRICE_DESC: "السعر ↓",
    SORT_DURATION_ASC: "المدة ↑",
    SORT_DURATION_DESC: "المدة ↓",
    RESET: "إعادة تعيين",
    TOKENS: "توكن",
    PREVIEW: "معاينة",
    STOP: "إيقاف",
    BUY: "شراء",
    DURATION: "المدة",
    NO_RESULTS: "لا توجد نتائج مطابقة.",
    ITEMS: "عنصر",
  },
  en: {
    PAGE_TITLE: "Sounds",
    PAGE_SUB: "A library of ready voice packs. Preview and buy instantly.",
    BACK: "Back to Market",
    FILTERS: "Filters",
    LANGUAGE: "Language",
    GENDER: "Voice Type",
    GENDER_ALL: "All",
    GENDER_MALE: "Male",
    GENDER_FEMALE: "Female",
    GENDER_CHILD: "Child",
    SEARCH_PLACEHOLDER: "Search sounds...",
    ALL: "All",
    MIN: "Min",
    MAX: "Max",
    PRICE: "Price",
    TAGS: "Tags (comma-separated)",
    SORT_BY: "Sort",
    SORT_DEFAULT: "Newest",
    SORT_PRICE_ASC: "Price ↑",
    SORT_PRICE_DESC: "Price ↓",
    SORT_DURATION_ASC: "Duration ↑",
    SORT_DURATION_DESC: "Duration ↓",
    RESET: "Reset",
    TOKENS: "Token",
    PREVIEW: "Preview",
    STOP: "Stop",
    BUY: "Buy",
    DURATION: "Duration",
    NO_RESULTS: "No matching results.",
    ITEMS: "items",
  },
  fr: {
    PAGE_TITLE: "Voix",
    PAGE_SUB: "Bibliothèque de voix prêtes. Écoutez un extrait et achetez.",
    BACK: "Retour au Marché",
    FILTERS: "Filtres",
    LANGUAGE: "Langue",
    GENDER: "Type de voix",
    GENDER_ALL: "Tous",
    GENDER_MALE: "Homme",
    GENDER_FEMALE: "Femme",
    GENDER_CHILD: "Enfant",
    SEARCH_PLACEHOLDER: "Rechercher des voix...",
    ALL: "Tous",
    MIN: "Min",
    MAX: "Max",
    PRICE: "Prix",
    TAGS: "Mots-clés (séparés par des virgules)",
    SORT_BY: "Tri",
    SORT_DEFAULT: "Plus récent",
    SORT_PRICE_ASC: "Prix ↑",
    SORT_PRICE_DESC: "Prix ↓",
    SORT_DURATION_ASC: "Durée ↑",
    SORT_DURATION_DESC: "Durée ↓",
    RESET: "Réinitialiser",
    TOKENS: "Jeton",
    PREVIEW: "Aperçu",
    STOP: "Arrêter",
    BUY: "Acheter",
    DURATION: "Durée",
    NO_RESULTS: "Aucun résultat correspondant.",
    ITEMS: "articles",
  },
  el: {
    PAGE_TITLE: "Ήχοι",
    PAGE_SUB: "Βιβλιοθήκη έτοιμων φωνών. Άκου δείγμα και αγόρασε.",
    BACK: "Πίσω στην Αγορά",
    FILTERS: "Φίλτρα",
    LANGUAGE: "Γλώσσα",
    GENDER: "Τύπος φωνής",
    GENDER_ALL: "Όλα",
    GENDER_MALE: "Άνδρας",
    GENDER_FEMALE: "Γυναίκα",
    GENDER_CHILD: "Παιδί",
    SEARCH_PLACEHOLDER: "Αναζήτηση ήχων...",
    ALL: "Όλα",
    MIN: "Ελάχιστο",
    MAX: "Μέγιστο",
    PRICE: "Τιμή",
    TAGS: "Ετικέτες (χωρίζονται με κόμμα)",
    SORT_BY: "Ταξινόμηση",
    SORT_DEFAULT: "Νεότερα",
    SORT_PRICE_ASC: "Τιμή ↑",
    SORT_PRICE_DESC: "Τιμή ↓",
    SORT_DURATION_ASC: "Διάρκεια ↑",
    SORT_DURATION_DESC: "Διάρκεια ↓",
    RESET: "Επαναφορά",
    TOKENS: "Token",
    PREVIEW: "Προεπισκόπηση",
    STOP: "Διακοπή",
    BUY: "Αγορά",
    DURATION: "Διάρκεια",
    NO_RESULTS: "Δεν βρέθηκαν αποτελέσματα.",
    ITEMS: "αντικείμενα",
  },
};

const SOUNDS = [
  {
    id: "voice-orion",
    name: "Orion Male",
    description: "صوت ذكوري واضح للرواية.",
    image: "https://placehold.co/640x360/png",
    priceTokens: 150,
    language: "en",
    gender: "male",
    durationSec: 38,
    tags: ["male", "narration", "tts"],
    previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
    createdAt: 1722250000000,
  },
  {
    id: "voice-lyra",
    name: "Lyra Female",
    description: "صوت أنثوي دافئ لفيديوهات قصيرة.",
    image: "https://placehold.co/640x360/png",
    priceTokens: 160,
    language: "el",
    gender: "female",
    durationSec: 25,
    tags: ["female", "shorts"],
    previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
    createdAt: 1722260000000,
  },
  {
    id: "voice-samir",
    name: "Samir Arabic",
    description: "صوت عربي محايد للبرامج الحوارية.",
    image: "https://placehold.co/640x360/png",
    priceTokens: 170,
    language: "ar",
    gender: "male",
    durationSec: 42,
    tags: ["male", "neutral"],
    previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
    createdAt: 1722270000000,
  },
  {
    id: "voice-amelie",
    name: "Amélie FR",
    description: "Voix féminine douce pour tutoriels.",
    image: "https://placehold.co/640x360/png",
    priceTokens: 165,
    language: "fr",
    gender: "female",
    durationSec: 30,
    tags: ["female", "tutorial"],
    previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
    createdAt: 1722280000000,
  },
  {
    id: "voice-luna",
    name: "Luna Child",
    description: "Child voice for animations.",
    image: "https://placehold.co/640x360/png",
    priceTokens: 155,
    language: "en",
    gender: "child",
    durationSec: 22,
    tags: ["child", "cartoon"],
    previewUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3",
    createdAt: 1722290000000,
  },
];

function useI18n(lang) {
  return (k) => (DICT[lang]?.[k] ?? DICT.en[k] ?? k);
}

function useRTL(lang) {
  useEffect(() => {
    const rtl = lang === "ar";
    document.documentElement.dir = rtl ? "rtl" : "ltr";
    document.documentElement.lang = lang;
  }, [lang]);
}

function Chip({ children }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-cyan-300/30 bg-cyan-300/10 px-2.5 py-1 text-xs text-cyan-100">
      {children}
    </span>
  );
}

function formatDuration(sec) {
  const s = Math.max(0, Math.floor(sec || 0));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${String(r).padStart(2, "0")}`;
}

function Card({ t, item, onPreview, onBuy, playing }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-cyan-300/25 bg-gradient-to-b from-cyan-400/10 to-cyan-400/5 shadow-[0_0_24px_rgba(0,229,255,0.12)]"
    >
      <div className="aspect-video w-full overflow-hidden bg-black/60">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={item.image}
          alt={item.name}
          className="h-full w-full object-cover opacity-90 transition-opacity duration-200 group-hover:opacity-100"
        />
      </div>
      <div className="p-4">
        <div className="font-semibold tracking-wide text-cyan-100">{item.name}</div>
        <div className="mt-1 line-clamp-2 text-sm text-cyan-100/80">{item.description}</div>
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <div className="font-mono text-cyan-200">{item.priceTokens} {t("TOKENS")}</div>
            <Chip>{t("DURATION")}: {formatDuration(item.durationSec)}</Chip>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => onPreview?.(item)}
              className={`rounded-md border border-cyan-300/40 px-3 py-1.5 text-sm text-cyan-50 hover:bg-cyan-500/10 ${
                playing ? "animate-pulse" : ""
              }`}
            >
              {playing ? t("STOP") : t("PREVIEW")}
            </button>
            <button
              onClick={() => onBuy?.(item)}
              className="rounded-md border border-cyan-300/40 px-3 py-1.5 text-sm text-cyan-50 hover:bg-cyan-500/10"
            >
              {t("BUY")}
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export default function MarketSoundsPage() {
  const [lang, setLang] = useState("ar");
  const t = useI18n(lang);
  useRTL(lang);

  const [q, setQ] = useState("");
  const [langFilter, setLangFilter] = useState("all");
  const [gender, setGender] = useState("all");
  const [minP, setMinP] = useState("");
  const [maxP, setMaxP] = useState("");
  const [tags, setTags] = useState("");
  const [sort, setSort] = useState("default");
  const [playingId, setPlayingId] = useState(null);

  const audioRef = useRef(null);
  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
      audioRef.current.addEventListener("ended", () => setPlayingId(null));
    }
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, []);

  const match = (item) => {
    const text = `${item.name} ${item.description}`.toLowerCase();
    if (q && !text.includes(q.toLowerCase())) return false;
    if (langFilter !== "all" && item.language !== langFilter) return false;
    if (gender !== "all" && item.gender !== gender) return false;
    const p = item.priceTokens ?? 0;
    if (minP !== "" && p < Number(minP)) return false;
    if (maxP !== "" && p > Number(maxP)) return false;
    const tagList = tags
      .split(",")
      .map((s) => s.trim().toLowerCase())
      .filter(Boolean);
    if (tagList.length) {
      const itemTags = (item.tags || []).map((s) => s.toLowerCase());
      const ok = tagList.every((tg) => itemTags.includes(tg));
      if (!ok) return false;
    }
    return true;
  };

  const filtered = useMemo(() => {
    let list = SOUNDS.filter(match);
    if (sort === "price-asc") list = [...list].sort((a, b) => (a.priceTokens || 0) - (b.priceTokens || 0));
    else if (sort === "price-desc") list = [...list].sort((a, b) => (b.priceTokens || 0) - (a.priceTokens || 0));
    else if (sort === "dur-asc") list = [...list].sort((a, b) => (a.durationSec || 0) - (b.durationSec || 0));
    else if (sort === "dur-desc") list = [...list].sort((a, b) => (b.durationSec || 0) - (a.durationSec || 0));
    else list = [...list].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)); // default newest
    return list;
  }, [q, langFilter, gender, minP, maxP, tags, sort, lang]);

  const onPreview = (item) => {
    if (!audioRef.current) return;
    if (playingId === item.id) {
      audioRef.current.pause();
      setPlayingId(null);
      return;
    }
    try {
      audioRef.current.src = item.previewUrl || "";
      audioRef.current.currentTime = 0;
      audioRef.current.play();
      setPlayingId(item.id);
    } catch (e) {
      console.warn("Preview failed", e);
      setPlayingId(null);
      alert("Preview failed");
    }
  };

  const onBuy = (item) => {
    window.location.href = `/checkout/${item.id}`;
  };

  const resetFilters = () => {
    setQ("");
    setLangFilter("all");
    setGender("all");
    setMinP("");
    setMaxP("");
    setTags("");
    setSort("default");
  };

  return (
    <div className="min-h-screen w-full bg-[#05060a] bg-[radial-gradient(1200px_600px_at_10%_-10%,rgba(0,229,255,0.08),transparent_40%),radial-gradient(900px_500px_at_90%_0%,rgba(0,229,255,0.06),transparent_35%)] text-cyan-50">
      <div className="mx-auto max-w-6xl px-5 py-8">
        {/* Header */}
        <header className="mb-6">
          <div className="mb-2 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <a
                href="/market"
                className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10"
              >
                ← {t("BACK")}
              </a>
              <motion.h1
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="text-[clamp(24px,3.4vw,36px)] font-extrabold tracking-wide text-cyan-100 drop-shadow-[0_0_22px_rgba(0,229,255,0.18)]"
              >
                {t("PAGE_TITLE")}
              </motion.h1>
            </div>
            <select
              value={lang}
              onChange={(e) => setLang(e.target.value)}
              className="min-w-[140px] rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 outline-none ring-0 transition focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            >
              <option value="ar">العربية</option>
              <option value="en">English</option>
              <option value="fr">Français</option>
              <option value="el">Ελληνικά</option>
            </select>
          </div>
          <p className="text-cyan-100/80">{t("PAGE_SUB")}</p>
        </header>

        {/* Filters */}
        <div className="mb-6 rounded-2xl border border-cyan-300/30 bg-gradient-to-b from-cyan-400/10 to-cyan-400/5 p-4 shadow-[0_0_30px_rgba(0,229,255,0.12)]">
          <div className="mb-3 flex items-center justify-between">
            <strong className="text-cyan-100">{t("FILTERS")}</strong>
            <div className="flex flex-wrap items-center gap-2">
              <Chip>Sounds Only</Chip>
              <Chip>Neon UI</Chip>
              <Chip>{filtered.length} {t("ITEMS")}</Chip>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-7">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("SEARCH_PLACEHOLDER")}
              className="col-span-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20 sm:col-span-2 lg:col-span-7"
            />
            <select
              value={langFilter}
              onChange={(e) => setLangFilter(e.target.value)}
              className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            >
              <option value="all">{t("ALL")}</option>
              <option value="ar">العربية</option>
              <option value="en">English</option>
              <option value="fr">Français</option>
              <option value="el">Ελληνικά</option>
            </select>
            <select
              value={gender}
              onChange={(e) => setGender(e.target.value)}
              className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            >
              <option value="all">{t("GENDER_ALL")}</option>
              <option value="male">{t("GENDER_MALE")}</option>
              <option value="female">{t("GENDER_FEMALE")}</option>
              <option value="child">{t("GENDER_CHILD")}</option>
            </select>
            <input
              type="number"
              inputMode="numeric"
              value={minP}
              onChange={(e) => setMinP(e.target.value)}
              placeholder={t("MIN")}
              className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            />
            <input
              type="number"
              inputMode="numeric"
              value={maxP}
              onChange={(e) => setMaxP(e.target.value)}
              placeholder={t("MAX")}
              className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            />
            <input
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder={t("TAGS")}
              className="col-span-1 rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20 sm:col-span-2 lg:col-span-3"
            />
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 outline-none ring-0 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-300/20"
            >
              <option value="default">{t("SORT_DEFAULT")}</option>
              <option value="price-asc">{t("SORT_PRICE_ASC")}</option>
              <option value="price-desc">{t("SORT_PRICE_DESC")}</option>
              <option value="dur-asc">{t("SORT_DURATION_ASC")}</option>
              <option value="dur-desc">{t("SORT_DURATION_DESC")}</option>
            </select>
            <button
              onClick={resetFilters}
              className="rounded-xl border border-cyan-300/30 bg-black/40 px-3 py-2 text-sm text-cyan-100 hover:bg-cyan-500/10"
            >
              {t("RESET")}
            </button>
          </div>
        </div>

        {/* Cards */}
        {filtered.length === 0 ? (
          <div className="rounded-2xl border border-cyan-300/25 bg-black/30 p-6 text-center text-cyan-100/80">
            {t("NO_RESULTS")}
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((item) => (
              <Card
                key={item.id}
                t={t}
                item={item}
                onPreview={onPreview}
                onBuy={onBuy}
                playing={playingId === item.id}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
