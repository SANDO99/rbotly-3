# Rbotly Bot Studio — Comprehensive Implementation Plan (Product & Technical Spec)

> This document defines the **Studio** where a user manages a bot **after purchase**: knowledge ingestion, instructions, few‑shot examples, in‑studio testing (text/mic), managed deployment, and logs. It is written to hand off to an external team to build the product **from scratch** without other references.

---

## 1) Scope
- A web application to manage user‑owned AI bots after they are bought from the Marketplace.
- **Single monthly subscription plan** gates all Studio features (no free tier inside the Studio; no multiple tiers).
- **No admin UI** is ever exposed to end users.

**Out of scope:** public marketplace pages, marketing site, or any specific model provider implementation (connected via API only).

---

## 2) Roles
- **User (bot owner):** activates the monthly plan, uploads data, configures instructions, adds examples, tests, starts/stops managed runtime, downloads generated artifacts/exports.
- **Admin (internal only):** reviews orders/payments, sees GPU/Jobs status. **No** navigation path from user UI.

---

## 3) Architecture
- **Frontend:** React + TailwindCSS + React Router + i18next (AR/EN/FR/EL) + local state (Zustand/Recoil/Context) + File API + MediaRecorder.
- **Backend:** Node.js (Express or Next.js API routes). Modules: Auth, Billing, Storage, Vector Index, Chat Runtime, Jobs, Logging.
- **Storage:**
  - User files (knowledge & chat attachments): S3‑compatible (AWS S3/MinIO) using **signed URLs**.
  - Vector indexes: Qdrant / Weaviate / PGVector.
  - Logs & events: PostgreSQL / ClickHouse.
- **AI Providers (swappable):**
  - Embeddings: open‑source (e5, bge) or paid provider.
  - Chat inference: internal/external via REST.
  - STT/TTS: Whisper/Deepgram/Google via a unified API layer.
- **CI/CD:** Dockerized builds; environments for dev/stage/prod.

---

## 4) Non‑Functional Requirements (NFR)
- Four languages with RTL for Arabic.
- File upload limits: single file up to 50MB by default (configurable). Allowed types: pdf, txt, md, docx, csv, json, webm, wav, mp3.
- Security: JWT auth; resource scoping by botId/userId; optional antivirus scan (ClamAV).
- Telemetry: UI events (clicks, job transitions) + API metrics.
- Scalability: background workers for jobs; queue (Redis/BullMQ/etc.).

---

## 5) UX — Tabbed Studio
Route: `/dashboard/bots/:botId/train`

### 5.1 Persistent Header
- Bot avatar & name.
- Plan badge: Active / Inactive.
- Back to **My Bots** button.

### 5.2 Tabs
1) **Overview**
   - Short guidance copy.
   - **Export config (JSON)** button → `{ bot, config, datasets }`.
   - Plan activation banner appears only when plan is **Inactive**.

2) **Data** (knowledge ingestion)
   - Multiple file upload (drag/drop + select).
   - Table: filename, size, language (optional), status: `uploaded | indexing | indexed | failed`.
   - **Build index** triggers indexing jobs for all `uploaded` files.
   - **Download datasets manifest (JSON)** documents every file & status.

3) **Instructions** (system prompt)
   - Textarea for the bot’s system prompt.
   - Default language (ar/en/fr/el).
   - Feature toggles: RAG / Web.
   - **Save** persists configuration.

4) **Examples** (few‑shot)
   - Q/A inputs with **Add**; list with **Remove**.

5) **Test Chat** (in‑studio testing)
   - Text input + **Send**.
   - **Attach** files to a message (chat attachments; **not** added to Data).
   - **Start mic / Stop** to record audio and attach it.
   - Message list (User/Bot) with **Download** links for attachments and bot‑generated files.
   - **Export chat (.json)** downloads the full conversation.

6) **Deploy** (managed runtime)
   - Readiness state.
   - **Start / Stop** managed service (GPU/CPU).
   - After **Start** show `endpoint` & `token` (Copy to clipboard + **Regenerate token**).

7) **Logs**
   - Job list (type, status, progress, timestamps).
   - Filters by type (indexing/chat/deploy) and date.

> Tabs (2→7) are disabled when plan is **Inactive** and unlocked after activation.

---

## 6) Core User Flows

### A) Studio entry after purchase
1. User completes checkout.
2. Post‑purchase choice: **Run on our platform (monthly)** or **Download to run externally**.
3. If "Run on our platform" → route to `/dashboard/bots/:botId/train`.

### B) Monthly plan activation
1. In **Overview** (or a sticky banner) show monthly price and **Activate plan**.
2. Clicking opens payment provider (Stripe/PayPal) or in‑app sheet.
3. On success, payment **webhook** flips subscription status to Active on the server → Studio unlocks.

### C) Data upload & indexing
1. In **Data**, user uploads files.
2. Server creates `indexing` jobs → extract text → chunk → embeddings → store in vector DB.
3. UI reflects progress and final status.

### D) Test chat
1. User sends text or records voice.
2. Chat attachments are stored as `ChatMessageAttachment` (separate from Data).
3. Server calls inference provider with bot config + optional RAG + attachments when relevant.
4. Returns bot reply + optional file artifacts (signed URLs).

### E) Managed deploy
1. **Start** spins a (containerized) runtime with needed resources (GPU/CPU) and env.
2. Returns `endpoint` + `token` for external consumption.
3. **Stop** tears it down and frees resources.

---

## 7) Data Models

### 7.1 Bot
```ts
Bot {
  id: string;
  ownerId: string;
  name: string;
  imageUrl?: string;
  type: 'bots' | 'bots-nft';
  defaultLanguage: 'ar'|'en'|'fr'|'el';
  createdAt: number;
}
```

### 7.2 PlanSubscription (monthly)
```ts
PlanSubscription {
  id: string;
  botId: string;
  ownerId: string;
  status: 'inactive'|'active'|'expired';
  startedAt?: number;
  renewedAt?: number;
  expiresAt?: number;
  priceCents: number;
  currency: string;
  provider: 'stripe'|'paypal'|'manual';
  providerSubId?: string;
}
```

### 7.3 Dataset & IndexJob
```ts
Dataset {
  id: string; botId: string; ownerId: string;
  filename: string; mime: string; size: number; storageKey: string;
  lang?: string;
  status: 'uploaded'|'indexing'|'indexed'|'failed';
  createdAt: number;
}

IndexJob {
  id: string; botId: string; datasetId: string;
  status: 'queued'|'running'|'done'|'failed';
  progress: number; error?: string;
  startedAt?: number; finishedAt?: number;
}
```

### 7.4 BotConfig
```ts
BotConfig {
  botId: string;
  prompt: string;
  language: 'ar'|'en'|'fr'|'el';
  tools: { rag: boolean; web: boolean };
  examples: { id: string; q: string; a: string }[];
  updatedAt: number;
}
```

### 7.5 ChatMessage & Attachments
```ts
ChatMessage {
  id: string; botId: string; ownerId: string;
  role: 'user'|'bot'|'system';
  text?: string;
  attachments?: Attachment[];
  files?: FileArtifact[];
  createdAt: number;
}

Attachment { name: string; size: number; storageKey: string; mime: string }
FileArtifact { name: string; size: number; storageKey: string; mime: string }
```

### 7.6 DeployRuntime
```ts
DeployRuntime {
  id: string; botId: string; ownerId: string;
  status: 'stopped'|'starting'|'running'|'stopping'|'error';
  endpoint?: string; tokenHash?: string;
  lastStartAt?: number; lastError?: string;
}
```

---

## 8) API Surface (sample)
All under `/api/studio`, JWT protected. Responses are `application/json`.

### Auth
- `POST /auth/login` (outside the Studio)

### Subscription
- `POST /billing/subscribe` { botId } → 302 to provider
- `POST /billing/webhook` (server‑to‑server) to activate/suspend subscription
- `GET /subscription/:botId` → { status, expiresAt }

### Data / Indexing
- `POST /upload-url` { botId, filename, mime } → { url, storageKey }
- Client uploads to S3 directly.
- `POST /datasets/commit` { botId, items:[{ filename, storageKey, size, lang? }] }
- `POST /index/build` { botId } → enqueue jobs for `uploaded` items
- `GET /datasets/:botId` → list datasets with statuses
- `GET /jobs/:botId` → list jobs

### Config
- `GET /config/:botId`
- `PUT /config/:botId` { prompt, language, tools, examples }

### Chat (test)
- `POST /chat` { botId, message:{ text?, attachments? }, trace? } → { reply:{ text, files?[] } }
- For attachments, call `/upload-url` then pass `storageKey` in `attachments`.

### Deploy
- `POST /deploy/start` { botId } → { endpoint, token }
- `POST /deploy/stop` { botId }
- `GET /deploy/:botId` → runtime state

### Exports
- `GET /export/config/:botId` → runtime‑ready JSON
- `GET /export/chat/:botId?from=..&to=..` → chat JSON

**Error shape:** `{ error: { code, message, details? } }` with proper HTTP status codes.

---

## 9) Marketplace / Checkout Integration
- On payment success, persist an **Order** tied to the user and botId.
- Post‑purchase screen offers:
  1) **Run on our platform (monthly)** → opens Studio.
  2) **Download to run externally** → goes to Downloads page.
- If the item is **NFT**, minting happens in the background (mock/API) and is visible to admin only.

---

## 10) i18n & RTL
- Languages: ar, en, fr, el. Language stored in URL or LocalStorage.
- At `<html>` level: set `dir` based on language (rtl for `ar`).
- All strings live in separate message files.

---

## 11) UI Checklist

### Global
- [ ] Back to **My Bots** button.
- [ ] Plan status badge + activation banner when Inactive.

### Overview
- [ ] **Export config (JSON)**.

### Data
- [ ] Multi‑file upload (drag/drop + select).
- [ ] File list with statuses.
- [ ] **Build index** triggers jobs.
- [ ] **Download datasets manifest (JSON)**.

### Instructions
- [ ] System prompt textarea.
- [ ] Default language selector (ar/en/fr/el).
- [ ] Toggles: RAG / Web.
- [ ] **Save**.

### Examples
- [ ] Q/A inputs + **Add**.
- [ ] List with **Remove**.

### Test Chat
- [ ] Text input + **Send**.
- [ ] **Attach** files (allowed types only).
- [ ] **Start mic / Stop** adds `webm` as attachment.
- [ ] Message list with **Download** for attachments and bot artifacts.
- [ ] **Export chat (.json)**.

### Deploy
- [ ] **Start / Stop** runtime.
- [ ] Show `endpoint`, `token`, **Regenerate token**.

### Logs
- [ ] Job list with filters.

---

## 12) Security Considerations
- JWT per request; scope every resource by `ownerId`/`botId`.
- Short‑lived signed URLs for uploads/downloads.
- Enforce file size/type limits.
- Rate‑limit chat and upload endpoints.
- Verify payment webhooks.

---

## 13) Environment Variables
```env
# Frontend
VITE_DEFAULT_LANG=ar
VITE_SUPPORTED_LANGS=ar,en,fr,el
VITE_STUDIO_MONTHLY_PRICE=__TO_BE_DEFINED__

# Backend
APP_BASE_URL=https://api.example.com
JWT_SECRET=__SECRET__
S3_ENDPOINT=...
S3_BUCKET=...
VECTOR_DB_URL=...
PAYMENT_PROVIDER=stripe
STRIPE_SECRET=...
STT_PROVIDER=whisper
CHAT_PROVIDER=internal
```

---

## 14) Acceptance Criteria
- All tabs except Overview are disabled without an active subscription.
- Upload works up to configured limits; progress & final states are visible.
- **Build index** transitions files to `indexed` or `failed` with error message.
- Test Chat supports: text, attachments, microphone, and file downloads.
- Exports (config/manifest/chat) download valid files.
- Deploy returns endpoint + token and stops cleanly.
- All strings are localized in four languages; Arabic is RTL.

---

## 15) Milestones
1) Skeleton + i18n + routing + auth (user role only).
2) Subscription banner + payment integration (redirect + webhook).
3) Data upload + indexing jobs + vector DB.
4) Instructions + examples + save API.
5) Test chat (text/attachments/mic) + file artifacts.
6) Managed deployment + endpoint/token.
7) Logs + telemetry + **separate** admin app.

---

## 16) Implementation Notes
- Use a shared component library for the **blue‑neon** theme (buttons/cards).
- All downloads must go through signed URLs.
- Do **not** display marketing claims about “bot ownership” inside Studio; keep it purely functional.
- Prices are **not hard‑coded**; read from configuration/env.

> With this spec, an external team can build the **Studio** end‑to‑end with clear UI flows, data models, and API boundaries—without relying on prior code.

