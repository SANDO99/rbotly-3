import { NextResponse } from 'next/server';

// This endpoint is a placeholder for a WebSocket signaling service used by
// the calls/translation UI. Next.js does not handle WebSockets in the same
// manner as HTTP requests; you would typically implement a custom server or
// run socket.io on a separate port. Until a real signaling server is set up,
// this endpoint returns a 501 Not Implemented response.

export async function GET() {
  return new NextResponse('Not Implemented', { status: 501 });
}

export async function POST() {
  return new NextResponse('Not Implemented', { status: 501 });
}