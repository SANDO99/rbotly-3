// AdminAddonsReviewPage.js - مراجعة الإضافات مع ترجمة رباعية (ملف مستقل كامل)

// --- ملفات الترجمة لكل لغة ---
export const admin_addons_review_en = {
  addonsReviewTitle: "Add-ons Review",
  name: "Name",
  type: "Type",
  audio: "Audio Filter",
  data: "Data Source",
  voice: "Voice Service",
  owner: "Owner",
  status: "Status",
  approved: "Approved",
  pending: "Pending",
  rejected: "Rejected",
  actions: "Actions",
  approve: "Approve",
  reject: "Reject",
};
export const admin_addons_review_ar = {
  addonsReviewTitle: "مراجعة الإضافات",
  name: "الاسم",
  type: "النوع",
  audio: "فلتر صوتي",
  data: "مصدر بيانات",
  voice: "خدمة صوتية",
  owner: "المالك",
  status: "الحالة",
  approved: "معتمد",
  pending: "بانتظار المراجعة",
  rejected: "مرفوض",
  actions: "إجراءات",
  approve: "اعتماد",
  reject: "رفض",
};
export const admin_addons_review_fr = {
  addonsReviewTitle: "Revue des Add-ons",
  name: "Nom",
  type: "Type",
  audio: "Filtre audio",
  data: "Source de données",
  voice: "Service vocal",
  owner: "Propriétaire",
  status: "Statut",
  approved: "Approuvé",
  pending: "En attente",
  rejected: "Rejeté",
  actions: "Actions",
  approve: "Approuver",
  reject: "Rejeter",
};
export const admin_addons_review_el = {
  addonsReviewTitle: "Αξιολόγηση πρόσθετων",
  name: "Όνομα",
  type: "Τύπος",
  audio: "Φίλτρο ήχου",
  data: "Πηγή δεδομένων",
  voice: "Υπηρεσία φωνής",
  owner: "Ιδιοκτήτης",
  status: "Κατάσταση",
  approved: "Εγκρίθηκε",
  pending: "Σε αναμονή",
  rejected: "Απορρίφθηκε",
  actions: "Ενέργειες",
  approve: "Έγκριση",
  reject: "Απόρριψη",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: admin_addons_review_en,
  ar: admin_addons_review_ar,
  fr: admin_addons_review_fr,
  el: admin_addons_review_el,
};

// بيانات وهمية للإضافات
const mockAddons = [
  { id: 1, name: "Smart Audio Filter", owner: "ahmed@example.com", type: "audio", status: "pending" },
  { id: 2, name: "Crypto News Source", owner: "sara@example.com", type: "data", status: "approved" },
  { id: 3, name: "French TTS", owner: "lucas@example.com", type: "voice", status: "rejected" },
];

export default function AdminAddonsReviewPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [addons, setAddons] = useState(mockAddons);

  // أماكن الربط مع API لاعتماد أو رفض الإضافة مستقبلاً
  const handleApprove = (id) => {
    setAddons(addons.map(a => a.id === id ? { ...a, status: "approved" } : a));
  };
  const handleReject = (id) => {
    setAddons(addons.map(a => a.id === id ? { ...a, status: "rejected" } : a));
  };

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("addonsReviewTitle")}</h1>
      <table className="w-full table-auto text-left border">
        <thead>
          <tr className="bg-zinc-900">
            <th className="p-2 border">#</th>
            <th className="p-2 border">{t("name")}</th>
            <th className="p-2 border">{t("type")}</th>
            <th className="p-2 border">{t("owner")}</th>
            <th className="p-2 border">{t("status")}</th>
            <th className="p-2 border">{t("actions")}</th>
          </tr>
        </thead>
        <tbody>
          {addons.map((a, i) => (
            <tr key={a.id} className="border-t">
              <td className="p-2 border">{i + 1}</td>
              <td className="p-2 border">{a.name}</td>
              <td className="p-2 border">{t(a.type)}</td>
              <td className="p-2 border">{a.owner}</td>
              <td className="p-2 border">
                <span className={
                  a.status === "approved" ? "text-green-400" :
                  a.status === "pending" ? "text-yellow-400" : "text-red-400"
                }>
                  {t(a.status)}
                </span>
              </td>
              <td className="p-2 border flex gap-2">
                {a.status !== "approved" && (
                  <button onClick={() => handleApprove(a.id)} className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded">
                    {t("approve")}
                  </button>
                )}
                {a.status !== "rejected" && (
                  <button onClick={() => handleReject(a.id)} className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded">
                    {t("reject")}
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}
