// UserSettingsPage.js - صفحة إعدادات المستخدم مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const user_settings_page_en = {
  settingsTitle: "User Settings",
  language: "Language",
  notification: "Notifications",
  emailNotifications: "Email Notifications",
  save: "Save Settings",
};
export const user_settings_page_ar = {
  settingsTitle: "إعدادات المستخدم",
  language: "اللغة",
  notification: "الإشعارات",
  emailNotifications: "إشعارات البريد الإلكتروني",
  save: "حفظ الإعدادات",
};
export const user_settings_page_fr = {
  settingsTitle: "Paramètres utilisateur",
  language: "Langue",
  notification: "Notifications",
  emailNotifications: "Notifications par e-mail",
  save: "Enregistrer les paramètres",
};
export const user_settings_page_el = {
  settingsTitle: "Ρυθμίσεις χρήστη",
  language: "Γλώσσα",
  notification: "Ειδοποιήσεις",
  emailNotifications: "Ειδοποιήσεις email",
  save: "Αποθήκευση ρυθμίσεων",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: user_settings_page_en,
  ar: user_settings_page_ar,
  fr: user_settings_page_fr,
  el: user_settings_page_el,
};

const initialSettings = {
  language: "en",
  emailNotifications: true,
};

export default function UserSettingsPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [settings, setSettings] = useState(initialSettings);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setSettings({ ...settings, [name]: type === "checkbox" ? checked : value });
  };

  const handleSave = () => {
    // TODO: ربط مع API لحفظ الإعدادات
    alert(t("save"));
  };

  return (
    <main className="min-h-screen bg-black text-white p-6 max-w-lg mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("settingsTitle")}</h1>
      <div className="bg-zinc-900 rounded-2xl shadow-lg p-8">
        <div className="mb-6">
          <label className="block font-semibold mb-2">{t("language")}</label>
          <select
            name="language"
            value={settings.language}
            onChange={handleChange}
            className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none"
          >
            <option value="en">English</option>
            <option value="ar">العربية</option>
            <option value="fr">Français</option>
            <option value="el">Ελληνικά</option>
          </select>
        </div>
        <div className="mb-6">
          <label className="block font-semibold mb-2">{t("notification")}</label>
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="emailNotifications"
              name="emailNotifications"
              checked={settings.emailNotifications}
              onChange={handleChange}
              className="accent-[var(--neon)] w-5 h-5"
            />
            <label htmlFor="emailNotifications">{t("emailNotifications")}</label>
          </div>
        </div>
        <button
          onClick={handleSave}
          className="bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-xl mt-4 w-full"
        >
          {t("save")}
        </button>
      </div>
    </main>
  );
}
