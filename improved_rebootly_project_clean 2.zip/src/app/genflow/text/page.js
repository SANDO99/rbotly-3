import { useState } from 'react';
import { useTranslation } from 'next-i18next';
import { serverSideTranslations } from 'next-i18next/serverSideTranslations';

export default function TextToTextPage() {
  const { t } = useTranslation('common');
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [action, setAction] = useState('paraphrase');

  const handleProcessText = async () => {
    setIsLoading(true);
    setOutputText('');

    try {
      // ❌ API خارجي لاحقًا
      const mockOutput = `Processed (${action}):\n` + inputText;
      setTimeout(() => {
        setOutputText(mockOutput);
        setIsLoading(false);
      }, 1500);
    } catch (err) {
      console.error(err);
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-6 text-[var(--neon)]">
        {t('TextToText.title')}
      </h1>

      <div className="max-w-2xl space-y-6">
        <textarea
          className="w-full p-4 rounded-xl bg-zinc-900 text-white"
          rows={4}
          placeholder={t('TextToText.placeholder')}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
        />

        <div>
          <label className="block mb-2 text-white/70">{t('TextToText.selectAction')}</label>
          <select
            className="w-full p-3 rounded-xl bg-zinc-900 text-white"
            value={action}
            onChange={(e) => setAction(e.target.value)}
          >
            <option value="paraphrase">{t('TextToText.actions.paraphrase')}</option>
            <option value="summarize">{t('TextToText.actions.summarize')}</option>
            <option value="expand">{t('TextToText.actions.expand')}</option>
          </select>
        </div>

        <button
          className="bg-[var(--neon)] text-black font-bold px-6 py-3 rounded-xl hover:opacity-80"
          onClick={handleProcessText}
          disabled={isLoading || !inputText}
        >
          {isLoading ? t('TextToText.loading') : t('TextToText.process')}
        </button>

        {outputText && (
          <div className="mt-6 bg-zinc-800 p-4 rounded-xl">
            <h2 className="text-xl mb-4">{t('TextToText.result')}</h2>
            <p className="whitespace-pre-line text-white/90">{outputText}</p>
          </div>
        )}
      </div>
    </main>
  );
}

export async function getStaticProps({ locale }) {
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common'])),
    },
  };
}
