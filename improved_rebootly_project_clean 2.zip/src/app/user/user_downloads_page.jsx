// UserDownloadsPage.js - صفحة ملفات المستخدم/التنزيلات مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const user_downloads_page_en = {
  downloadsTitle: "My Downloads",
  noDownloads: "No downloads available.",
  product: "Product",
  type: "Type",
  date: "Date",
  download: "Download",
  voice: "Voice",
  bot: "Bot",
  nft: "NFT",
};
export const user_downloads_page_ar = {
  downloadsTitle: "ملفاتي/التنزيلات",
  noDownloads: "لا توجد ملفات متاحة للتحميل.",
  product: "المنتج",
  type: "النوع",
  date: "التاريخ",
  download: "تحميل",
  voice: "صوت",
  bot: "بوت",
  nft: "رمز NFT",
};
export const user_downloads_page_fr = {
  downloadsTitle: "Mes téléchargements",
  noDownloads: "Aucun téléchargement disponible.",
  product: "Produit",
  type: "Type",
  date: "Date",
  download: "Télécharger",
  voice: "Voix",
  bot: "Bot",
  nft: "NFT",
};
export const user_downloads_page_el = {
  downloadsTitle: "Τα αρχεία μου / Λήψεις",
  noDownloads: "Δεν υπάρχουν διαθέσιμες λήψεις.",
  product: "Προϊόν",
  type: "Τύπος",
  date: "Ημερομηνία",
  download: "Λήψη",
  voice: "Φωνή",
  bot: "Bot",
  nft: "NFT",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: user_downloads_page_en,
  ar: user_downloads_page_ar,
  fr: user_downloads_page_fr,
  el: user_downloads_page_el,
};

const mockDownloads = [
  { id: 1, product: "EduBotX", type: "bot", date: "2025-08-08", url: "/downloads/EduBotX.zip" },
  { id: 2, product: "French TTS Voice", type: "voice", date: "2025-07-25", url: "/downloads/french-tts.zip" },
  { id: 3, product: "Mixtral NFT", type: "nft", date: "2025-07-13", url: "/downloads/mixtral-nft.zip" },
];

export default function UserDownloadsPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [downloads] = useState(mockDownloads);

  return (
    <main className="min-h-screen bg-black text-white p-6 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("downloadsTitle")}</h1>
      {downloads.length === 0 ? (
        <div className="text-lg text-center text-gray-400 py-16">{t("noDownloads")}</div>
      ) : (
        <table className="w-full table-auto text-left border">
          <thead>
            <tr className="bg-zinc-900">
              <th className="p-2 border">#</th>
              <th className="p-2 border">{t("product")}</th>
              <th className="p-2 border">{t("type")}</th>
              <th className="p-2 border">{t("date")}</th>
              <th className="p-2 border">{t("download")}</th>
            </tr>
          </thead>
          <tbody>
            {downloads.map((d, i) => (
              <tr key={d.id} className="border-t">
                <td className="p-2 border">{i + 1}</td>
                <td className="p-2 border">{d.product}</td>
                <td className="p-2 border">{t(d.type)}</td>
                <td className="p-2 border">{d.date}</td>
                <td className="p-2 border">
                  <a
                    href={d.url}
                    download
                    className="bg-blue-700 hover:bg-blue-800 text-white px-3 py-1 rounded shadow"
                  >
                    {t("download")}
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </main>
  );
}
