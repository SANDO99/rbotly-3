// UserProductsPage.js - صفحة منتجات المستخدم مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const user_products_page_en = {
  productsTitle: "My Products",
  productName: "Product Name",
  type: "Type",
  created: "Created",
  actions: "Actions",
  edit: "Edit",
  remove: "Remove",
  voice: "Voice",
  bot: "Bot",
  nft: "NFT",
};
export const user_products_page_ar = {
  productsTitle: "منتجاتي",
  productName: "اسم المنتج",
  type: "النوع",
  created: "تاريخ الإضافة",
  actions: "إجراءات",
  edit: "تعديل",
  remove: "حذف",
  voice: "صوت",
  bot: "بوت",
  nft: "رمز NFT",
};
export const user_products_page_fr = {
  productsTitle: "Mes produits",
  productName: "Nom du produit",
  type: "Type",
  created: "Créé le",
  actions: "Actions",
  edit: "Modifier",
  remove: "Supprimer",
  voice: "Voix",
  bot: "Bot",
  nft: "NFT",
};
export const user_products_page_el = {
  productsTitle: "Τα προϊόντα μου",
  productName: "Όνομα προϊόντος",
  type: "Τύπος",
  created: "Ημ/νία δημιουργίας",
  actions: "Ενέργειες",
  edit: "Επεξεργασία",
  remove: "Διαγραφή",
  voice: "Φωνή",
  bot: "Bot",
  nft: "NFT",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: user_products_page_en,
  ar: user_products_page_ar,
  fr: user_products_page_fr,
  el: user_products_page_el,
};

const mockProducts = [
  { id: 1, name: "French TTS Voice", type: "voice", created: "2025-08-02" },
  { id: 2, name: "EduBotX", type: "bot", created: "2025-07-20" },
  { id: 3, name: "Mixtral NFT", type: "nft", created: "2025-06-28" },
];

export default function UserProductsPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [products, setProducts] = useState(mockProducts);

  const handleEdit = (id) => {
    alert(`Edit product with id: ${id}`);
  };
  const handleRemove = (id) => {
    setProducts(products.filter(p => p.id !== id));
  };

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("productsTitle")}</h1>
      <table className="w-full table-auto text-left border">
        <thead>
          <tr className="bg-zinc-900">
            <th className="p-2 border">#</th>
            <th className="p-2 border">{t("productName")}</th>
            <th className="p-2 border">{t("type")}</th>
            <th className="p-2 border">{t("created")}</th>
            <th className="p-2 border">{t("actions")}</th>
          </tr>
        </thead>
        <tbody>
          {products.map((p, i) => (
            <tr key={p.id} className="border-t">
              <td className="p-2 border">{i + 1}</td>
              <td className="p-2 border">{p.name}</td>
              <td className="p-2 border">{t(p.type)}</td>
              <td className="p-2 border">{p.created}</td>
              <td className="p-2 border flex gap-2">
                <button onClick={() => handleEdit(p.id)} className="bg-blue-700 hover:bg-blue-800 text-white px-3 py-1 rounded">{t("edit")}</button>
                <button onClick={() => handleRemove(p.id)} className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded">{t("remove")}</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}
