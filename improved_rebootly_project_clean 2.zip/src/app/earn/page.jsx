"use client";
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'next-i18next';
import { serverSideTranslations } from 'next-i18next/serverSideTranslations';

/**
 * Earn Page
 *
 * Separate from the job search, this page allows users to earn points by
 * watching videos and completing surveys.  Tasks are fetched from an API
 * (represented here with a mock) and points are tracked in local state.
 */

export default function EarnPage() {
  const { t } = useTranslation('common');
  const [tasks, setTasks] = useState([]);
  const [completed, setCompleted] = useState({});
  const [points, setPoints] = useState(0);

  useEffect(() => {
    const mock = [
      {
        id: 'task1',
        type: 'video',
        title: 'Promotional Video 1',
        videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4',
        reward: 10,
      },
      {
        id: 'task2',
        type: 'survey',
        title: 'Customer Satisfaction Survey',
        surveyUrl: 'https://example.com/survey/123',
        reward: 20,
      },
    ];
    setTasks(mock);
  }, []);

  function handleVideoProgress(id, videoEl) {
    if (completed[id]) return;
    const progress = (videoEl.currentTime / videoEl.duration) * 100;
    if (progress >= 90) {
      setCompleted((prev) => ({ ...prev, [id]: true }));
      const task = tasks.find((t) => t.id === id);
      if (task) setPoints((p) => p + (task.reward || 0));
    }
  }

  function handleSurveyComplete(id) {
    if (completed[id]) return;
    alert(t('earn.surveyCompleteAlert'));
    setCompleted((prev) => ({ ...prev, [id]: true }));
    const task = tasks.find((t) => t.id === id);
    if (task) setPoints((p) => p + (task.reward || 0));
  }

  return (
    <main className="min-h-screen bg-black text-white p-4 md:p-8 space-y-8">
      <header className="space-y-2">
        <h1 className="text-3xl font-bold text-[var(--neon)]">{t('earn.title')}</h1>
        <p className="text-gray-400">{t('earn.desc')}</p>
        <div className="text-sm text-gray-500">
          {t('earn.points')}: <span className="font-semibold text-[var(--neon)]">{points}</span>
        </div>
      </header>
      <section className="space-y-6">
        {tasks.length === 0 && <p className="text-gray-500 italic">{t('earn.noTasks')}</p>}
        {tasks.map((task) => {
          if (task.type === 'video') {
            return (
              <div key={task.id} className="border border-gray-700 rounded-lg p-4 bg-zinc-900 space-y-4">
                <h2 className="text-xl font-semibold">{task.title}</h2>
                <video
                  src={task.videoUrl}
                  controls
                  className="w-full rounded"
                  onTimeUpdate={(e) => handleVideoProgress(task.id, e.target)}
                ></video>
                {completed[task.id] ? (
                  <p className="text-green-400 font-medium">{t('earn.completed')}</p>
                ) : (
                  <p className="text-gray-500 italic">{t('earn.watchTip')}</p>
                )}
              </div>
            );
          } else if (task.type === 'survey') {
            return (
              <div key={task.id} className="border border-gray-700 rounded-lg p-4 bg-zinc-900 space-y-4">
                <h2 className="text-xl font-semibold">{task.title}</h2>
                <button
                  onClick={() => handleSurveyComplete(task.id)}
                  disabled={!!completed[task.id]}
                  className="px-4 py-2 bg-[var(--neon)] text-black rounded-lg font-semibold disabled:opacity-50"
                >
                  {t('earn.takeSurveyBtn')}
                </button>
                {completed[task.id] && <p className="text-green-400 font-medium">{t('earn.completed')}</p>}
              </div>
            );
          }
          return null;
        })}
      </section>
    </main>
  );
}

export async function getStaticProps({ locale }) {
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common'])),
    },
  };
}