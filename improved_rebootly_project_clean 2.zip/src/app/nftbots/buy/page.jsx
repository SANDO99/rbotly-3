// NFTBotBuyPage.js - صفحة الشراء لبوت NFT مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const nft_bot_buy_page_en = {
  buyBotTitle: "Buy NFT Bot",
  product: "Product",
  owner: "Owner",
  price: "Price",
  payWith: "Pay with",
  tokenBalance: "Token balance:",
  confirm: "Confirm Purchase",
  success: "Purchase successful! The bot is now available in your downloads.",
  insufficient: "Insufficient token balance.",
  goToDownloads: "Go to My Downloads",
};
export const nft_bot_buy_page_ar = {
  buyBotTitle: "شراء بوت NFT",
  product: "المنتج",
  owner: "المالك",
  price: "السعر",
  payWith: "الدفع بواسطة",
  tokenBalance: "رصيد التوكن:",
  confirm: "تأكيد الشراء",
  success: "تم الشراء بنجاح! البوت أصبح متاحًا في صفحة التنزيلات.",
  insufficient: "رصيد التوكن غير كافٍ.",
  goToDownloads: "اذهب إلى ملفاتي/التنزيلات",
};
export const nft_bot_buy_page_fr = {
  buyBotTitle: "Acheter un bot NFT",
  product: "Produit",
  owner: "Propriétaire",
  price: "Prix",
  payWith: "Payer avec",
  tokenBalance: "Solde de jetons :",
  confirm: "Confirmer l'achat",
  success: "Achat réussi ! Le bot est désormais dans vos téléchargements.",
  insufficient: "Solde de jetons insuffisant.",
  goToDownloads: "Aller à mes téléchargements",
};
export const nft_bot_buy_page_el = {
  buyBotTitle: "Αγορά NFT Bot",
  product: "Προϊόν",
  owner: "Ιδιοκτήτης",
  price: "Τιμή",
  payWith: "Πληρωμή με",
  tokenBalance: "Υπόλοιπο tokens:",
  confirm: "Επιβεβαίωση αγοράς",
  success: "Η αγορά ολοκληρώθηκε! Το bot είναι πλέον διαθέσιμο στα αρχεία σας.",
  insufficient: "Ανεπαρκές υπόλοιπο tokens.",
  goToDownloads: "Μετάβαση στις λήψεις μου",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: nft_bot_buy_page_en,
  ar: nft_bot_buy_page_ar,
  fr: nft_bot_buy_page_fr,
  el: nft_bot_buy_page_el,
};

const mockBot = {
  id: 1,
  name: "Mixtral NFT Bot",
  img: "/img/nft1.png",
  owner: "ahmed@example.com",
  price: 15,
};
const mockUser = {
  tokenBalance: 20,
};

export default function NFTBotBuyPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const [processing, setProcessing] = useState(false);

  const handleBuy = () => {
    setError("");
    setProcessing(true);
    setTimeout(() => {
      if (mockUser.tokenBalance >= mockBot.price) {
        setSuccess(true);
      } else {
        setError(t("insufficient"));
      }
      setProcessing(false);
    }, 800);
  };

  return (
    <main className="min-h-screen bg-black text-white p-6 max-w-md mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("buyBotTitle")}</h1>
      <div className="bg-zinc-900 rounded-2xl p-6 mb-8 flex flex-col items-center">
        <img src={mockBot.img} alt={mockBot.name} className="w-32 h-32 mb-4 rounded-xl bg-zinc-800 object-contain" />
        <div className="font-bold text-lg mb-1">{mockBot.name}</div>
        <div className="text-xs text-gray-400 mb-1">{t("owner")}: {mockBot.owner}</div>
        <div className="text-xl text-green-400 mb-3">{t("price")}: ${mockBot.price}</div>
      </div>
      <div className="mb-4 bg-zinc-900 rounded-xl p-4">
        <div className="mb-1 font-semibold">{t("payWith")}</div>
        <div className="text-sm mb-2">{t("tokenBalance")} <span className="font-mono">{mockUser.tokenBalance}</span></div>
      </div>
      {success ? (
        <div className="bg-green-900 text-green-300 rounded-xl p-4 text-center font-bold flex flex-col gap-2 mb-4">
          {t("success")}
          <button className="bg-blue-700 hover:bg-blue-800 text-white px-3 py-1 rounded-xl mt-2">{t("goToDownloads")}</button>
        </div>
      ) : (
        <>
          {error && <div className="bg-red-900 text-red-400 rounded-xl p-3 text-center mb-3 font-bold">{error}</div>}
          <button
            onClick={handleBuy}
            className="bg-green-700 hover:bg-green-800 text-white px-5 py-2 rounded-xl w-full font-bold text-lg disabled:opacity-50"
            disabled={processing}
          >
            {processing ? "..." : t("confirm")}
          </button>
        </>
      )}
    </main>
  );
}
