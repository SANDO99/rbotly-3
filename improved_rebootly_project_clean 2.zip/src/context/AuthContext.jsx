import React, { createContext, useContext, useState, useMemo } from 'react';

// Simple authentication context that stores a user role and provides login/logout
// functionality. In a real application this would be tied to real auth flows.
const AuthCtx = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  // Example role: 'admin' or 'user'. Default is null when not authenticated.
  const [role, setRole] = useState(null);

  function login(username, password) {
    // Placeholder login logic. Accepts any username/password and assigns role
    // based on a simple rule: usernames starting with "admin" are admins.
    const isAdmin = username && username.toLowerCase().startsWith('admin');
    setUser({ username });
    setRole(isAdmin ? 'admin' : 'user');
  }

  function logout() {
    setUser(null);
    setRole(null);
  }

  const value = useMemo(() => ({ user, role, login, logout }), [user, role]);
  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}

export function useAuth() {
  const context = useContext(AuthCtx);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}