import { NextResponse } from 'next/server';

// Mock NFT mint endpoint. In a real implementation this would trigger a
// blockchain transaction and return a status. Here it simply returns a
// generated order ID and an OK flag. It accepts POST requests with a JSON
// payload that at minimum contains the item to mint.
export async function POST(request) {
  const body = await request.json().catch(() => ({}));
  // You could validate the payload here using zod or similar
  const orderId = `ORD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  return NextResponse.json({ ok: true, message: 'Mint started', orderId });
}

// Accept GET for checking mint status. Returns a mock success state.
export async function GET() {
  return NextResponse.json({ ok: true, status: 'minted' });
}