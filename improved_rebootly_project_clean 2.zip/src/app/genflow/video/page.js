import { useState } from 'react';
import { useTranslation } from 'next-i18next';
import { serverSideTranslations } from 'next-i18next/serverSideTranslations';

export default function TextToVideoPage() {
  const { t } = useTranslation('common');
  const [inputText, setInputText] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [videoType, setVideoType] = useState('short');

  const handleGenerateVideo = async () => {
    setIsLoading(true);
    setVideoUrl('');

    try {
      // ❌ ربط API لاحقًا
      // مثال وهمي مؤقت:
      const mockUrl = 'https://www.youtube.com/embed/dQw4w9WgXcQ';
      setTimeout(() => {
        setVideoUrl(mockUrl);
        setIsLoading(false);
      }, 2000);
    } catch (err) {
      console.error(err);
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-6 text-[var(--neon)]">
        {t('TextToVideo.title')}
      </h1>

      <div className="max-w-2xl space-y-6">
        <textarea
          className="w-full p-4 rounded-xl bg-zinc-900 text-white"
          rows={5}
          placeholder={t('TextToVideo.placeholder')}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
        />

        <div>
          <label className="block mb-2 text-white/70">{t('TextToVideo.selectType')}</label>
          <select
            className="w-full p-3 rounded-xl bg-zinc-900 text-white"
            value={videoType}
            onChange={(e) => setVideoType(e.target.value)}
          >
            <option value="short">{t('TextToVideo.types.short')}</option>
            <option value="explainer">{t('TextToVideo.types.explainer')}</option>
            <option value="motivational">{t('TextToVideo.types.motivational')}</option>
          </select>
        </div>

        <button
          className="bg-[var(--neon)] text-black font-bold px-6 py-3 rounded-xl hover:opacity-80"
          onClick={handleGenerateVideo}
          disabled={isLoading || !inputText}
        >
          {isLoading ? t('TextToVideo.loading') : t('TextToVideo.generate')}
        </button>

        {videoUrl && (
          <div className="mt-6">
            <h2 className="text-xl mb-4">{t('TextToVideo.preview')}</h2>
            <iframe
              className="w-full aspect-video rounded-xl"
              src={videoUrl}
              title="Generated Video"
              allowFullScreen
            />
          </div>
        )}
      </div>
    </main>
  );
}

export async function getStaticProps({ locale }) {
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common'])),
    },
  };
}
