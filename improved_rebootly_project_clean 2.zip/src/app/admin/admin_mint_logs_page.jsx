// AdminMintLogsPage.js - صفحة سجلات السك مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const admin_mint_logs_en = {
  mintLogsTitle: "Mint Logs",
  user: "User",
  bot: "Bot Name",
  date: "Mint Date",
  tx: "Transaction ID",
  status: "Status",
  success: "Success",
  failed: "Failed",
};
export const admin_mint_logs_ar = {
  mintLogsTitle: "سجلات السك",
  user: "المستخدم",
  bot: "اسم البوت",
  date: "تاريخ السك",
  tx: "معرف العملية",
  status: "الحالة",
  success: "ناجحة",
  failed: "فاشلة",
};
export const admin_mint_logs_fr = {
  mintLogsTitle: "Journaux de mint",
  user: "Utilisateur",
  bot: "Nom du bot",
  date: "Date de mint",
  tx: "ID de transaction",
  status: "Statut",
  success: "Succès",
  failed: "Échec",
};
export const admin_mint_logs_el = {
  mintLogsTitle: "Καταγραφές Mint",
  user: "Χρήστης",
  bot: "Όνομα bot",
  date: "Ημερομηνία mint",
  tx: "ID συναλλαγής",
  status: "Κατάσταση",
  success: "Επιτυχία",
  failed: "Αποτυχία",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: admin_mint_logs_en,
  ar: admin_mint_logs_ar,
  fr: admin_mint_logs_fr,
  el: admin_mint_logs_el,
};

const mockLogs = [
  { id: 1, user: "Ali Khaled", bot: "EduBotX", date: "2025-08-07", tx: "0xF8AB12...AA3", status: "success" },
  { id: 2, user: "Julia Petit", bot: "Mixtral Pro", date: "2025-08-06", tx: "0xD8EF88...C09", status: "failed" },
  { id: 3, user: "Sara Badr", bot: "ArtBot Mini", date: "2025-08-05", tx: "0x93AB91...2F2", status: "success" },
];

export default function AdminMintLogsPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [logs] = useState(mockLogs);

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("mintLogsTitle")}</h1>
      <table className="w-full table-auto text-left border">
        <thead>
          <tr className="bg-zinc-900">
            <th className="p-2 border">#</th>
            <th className="p-2 border">{t("user")}</th>
            <th className="p-2 border">{t("bot")}</th>
            <th className="p-2 border">{t("date")}</th>
            <th className="p-2 border">{t("tx")}</th>
            <th className="p-2 border">{t("status")}</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((log, i) => (
            <tr key={log.id} className="border-t">
              <td className="p-2 border">{i + 1}</td>
              <td className="p-2 border">{log.user}</td>
              <td className="p-2 border">{log.bot}</td>
              <td className="p-2 border">{log.date}</td>
              <td className="p-2 border">{log.tx}</td>
              <td className="p-2 border">
                <span className={
                  log.status === "success" ? "text-green-400" : "text-red-400"
                }>
                  {t(log.status)}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}
