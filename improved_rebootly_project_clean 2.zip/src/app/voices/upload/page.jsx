// voice_upload_page.jsx
export const voice_upload_page_en = {
  uploadTitle: "Sell / Upload AI Voice",
  voiceName: "Voice Name",
  description: "Description",
  category: "Category",
  male: "Male",
  female: "Female",
  child: "Child",
  other: "Other",
  language: "Language",
  arabic: "Arabic",
  english: "English",
  french: "French",
  greek: "Greek",
  otherLang: "Other",
  price: "Price (USD)",
  audioSample: "Audio Sample",
  image: "Cover Image",
  file: "Voice Model File (.zip)",
  ownership: "I confirm I own the rights to sell this voice.",
  submit: "Publish Voice",
  reset: "Reset",
  uploading: "Publishing...",
  success: "Your AI voice is submitted for review. You'll be notified when it's published.",
  preview: "Preview",
  required: "This field is required.",
};
export const voice_upload_page_ar = {
  uploadTitle: "بيع / رفع صوت ذكاء اصطناعي",
  voiceName: "اسم الصوت",
  description: "الوصف",
  category: "الفئة",
  male: "ذكر",
  female: "أنثى",
  child: "طفل",
  other: "أخرى",
  language: "اللغة",
  arabic: "العربية",
  english: "الإنجليزية",
  french: "الفرنسية",
  greek: "اليونانية",
  otherLang: "أخرى",
  price: "السعر (دولار)",
  audioSample: "عينة صوتية",
  image: "الصورة الغلاف",
  file: "ملف نموذج الصوت (.zip)",
  ownership: "أؤكد أن لدي حقوق بيع هذا الصوت.",
  submit: "نشر الصوت",
  reset: "إعادة تعيين",
  uploading: "جاري النشر...",
  success: "تم إرسال صوت الذكاء الاصطناعي للمراجعة. سنخطرك عند النشر.",
  preview: "معاينة",
  required: "هذا الحقل مطلوب.",
};
export const voice_upload_page_fr = {
  uploadTitle: "Vendre / Téléverser une voix IA",
  voiceName: "Nom de la voix",
  description: "Description",
  category: "Catégorie",
  male: "Masculin",
  female: "Féminin",
  child: "Enfant",
  other: "Autre",
  language: "Langue",
  arabic: "Arabe",
  english: "Anglais",
  french: "Français",
  greek: "Grec",
  otherLang: "Autre",
  price: "Prix (USD)",
  audioSample: "Échantillon audio",
  image: "Image de couverture",
  file: "Fichier du modèle de voix (.zip)",
  ownership: "Je confirme détenir les droits pour vendre cette voix.",
  submit: "Publier la voix",
  reset: "Réinitialiser",
  uploading: "Publication...",
  success: "Votre voix IA a été soumise pour examen. Vous serez notifié lors de la publication.",
  preview: "Aperçu",
  required: "Ce champ est obligatoire.",
};
export const voice_upload_page_el = {
  uploadTitle: "Πώληση / Μεταφόρτωση Φωνής ΤΝ",
  voiceName: "Όνομα φωνής",
  description: "Περιγραφή",
  category: "Κατηγορία",
  male: "Αρσενικό",
  female: "Θηλυκό",
  child: "Παιδί",
  other: "Άλλο",
  language: "Γλώσσα",
  arabic: "Αραβικά",
  english: "Αγγλικά",
  french: "Γαλλικά",
  greek: "Ελληνικά",
  otherLang: "Άλλη",
  price: "Τιμή (USD)",
  audioSample: "Ηχητικό δείγμα",
  image: "Εικόνα εξωφύλλου",
  file: "Αρχείο μοντέλου φωνής (.zip)",
  ownership: "Επιβεβαιώνω ότι έχω δικαιώματα πώλησης αυτής της φωνής.",
  submit: "Δημοσίευση φωνής",
  reset: "Επαναφορά",
  uploading: "Δημοσίευση...",
  success: "Η φωνή ΤΝ σας υποβλήθηκε για έλεγχο. Θα ειδοποιηθείτε όταν δημοσιευτεί.",
  preview: "Προεπισκόπηση",
  required: "Αυτό το πεδίο είναι υποχρεωτικό.",
};

import { useState, useRef } from "react";

const translations = {
  en: voice_upload_page_en,
  ar: voice_upload_page_ar,
  fr: voice_upload_page_fr,
  el: voice_upload_page_el,
};

export default function VoiceUploadPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;

  const [form, setForm] = useState({
    name: "",
    description: "",
    category: "male",
    language: "arabic",
    price: "",
    audioSample: null,
    image: null,
    file: null,
    ownership: false,
  });
  const [imgPreview, setImgPreview] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errors, setErrors] = useState({});

  const imageInputRef = useRef(null);
  const audioInputRef = useRef(null);
  const fileInputRef = useRef(null);

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = t("required");
    if (!form.description.trim()) e.description = t("required");
    if (!form.price || Number(form.price) <= 0) e.price = t("required");
    if (!form.audioSample) e.audioSample = t("required");
    if (!form.image) e.image = t("required");
    if (!form.file) e.file = t("required");
    if (!form.ownership) e.ownership = t("required");
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((f) => ({ ...f, [name]: type === "checkbox" ? checked : value }));
  };

  const handleImage = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setForm((f) => ({ ...f, image: file }));
    const reader = new FileReader();
    reader.onload = (ev) => setImgPreview(String(ev.target?.result || ""));
    reader.readAsDataURL(file);
  };

  const handleAudio = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setForm((f) => ({ ...f, audioSample: file }));
  };

  const handleFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setForm((f) => ({ ...f, file }));
  };

  const handleReset = () => {
    setForm({
      name: "",
      description: "",
      category: "male",
      language: "arabic",
      price: "",
      audioSample: null,
      image: null,
      file: null,
      ownership: false,
    });
    setImgPreview("");
    setErrors({});
    imageInputRef.current.value = "";
    audioInputRef.current.value = "";
    fileInputRef.current.value = "";
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    // TODO: ربط مع API فعلي لرفع البيانات (FormData)
    setTimeout(() => {
      setSubmitting(false);
      setSuccess(true);
      handleReset();
    }, 1200);
  };

  return (
    <main className="min-h-screen bg-black text-white p-6 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("uploadTitle")}</h1>
      {success && (
        <div className="bg-green-900 text-green-300 rounded-xl p-4 mb-6 font-semibold">
          {t("success")}
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-zinc-900 rounded-2xl p-6 flex flex-col gap-4">
        {/* اسم الصوت */}
        <div>
          <label className="block mb-1 font-semibold">{t("voiceName")}</label>
          <input
            name="name"
            value={form.name}
            onChange={handleChange}
            className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none"
            placeholder={t("voiceName")}
          />
          {errors.name && <div className="text-red-400 text-xs mt-1">{errors.name}</div>}
        </div>

        {/* الوصف */}
        <div>
          <label className="block mb-1 font-semibold">{t("description")}</label>
          <textarea
            name="description"
            value={form.description}
            onChange={handleChange}
            className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none min-h-[90px]"
            placeholder={t("description")}
          />
          {errors.description && <div className="text-red-400 text-xs mt-1">{errors.description}</div>}
        </div>

        {/* الفئة واللغة والسعر */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block mb-1 font-semibold">{t("category")}</label>
            <select
              name="category"
              value={form.category}
              onChange={handleChange}
              className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none"
            >
              <option value="male">{t("male")}</option>
              <option value="female">{t("female")}</option>
              <option value="child">{t("child")}</option>
              <option value="other">{t("other")}</option>
            </select>
          </div>
          <div>
            <label className="block mb-1 font-semibold">{t("language")}</label>
            <select
              name="language"
              value={form.language}
              onChange={handleChange}
              className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none"
            >
              <option value="arabic">{t("arabic")}</option>
              <option value="english">{t("english")}</option>
              <option value="french">{t("french")}</option>
              <option value="greek">{t("greek")}</option>
              <option value="other">{t("otherLang")}</option>
            </select>
          </div>
          <div>
            <label className="block mb-1 font-semibold">{t("price")}</label>
            <input
              type="number"
              min={0}
              step="0.01"
              name="price"
              value={form.price}
              onChange={handleChange}
              className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none"
              placeholder="0.00"
            />
            {errors.price && <div className="text-red-400 text-xs mt-1">{errors.price}</div>}
          </div>
        </div>

        {/* عينة صوتية */}
        <div>
          <label className="block mb-1 font-semibold">{t("audioSample")}</label>
          <input
            ref={audioInputRef}
            type="file"
            accept="audio/*"
            onChange={handleAudio}
            className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white"
          />
          {errors.audioSample && <div className="text-red-400 text-xs mt-1">{errors.audioSample}</div>}
        </div>

        {/* صورة الغلاف + المعاينة */}
        <div>
          <label className="block mb-1 font-semibold">{t("image")}</label>
          <input
            ref={imageInputRef}
            type="file"
            accept="image/*"
            onChange={handleImage}
            className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white"
          />
          {imgPreview && (
            <div className="mt-3">
              <div className="text-sm mb-1">{t("preview")}:</div>
              <div className="w-40 h-40 bg-zinc-800 rounded-xl overflow-hidden flex items-center justify-center">
                <img src={imgPreview} alt="preview" className="max-w-full max-h-full" />
              </div>
            </div>
          )}
          {errors.image && <div className="text-red-400 text-xs mt-1">{errors.image}</div>}
        </div>

        {/* ملف الصوت */}
        <div>
          <label className="block mb-1 font-semibold">{t("file")}</label>
          <input
            ref={fileInputRef}
            type="file"
            accept=".zip"
            onChange={handleFile}
            className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white"
          />
          {errors.file && <div className="text-red-400 text-xs mt-1">{errors.file}</div>}
        </div>

        {/* إقرار الملكية */}
        <div className="flex items-center gap-3">
          <input
            type="checkbox"
            id="ownership"
            name="ownership"
            checked={form.ownership}
            onChange={handleChange}
            className="accent-[var(--neon)] w-5 h-5"
          />
          <label htmlFor="ownership" className="text-sm">{t("ownership")}</label>
          {errors.ownership && <div className="text-red-400 text-xs ml-2">{errors.ownership}</div>}
        </div>

        {/* الأزرار */}
        <div className="flex gap-3 mt-2">
          <button
            type="submit"
            disabled={submitting}
            className="bg-green-700 hover:bg-green-800 disabled:opacity-50 text-white px-5 py-2 rounded-xl"
          >
            {submitting ? t("uploading") : t("submit")}
          </button>
          <button
            type="button"
            onClick={handleReset}
            className="bg-zinc-700 hover:bg-zinc-800 text-white px-5 py-2 rounded-xl"
          >
            {t("reset")}
          </button>
        </div>
      </form>
    </main>
  );
}