// Forward exports to the unified UserInventoryContext implementation.
export * from './UserInventoryContext.jsx';