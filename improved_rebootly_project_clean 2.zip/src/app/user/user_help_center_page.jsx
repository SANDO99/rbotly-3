// UserHelpCenterPage.js - صفحة مركز الدعم مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const user_help_center_page_en = {
  helpCenterTitle: "Help Center",
  faqTitle: "Frequently Asked Questions",
  contactSupport: "Contact Support",
  yourQuestion: "Your question or issue",
  send: "Send",
  sent: "Message sent! We'll contact you soon.",
  q1: "How do I buy an NFT bot?",
  a1: "Go to Marketplace, choose a bot, and follow purchase steps.",
  q2: "How can I check my token balance?",
  a2: "Your balance appears on your dashboard and token balance page.",
};
export const user_help_center_page_ar = {
  helpCenterTitle: "مركز الدعم",
  faqTitle: "الأسئلة الشائعة",
  contactSupport: "تواصل مع الدعم",
  yourQuestion: "سؤالك أو مشكلتك",
  send: "إرسال",
  sent: "تم إرسال الرسالة! سنعاود التواصل معك قريبًا.",
  q1: "كيف أشتري بوت NFT؟",
  a1: "اذهب إلى السوق، اختر البوت، واتبع خطوات الشراء.",
  q2: "كيف أتحقق من رصيد التوكن؟",
  a2: "يظهر رصيدك في لوحة التحكم وصفحة رصيد التوكن.",
};
export const user_help_center_page_fr = {
  helpCenterTitle: "Centre d'aide",
  faqTitle: "Questions fréquentes",
  contactSupport: "Contacter le support",
  yourQuestion: "Votre question ou problème",
  send: "Envoyer",
  sent: "Message envoyé ! Nous vous contacterons bientôt.",
  q1: "Comment acheter un bot NFT ?",
  a1: "Allez sur Marketplace, choisissez un bot et suivez les étapes d'achat.",
  q2: "Comment vérifier mon solde de jetons ?",
  a2: "Votre solde apparaît sur votre tableau de bord et la page de solde des jetons.",
};
export const user_help_center_page_el = {
  helpCenterTitle: "Κέντρο υποστήριξης",
  faqTitle: "Συχνές ερωτήσεις",
  contactSupport: "Επικοινωνήστε με την υποστήριξη",
  yourQuestion: "Η ερώτηση ή το πρόβλημά σας",
  send: "Αποστολή",
  sent: "Το μήνυμα εστάλη! Θα επικοινωνήσουμε σύντομα μαζί σας.",
  q1: "Πώς αγοράζω ένα NFT bot;",
  a1: "Μεταβείτε στην Αγορά, επιλέξτε ένα bot και ακολουθήστε τα βήματα αγοράς.",
  q2: "Πώς ελέγχω το υπόλοιπο tokens μου;",
  a2: "Το υπόλοιπό σας εμφανίζεται στον πίνακα χρήστη και στη σελίδα υπολοίπου tokens.",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: user_help_center_page_en,
  ar: user_help_center_page_ar,
  fr: user_help_center_page_fr,
  el: user_help_center_page_el,
};

export default function UserHelpCenterPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [question, setQuestion] = useState("");
  const [sent, setSent] = useState(false);

  const handleSend = (e) => {
    e.preventDefault();
    setSent(true);
    setQuestion("");
    // TODO: ربط مع API لإرسال السؤال للدعم
  };

  return (
    <main className="min-h-screen bg-black text-white p-6 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("helpCenterTitle")}</h1>
      <section className="mb-10">
        <h2 className="text-xl font-semibold mb-3 text-[var(--neon)]">{t("faqTitle")}</h2>
        <div className="mb-2">
          <strong>Q:</strong> {t("q1")}<br/>
          <span className="ml-5 text-gray-300"><strong>A:</strong> {t("a1")}</span>
        </div>
        <div className="mb-2">
          <strong>Q:</strong> {t("q2")}<br/>
          <span className="ml-5 text-gray-300"><strong>A:</strong> {t("a2")}</span>
        </div>
      </section>
      <section className="bg-zinc-900 rounded-2xl p-6">
        <h2 className="text-lg font-semibold mb-2">{t("contactSupport")}</h2>
        <form onSubmit={handleSend} className="flex flex-col gap-3">
          <textarea
            value={question}
            onChange={e => setQuestion(e.target.value)}
            required
            className="w-full min-h-[80px] p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none"
            placeholder={t("yourQuestion")}
          />
          <button type="submit" className="bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-xl w-max">{t("send")}</button>
        </form>
        {sent && <div className="mt-4 text-green-400 font-semibold">{t("sent")}</div>}
      </section>
    </main>
  );
}
