import '../globals.css';
// Initialize i18n; this import has side effects that set up translations.
import '../i18n';
import { AuthProvider } from '../context/AuthContext';
import { UserInventoryProvider } from '../context/UserInventoryContext.mint';

export const metadata = { title: 'Rebootly', description: 'Unified marketplace and AI platform' };

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-gray-50 text-gray-900 dark:bg-gray-950 dark:text-gray-50">
        {/* Provide Auth and Inventory contexts globally */}
        <AuthProvider>
          <UserInventoryProvider>
            {children}
          </UserInventoryProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
