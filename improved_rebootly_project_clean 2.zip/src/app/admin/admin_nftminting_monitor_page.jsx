// AdminNFTMintingMonitorPage.js - مراقبة عمليات سك بوتات NFT مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const admin_nft_minting_monitor_en = {
  mintingMonitorTitle: "NFT Minting Monitor",
  botId: "Bot ID",
  wallet: "Wallet",
  tx: "Tx Hash",
  status: "Status",
  success: "Success",
  failed: "Failed",
  loading: "Loading...",
  viewOnPolygonscan: "View on Polygonscan",
};
export const admin_nft_minting_monitor_ar = {
  mintingMonitorTitle: "مراقبة سك بوتات NFT",
  botId: "معرف البوت",
  wallet: "المحفظة",
  tx: "معرّف المعاملة",
  status: "الحالة",
  success: "ناجحة",
  failed: "فاشلة",
  loading: "جاري التحميل...",
  viewOnPolygonscan: "عرض على Polygonscan",
};
export const admin_nft_minting_monitor_fr = {
  mintingMonitorTitle: "Moniteur de mint NFT",
  botId: "ID du bot",
  wallet: "Portefeuille",
  tx: "Tx Hash",
  status: "Statut",
  success: "Succès",
  failed: "Échec",
  loading: "Chargement...",
  viewOnPolygonscan: "Voir sur Polygonscan",
};
export const admin_nft_minting_monitor_el = {
  mintingMonitorTitle: "Παρακολούθηση Minting NFT Bots",
  botId: "ID Bot",
  wallet: "Πορτοφόλι",
  tx: "Tx Hash",
  status: "Κατάσταση",
  success: "Επιτυχία",
  failed: "Αποτυχία",
  loading: "Φόρτωση...",
  viewOnPolygonscan: "Προβολή στο Polygonscan",
};

// --- مكون الصفحة الرئيسي ---
import { useEffect, useState } from "react";

const translations = {
  en: admin_nft_minting_monitor_en,
  ar: admin_nft_minting_monitor_ar,
  fr: admin_nft_minting_monitor_fr,
  el: admin_nft_minting_monitor_el,
};

// بيانات وهمية في حال لم تتوفر بيانات من API
const mockLogs = [
  { id: 1, botId: "EDU-33X", wallet: "0x9aBd...11c1", tx: "0xF8AB12...AA3", status: "success" },
  { id: 2, botId: "MIX-001", wallet: "0xD7fC...24aa", tx: "0xD8EF88...C09", status: "failed" },
  { id: 3, botId: "ART-44M", wallet: "0x4beD...FF2e", tx: "0x93AB91...2F2", status: "success" },
];

export default function AdminNFTMintingMonitorPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // TODO: ربط مع API حقيقي - استبدال البيانات الوهمية إذا توفر API
    // fetch("/api/admin/mint-logs").then(r => r.json()).then(data => { setLogs(data); setLoading(false); })
    setTimeout(() => {
      setLogs(mockLogs);
      setLoading(false);
    }, 900);
  }, []);

  return (
    <main className="min-h-screen bg-black text-white p-6">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("mintingMonitorTitle")}</h1>
      {loading ? (
        <div className="text-xl py-16 text-center">{t("loading")}</div>
      ) : (
        <table className="w-full table-auto text-left border">
          <thead>
            <tr className="bg-zinc-900">
              <th className="p-2 border">#</th>
              <th className="p-2 border">{t("botId")}</th>
              <th className="p-2 border">{t("wallet")}</th>
              <th className="p-2 border">{t("tx")}</th>
              <th className="p-2 border">{t("status")}</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((log, i) => (
              <tr key={log.id} className="border-t">
                <td className="p-2 border">{i + 1}</td>
                <td className="p-2 border">{log.botId}</td>
                <td className="p-2 border">{log.wallet}</td>
                <td className="p-2 border">
                  <a
                    className="underline text-blue-400 hover:text-blue-600"
                    href={`https://polygonscan.com/tx/${log.tx}`}
                    target="_blank" rel="noopener noreferrer"
                  >
                    {log.tx.slice(0, 8)}...{log.tx.slice(-4)}
                  </a>
                  <span className="ml-2 text-xs text-gray-400">{t("viewOnPolygonscan")}</span>
                </td>
                <td className="p-2 border">
                  <span className={
                    log.status === "success" ? "text-green-400" : "text-red-400"
                  }>
                    {t(log.status)}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </main>
  );
}
