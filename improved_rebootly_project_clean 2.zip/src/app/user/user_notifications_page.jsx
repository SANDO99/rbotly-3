// UserNotificationsPage.js - صفحة إشعارات المستخدم مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const user_notifications_page_en = {
  notificationsTitle: "Notifications",
  markAllRead: "Mark all as read",
  noNotifications: "No notifications.",
  new: "New",
  read: "Read",
  orderSuccess: "Order completed successfully!",
  tokenUsed: "Token used in service:",
  supportReply: "Support replied to your ticket.",
  downloadReady: "Your download is ready.",
};
export const user_notifications_page_ar = {
  notificationsTitle: "الإشعارات",
  markAllRead: "تعيين الكل كمقروء",
  noNotifications: "لا توجد إشعارات.",
  new: "جديد",
  read: "مقروء",
  orderSuccess: "تم تنفيذ طلبك بنجاح!",
  tokenUsed: "تم استخدام التوكن في الخدمة:",
  supportReply: "تم الرد على تذكرتك من الدعم.",
  downloadReady: "الملف متاح الآن للتحميل.",
};
export const user_notifications_page_fr = {
  notificationsTitle: "Notifications",
  markAllRead: "Tout marquer comme lu",
  noNotifications: "Aucune notification.",
  new: "Nouveau",
  read: "Lu",
  orderSuccess: "Commande terminée avec succès!",
  tokenUsed: "Jeton utilisé dans le service :",
  supportReply: "Le support a répondu à votre ticket.",
  downloadReady: "Votre téléchargement est prêt.",
};
export const user_notifications_page_el = {
  notificationsTitle: "Ειδοποιήσεις",
  markAllRead: "Σήμανση όλων ως διαβασμένων",
  noNotifications: "Δεν υπάρχουν ειδοποιήσεις.",
  new: "Νέο",
  read: "Διαβασμένο",
  orderSuccess: "Η παραγγελία ολοκληρώθηκε με επιτυχία!",
  tokenUsed: "Το token χρησιμοποιήθηκε στην υπηρεσία:",
  supportReply: "Η υποστήριξη απάντησε στο αίτημά σας.",
  downloadReady: "Η λήψη σας είναι έτοιμη.",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: user_notifications_page_en,
  ar: user_notifications_page_ar,
  fr: user_notifications_page_fr,
  el: user_notifications_page_el,
};

const mockNotifications = [
  { id: 1, type: "orderSuccess", text: "orderSuccess", date: "2025-08-08", read: false },
  { id: 2, type: "tokenUsed", text: "tokenUsed", extra: "Text-to-Image", date: "2025-08-07", read: false },
  { id: 3, type: "supportReply", text: "supportReply", date: "2025-08-07", read: true },
  { id: 4, type: "downloadReady", text: "downloadReady", date: "2025-08-05", read: true },
];

export default function UserNotificationsPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [notifications, setNotifications] = useState(mockNotifications);

  const markAllRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
  };
  const markAsRead = (id) => {
    setNotifications(notifications.map(n => n.id === id ? { ...n, read: true } : n));
  };

  return (
    <main className="min-h-screen bg-black text-white p-6 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("notificationsTitle")}</h1>
      <div className="flex justify-end mb-4">
        <button onClick={markAllRead} className="bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-xl">
          {t("markAllRead")}
        </button>
      </div>
      {notifications.length === 0 ? (
        <div className="text-lg text-center text-gray-400 py-16">{t("noNotifications")}</div>
      ) : (
        <ul className="flex flex-col gap-4">
          {notifications.map(n => (
            <li key={n.id} className={`rounded-xl p-4 flex items-center justify-between shadow ${n.read ? "bg-zinc-900" : "bg-zinc-800 border border-[var(--neon)]"}`}>
              <div>
                <div className="font-semibold text-base">
                  {t(n.text)}
                  {n.extra && <span className="ml-2 text-[var(--neon)] font-mono">{n.extra}</span>}
                </div>
                <div className="text-xs text-gray-400 mt-1">{n.date}</div>
              </div>
              <div className="flex flex-col items-end gap-1">
                <span className={`text-xs font-bold ${n.read ? "text-gray-500" : "text-[var(--neon)]"}`}>{n.read ? t("read") : t("new")}</span>
                {!n.read && (
                  <button onClick={() => markAsRead(n.id)} className="text-xs underline text-blue-400 hover:text-blue-600">{t("read")}</button>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
