// NFTBotUploadPage.js - صفحة رفع/بيع بوت NFT جديد مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const nft_bot_upload_page_en = {
  uploadTitle: "Sell / Upload NFT Bot",
  botName: "Bot Name",
  description: "Description",
  category: "Category",
  education: "Education",
  assistant: "Assistant",
  entertainment: "Entertainment",
  healthcare: "Healthcare",
  price: "Price (USD)",
  image: "Cover Image",
  file: "Bot Package File (.zip)",
  ownership: "I confirm I own the rights to sell this bot.",
  submit: "Publish Bot",
  reset: "Reset",
  uploading: "Publishing...",
  success: "Your NFT bot is submitted for review. You'll be notified when it's published.",
  preview: "Preview",
  required: "This field is required.",
};
export const nft_bot_upload_page_ar = {
  uploadTitle: "بيع / رفع بوت NFT",
  botName: "اسم البوت",
  description: "الوصف",
  category: "الفئة",
  education: "تعليمي",
  assistant: "مساعد",
  entertainment: "ترفيه",
  healthcare: "صحة",
  price: "السعر (دولار)",
  image: "الصورة الغلاف",
  file: "ملف حزمة البوت (.zip)",
  ownership: "أؤكد أن لدي حقوق بيع هذا البوت.",
  submit: "نشر البوت",
  reset: "إعادة تعيين",
  uploading: "جاري النشر...",
  success: "تم إرسال بوت NFT للمراجعة. سنخطرك عند النشر.",
  preview: "معاينة",
  required: "هذا الحقل مطلوب.",
};
export const nft_bot_upload_page_fr = {
  uploadTitle: "Vendre / Téléverser un bot NFT",
  botName: "Nom du bot",
  description: "Description",
  category: "Catégorie",
  education: "Éducation",
  assistant: "Assistant",
  entertainment: "Divertissement",
  healthcare: "Santé",
  price: "Prix (USD)",
  image: "Image de couverture",
  file: "Fichier du bot (.zip)",
  ownership: "Je confirme détenir les droits pour vendre ce bot.",
  submit: "Publier le bot",
  reset: "Réinitialiser",
  uploading: "Publication...",
  success: "Votre bot NFT a été soumis pour examen. Vous serez notifié lors de la publication.",
  preview: "Aperçu",
  required: "Ce champ est obligatoire.",
};
export const nft_bot_upload_page_el = {
  uploadTitle: "Πώληση / Μεταφόρτωση NFT Bot",
  botName: "Όνομα bot",
  description: "Περιγραφή",
  category: "Κατηγορία",
  education: "Εκπαίδευση",
  assistant: "Βοηθός",
  entertainment: "Ψυχαγωγία",
  healthcare: "Υγεία",
  price: "Τιμή (USD)",
  image: "Εικόνα εξωφύλλου",
  file: "Αρχείο πακέτου bot (.zip)",
  ownership: "Επιβεβαιώνω ότι έχω δικαιώματα πώλησης αυτού του bot.",
  submit: "Δημοσίευση bot",
  reset: "Επαναφορά",
  uploading: "Δημοσίευση...",
  success: "Το NFT bot σας υποβλήθηκε για έλεγχο. Θα ειδοποιηθείτε όταν δημοσιευτεί.",
  preview: "Προεπισκόπηση",
  required: "Αυτό το πεδίο είναι υποχρεωτικό.",
};

// --- مكون الصفحة الرئيسي ---
import { useState, useRef } from "react";

const translations = {
  en: nft_bot_upload_page_en,
  ar: nft_bot_upload_page_ar,
  fr: nft_bot_upload_page_fr,
  el: nft_bot_upload_page_el,
};

export default function NFTBotUploadPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;

  const [form, setForm] = useState({
    name: "",
    description: "",
    category: "education",
    price: "",
    image: null,
    file: null,
    ownership: false,
  });
  const [imgPreview, setImgPreview] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errors, setErrors] = useState({});

  const imageInputRef = useRef(null);
  const fileInputRef = useRef(null);

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = t("required");
    if (!form.description.trim()) e.description = t("required");
    if (!form.price || Number(form.price) <= 0) e.price = t("required");
    if (!form.image) e.image = t("required");
    if (!form.file) e.file = t("required");
    if (!form.ownership) e.ownership = t("required");
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((f) => ({ ...f, [name]: type === "checkbox" ? checked : value }));
  };

  const handleImage = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setForm((f) => ({ ...f, image: file }));
    const reader = new FileReader();
    reader.onload = (ev) => setImgPreview(String(ev.target?.result || ""));
    reader.readAsDataURL(file);
  };

  const handleFile = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setForm((f) => ({ ...f, file }));
  };

  const handleReset = () => {
    setForm({ name: "", description: "", category: "education", price: "", image: null, file: null, ownership: false });
    setImgPreview("");
    setErrors({});
    imageInputRef.current?.value = "";
    fileInputRef.current?.value = "";
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    // TODO: ربط مع API فعلي لرفع البيانات (FormData)
    setTimeout(() => {
      setSubmitting(false);
      setSuccess(true);
      handleReset();
    }, 1200);
  };

  return (
    <main className="min-h-screen bg-black text-white p-6 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("uploadTitle")}</h1>
      {success && (
        <div className="bg-green-900 text-green-300 rounded-xl p-4 mb-6 font-semibold">
          {t("success")}
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-zinc-900 rounded-2xl p-6 flex flex-col gap-4">
        {/* اسم البوت */}
        <div>
          <label className="block mb-1 font-semibold">{t("botName")}</label>
          <input
            name="name"
            value={form.name}
            onChange={handleChange}
            className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none"
            placeholder={t("botName")}
          />
          {errors.name && <div className="text-red-400 text-xs mt-1">{errors.name}</div>}
        </div>

        {/* الوصف */}
        <div>
          <label className="block mb-1 font-semibold">{t("description")}</label>
          <textarea
            name="description"
            value={form.description}
            onChange={handleChange}
            className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none min-h-[90px]"
            placeholder={t("description")}
          />
          {errors.description && <div className="text-red-400 text-xs mt-1">{errors.description}</div>}
        </div>

        {/* الفئة والسعر */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block mb-1 font-semibold">{t("category")}</label>
            <select
              name="category"
              value={form.category}
              onChange={handleChange}
              className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none"
            >
              <option value="education">{t("education")}</option>
              <option value="assistant">{t("assistant")}</option>
              <option value="entertainment">{t("entertainment")}</option>
              <option value="healthcare">{t("healthcare")}</option>
            </select>
          </div>
          <div>
            <label className="block mb-1 font-semibold">{t("price")}</label>
            <input
              type="number"
              min={0}
              step="0.01"
              name="price"
              value={form.price}
              onChange={handleChange}
              className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none"
              placeholder="0.00"
            />
            {errors.price && <div className="text-red-400 text-xs mt-1">{errors.price}</div>}
          </div>
        </div>

        {/* صورة الغلاف + المعاينة */}
        <div>
          <label className="block mb-1 font-semibold">{t("image")}</label>
          <input
            ref={imageInputRef}
            type="file"
            accept="image/*"
            onChange={handleImage}
            className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white"
          />
          {imgPreview && (
            <div className="mt-3">
              <div className="text-sm mb-1">{t("preview")}:</div>
              <div className="w-40 h-40 bg-zinc-800 rounded-xl overflow-hidden flex items-center justify-center">
                <img src={imgPreview} alt="preview" className="max-w-full max-h-full" />
              </div>
            </div>
          )}
          {errors.image && <div className="text-red-400 text-xs mt-1">{errors.image}</div>}
        </div>

        {/* ملف البوت */}
        <div>
          <label className="block mb-1 font-semibold">{t("file")}</label>
          <input
            ref={fileInputRef}
            type="file"
            accept=".zip"
            onChange={handleFile}
            className="w-full p-2 rounded bg-zinc-800 border border-zinc-700 text-white"
          />
          {errors.file && <div className="text-red-400 text-xs mt-1">{errors.file}</div>}
        </div>

        {/* إقرار الملكية */}
        <div className="flex items-center gap-3">
          <input
            type="checkbox"
            id="ownership"
            name="ownership"
            checked={form.ownership}
            onChange={handleChange}
            className="accent-[var(--neon)] w-5 h-5"
          />
          <label htmlFor="ownership" className="text-sm">{t("ownership")}</label>
          {errors.ownership && <div className="text-red-400 text-xs ml-2">{errors.ownership}</div>}
        </div>

        {/* الأزرار */}
        <div className="flex gap-3 mt-2">
          <button
            type="submit"
            disabled={submitting}
            className="bg-green-700 hover:bg-green-800 disabled:opacity-50 text-white px-5 py-2 rounded-xl"
          >
            {submitting ? t("uploading") : t("submit")}
          </button>
          <button
            type="button"
            onClick={handleReset}
            className="bg-zinc-700 hover:bg-zinc-800 text-white px-5 py-2 rounded-xl"
          >
            {t("reset")}
          </button>
        </div>
      </form>
    </main>
  );
}
