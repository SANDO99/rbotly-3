import React, { useState } from 'react';
import { useParams } from 'next/navigation';
import { useTranslation } from 'next-i18next';
import { serverSideTranslations } from 'next-i18next/serverSideTranslations';
// Adjust relative import path for context
import { useUserInventory } from '../../../context/UserInventoryContext';

/**
 * Bot Studio Page
 *
 * This page provides a workshop-like environment for the owner of a bot to
 * customise and train it.  The page is split into logical sections (Overview,
 * Data, Instructions, Examples, Test Chat, Deploy, Lessons) to guide users
 * through the process without requiring them to write code.  NFT minting
 * happens transparently in the background when the bot is purchased; the mint
 * status is not displayed here.
 */

export default function BotStudioPage() {
  const { botId } = useParams();
  const { t } = useTranslation('common');
  const inv = useUserInventory();

  // Find the bot in the user's inventory
  const bot = inv.bots.find((b) => b.id === botId);

  // Local state for instructions and examples
  const [prompt, setPrompt] = useState('');
  const [examples, setExamples] = useState([]);
  const [newQ, setNewQ] = useState('');
  const [newA, setNewA] = useState('');

  if (!bot) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center space-y-3">
          <h1 className="text-3xl font-bold">{t('studio.notFound')}</h1>
          <p>{t('studio.notFoundDesc')}</p>
        </div>
      </div>
    );
  }

  // Handlers
  function addExample() {
    if (!newQ.trim() || !newA.trim()) return;
    setExamples((prev) => [...prev, { id: Date.now().toString(), q: newQ, a: newA }]);
    setNewQ('');
    setNewA('');
  }
  function removeExample(id) {
    setExamples((prev) => prev.filter((ex) => ex.id !== id));
  }

  return (
    <main className="min-h-screen bg-black text-white p-4 md:p-8 space-y-8">
      {/* Overview */}
      <section className="space-y-2">
        <h1 className="text-3xl font-bold text-[var(--neon)]">{bot.name}</h1>
        <p className="text-gray-400">{t('studio.overviewDesc')}</p>
        <div className="flex items-center gap-4 mt-2">
          <span className="px-3 py-1 bg-green-700 text-xs rounded-full">
            {t(bot.type === 'bots-nft' ? 'studio.typeNFT' : 'studio.typeBot')}
          </span>
          <span className="px-3 py-1 bg-blue-700 text-xs rounded-full">{bot.language.toUpperCase()}</span>
        </div>
      </section>

      {/* Data Upload Section */}
      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">{t('studio.dataTitle')}</h2>
        <p className="text-gray-400">{t('studio.dataDesc')}</p>
        <div className="border border-gray-700 rounded-lg p-4 bg-zinc-900">
          {/* Placeholder for file uploader */}
          <p className="text-gray-500 italic">
            {t('studio.dataPlaceholder')}
          </p>
        </div>
      </section>

      {/* Instructions Section */}
      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">{t('studio.instructionsTitle')}</h2>
        <textarea
          className="w-full min-h-[120px] p-4 bg-zinc-900 rounded-lg focus:outline-none"
          placeholder={t('studio.instructionsPlaceholder')}
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
        ></textarea>
        <button
          className="px-4 py-2 bg-[var(--neon)] text-black rounded-lg font-semibold hover:opacity-80"
          onClick={() => {
            /* Persist prompt to backend */
          }}
        >
          {t('studio.save')}
        </button>
      </section>

      {/* Examples Section */}
      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">{t('studio.examplesTitle')}</h2>
        <div className="space-y-2">
          {examples.map((ex) => (
            <div key={ex.id} className="flex items-start justify-between bg-zinc-900 p-3 rounded-lg">
              <div>
                <p className="font-medium text-[var(--neon)]">Q: {ex.q}</p>
                <p className="text-gray-300">A: {ex.a}</p>
              </div>
              <button
                onClick={() => removeExample(ex.id)}
                className="text-red-400 hover:text-red-600"
              >
                {t('studio.remove')}
              </button>
            </div>
          ))}
        </div>
        <div className="grid md:grid-cols-2 gap-2">
          <input
            type="text"
            className="p-2 bg-zinc-900 rounded-lg"
            placeholder={t('studio.examplesQuestion')}
            value={newQ}
            onChange={(e) => setNewQ(e.target.value)}
          />
          <input
            type="text"
            className="p-2 bg-zinc-900 rounded-lg"
            placeholder={t('studio.examplesAnswer')}
            value={newA}
            onChange={(e) => setNewA(e.target.value)}
          />
          <button
            className="px-4 py-2 bg-[var(--neon)] text-black rounded-lg font-semibold hover:opacity-80"
            onClick={addExample}
          >
            {t('studio.addExample')}
          </button>
        </div>
      </section>

      {/* Test Chat Section */}
      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">{t('studio.testTitle')}</h2>
        <p className="text-gray-400">{t('studio.testDesc')}</p>
        <div className="border border-gray-700 rounded-lg p-4 bg-zinc-900 min-h-[100px]">
          <p className="text-gray-500 italic">{t('studio.testPlaceholder')}</p>
        </div>
      </section>

      {/* Deploy Section */}
      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">{t('studio.deployTitle')}</h2>
        <p className="text-gray-400">{t('studio.deployDesc')}</p>
        <button
          className="px-6 py-2 bg-green-600 rounded-lg text-white font-bold hover:bg-green-700"
          onClick={() => {
            /* Start or stop managed runtime */
          }}
        >
          {t('studio.deployStart')}
        </button>
      </section>

      {/* Lessons Section */}
      <section className="space-y-4">
        <h2 className="text-2xl font-semibold">{t('studio.lessonsTitle')}</h2>
        <p className="text-gray-400">{t('studio.lessonsDesc')}</p>
        <div className="border border-gray-700 rounded-lg p-4 bg-zinc-900">
          {/* Placeholder for dynamic lessons feed */}
          <p className="text-gray-500 italic">{t('studio.lessonsPlaceholder')}</p>
        </div>
      </section>
    </main>
  );
}

// Load translations on the server
export async function getStaticProps({ locale }) {
  return {
    props: {
      ...(await serverSideTranslations(locale, ['common'])),
    },
  };
}