// AdminSupportTicketsPage.js - صفحة إدارة تذاكر الدعم للمشرف مع ترجمة رباعية (ملف كامل)

// --- ملفات الترجمة ---
export const admin_support_tickets_page_en = {
  supportTicketsTitle: "Support Tickets",
  from: "From",
  email: "Email",
  date: "Date",
  status: "Status",
  open: "Open",
  answered: "Answered",
  closed: "Closed",
  message: "Message",
  reply: "Reply",
  yourReply: "Your reply...",
  send: "Send",
  sent: "Reply sent!",
};
export const admin_support_tickets_page_ar = {
  supportTicketsTitle: "تذاكر الدعم",
  from: "من",
  email: "البريد الإلكتروني",
  date: "التاريخ",
  status: "الحالة",
  open: "مفتوحة",
  answered: "تم الرد",
  closed: "مغلقة",
  message: "الرسالة",
  reply: "الرد",
  yourReply: "ردك...",
  send: "إرسال",
  sent: "تم إرسال الرد!",
};
export const admin_support_tickets_page_fr = {
  supportTicketsTitle: "Tickets de support",
  from: "De",
  email: "E-mail",
  date: "Date",
  status: "Statut",
  open: "Ouvert",
  answered: "Répondu",
  closed: "Fermé",
  message: "Message",
  reply: "Réponse",
  yourReply: "Votre réponse...",
  send: "Envoyer",
  sent: "Réponse envoyée !",
};
export const admin_support_tickets_page_el = {
  supportTicketsTitle: "Αιτήματα υποστήριξης",
  from: "Από",
  email: "Email",
  date: "Ημερομηνία",
  status: "Κατάσταση",
  open: "Ανοιχτό",
  answered: "Απαντήθηκε",
  closed: "Κλειστό",
  message: "Μήνυμα",
  reply: "Απάντηση",
  yourReply: "Η απάντησή σας...",
  send: "Αποστολή",
  sent: "Η απάντηση εστάλη!",
};

// --- مكون الصفحة الرئيسي ---
import { useState } from "react";

const translations = {
  en: admin_support_tickets_page_en,
  ar: admin_support_tickets_page_ar,
  fr: admin_support_tickets_page_fr,
  el: admin_support_tickets_page_el,
};

const mockTickets = [
  {
    id: 1,
    from: "Ali Khaled",
    email: "ali@example.com",
    date: "2025-08-08",
    status: "open",
    message: "I have an issue with my token balance.",
    replies: [],
  },
  {
    id: 2,
    from: "Sara Badr",
    email: "sara@example.com",
    date: "2025-08-07",
    status: "answered",
    message: "How do I download my NFT bot?",
    replies: [
      { text: "You can find your downloads in the Downloads page.", date: "2025-08-07" },
    ],
  },
  {
    id: 3,
    from: "Lucas Dupont",
    email: "lucas@example.com",
    date: "2025-08-05",
    status: "closed",
    message: "App not working on my phone.",
    replies: [
      { text: "Please make sure you are on the latest version.", date: "2025-08-05" },
      { text: "Ticket closed by admin.", date: "2025-08-06" },
    ],
  },
];

export default function AdminSupportTicketsPage({ locale = "en" }) {
  const t = (key) => translations[locale][key] || key;
  const [tickets, setTickets] = useState(mockTickets);
  const [activeTicket, setActiveTicket] = useState(null);
  const [reply, setReply] = useState("");
  const [sent, setSent] = useState(false);

  const handleReply = (id) => {
    setTickets(tickets.map(t => t.id === id ? {
      ...t,
      status: "answered",
      replies: [...t.replies, { text: reply, date: new Date().toISOString().slice(0, 10) }],
    } : t));
    setReply("");
    setSent(true);
    setTimeout(() => setSent(false), 2000);
  };
  const closeModal = () => {
    setActiveTicket(null);
    setReply("");
    setSent(false);
  };

  return (
    <main className="min-h-screen bg-black text-white p-6 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-[var(--neon)]">{t("supportTicketsTitle")}</h1>
      <table className="w-full table-auto text-left border mb-8">
        <thead>
          <tr className="bg-zinc-900">
            <th className="p-2 border">#</th>
            <th className="p-2 border">{t("from")}</th>
            <th className="p-2 border">{t("email")}</th>
            <th className="p-2 border">{t("date")}</th>
            <th className="p-2 border">{t("status")}</th>
            <th className="p-2 border"></th>
          </tr>
        </thead>
        <tbody>
          {tickets.map((ticket, i) => (
            <tr key={ticket.id} className="border-t">
              <td className="p-2 border">{i + 1}</td>
              <td className="p-2 border">{ticket.from}</td>
              <td className="p-2 border">{ticket.email}</td>
              <td className="p-2 border">{ticket.date}</td>
              <td className="p-2 border">
                <span className={
                  ticket.status === "open" ? "text-yellow-400" :
                  ticket.status === "answered" ? "text-blue-400" : "text-gray-400"
                }>
                  {t(ticket.status)}
                </span>
              </td>
              <td className="p-2 border">
                <button
                  onClick={() => setActiveTicket(ticket)}
                  className="bg-blue-700 hover:bg-blue-800 text-white px-3 py-1 rounded"
                >
                  {t("message")}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {activeTicket && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
          <div className="bg-zinc-900 rounded-2xl p-8 max-w-lg w-full shadow-lg relative">
            <button
              onClick={closeModal}
              className="absolute top-3 right-4 text-gray-400 hover:text-white text-xl"
            >×</button>
            <div className="mb-3">
              <div className="font-bold text-xl mb-1">{activeTicket.from}</div>
              <div className="text-sm text-gray-400 mb-1">{activeTicket.email} | {activeTicket.date}</div>
              <div className="text-base mb-2"><strong>{t("message")}:</strong> {activeTicket.message}</div>
              {activeTicket.replies.length > 0 && (
                <div className="mb-2">
                  <div className="text-sm font-bold mb-1">{t("reply")}:</div>
                  <ul className="pl-4 list-disc text-sm text-gray-300">
                    {activeTicket.replies.map((r, idx) => (
                      <li key={idx}><span className="font-mono">[{r.date}]</span> {r.text}</li>
                    ))}
                  </ul>
                </div>
              )}
              <form
                className="flex flex-col gap-2 mt-3"
                onSubmit={e => { e.preventDefault(); handleReply(activeTicket.id); }}
              >
                <textarea
                  value={reply}
                  onChange={e => setReply(e.target.value)}
                  className="w-full min-h-[80px] p-2 rounded bg-zinc-800 border border-zinc-700 text-white focus:outline-none"
                  placeholder={t("yourReply")}
                  required
                  disabled={activeTicket.status === "closed"}
                />
                <button
                  type="submit"
                  className="bg-green-700 hover:bg-green-800 text-white px-4 py-2 rounded-xl mt-2"
                  disabled={activeTicket.status === "closed" || !reply.trim()}
                >
                  {t("send")}
                </button>
                {sent && <div className="mt-2 text-green-400 font-semibold">{t("sent")}</div>}
              </form>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
